<?php
 
function employee_list() {
    ?>  
	<div id="my_view_employee"><h1>Employee Listing</h1></div>
    <div class="wrap">
        <table id="employe_id">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Name</th>
                    <th>Role</th>
                    <th>Contact</th>
					<th>Delete</th>
					<th>Update</th>
                </tr>
            </thead>
                <tbody>
                <?php
                global $wpdb;
                $table_name = $wpdb->prefix . 'employee_list';
                $employees = $wpdb->get_results("SELECT id,name,contact,role from $table_name");
                foreach ($employees as $employee) {
                    ?>
                    <tr>
                        <td><?= $employee->id; ?></td>
                        <td><?= $employee->name; ?></td>
                        <td><?= $employee->role; ?></td>
                        <td><?= $employee->contact; ?></td>
						<td>
						<div class="box">
							<a class="button" href="#popup_delete<?= $employee->id;?>" id="update_datas">Delete</a>
						</div>
						<div id="popup_delete<?= $employee->id;?>" class="overlay">
						<div class="popup">
						<form id="delete" method="post" action="">
						   <h3 id="update_data_heading">Are You Sure? Delete The Data</h3>
							<input type="hidden" name="deleteRow"  value="<?= $employee->id; ?>"/>
							<a href="#"><input type="button" value="Cencel" id="delete_datas"></a>
							<input type="submit" name="delete" value="Delete" id="delete_datas">
						</form>
						</div> 
						</div>
						</td>
			<td>
	<div class="box">
	<a class="button" href="#popup1<?= $employee->id;?>" id="update_datas">Update</a>
</div>

<div id="popup1<?= $employee->id; ?>" class="overlay">
	<div class="popup">
	<h3 id="update_data_heading">Update Data</h3>
	<a class="close" href="#">&times;</a>
		<form id="delete1" method="post" action="">
		<p id="update_name">Employee Id :<?= $employee->id; ?></p>  
		<input type="hidden" name="update_id"  value="<?= $employee->id; ?>"/>
		<p id="update_name">Employee Name</p>
		<input type="text" name="update_name"  value="<?= $employee->name; ?>"/>
		<p id="update_name">Employee Role</p>
		<input type="text" name="update_role"  value="<?= $employee->role; ?>"/>
		<p id="update_name">Employee Contact</p>
		<input type="text" name="update_contact"  value="<?= $employee->contact; ?>"/>
        <p><input type="submit" name="update" value="Update" id="display_popup_update"></p>			
    </form>
	</div>
</div>
	</td>
                    </tr>
                <?php } ?>
           
            </tbody>
        </table>
    </div>
    <?php 
	 if (isset($_POST['delete'])) {
		 $myid=$_POST['deleteRow'];
			global $wpdb;			
			 if($wpdb->query(
				  'DELETE  FROM '.$wpdb->prefix.'employee_list
				   WHERE id = "'.$myid.'"'
			  
			  )== false) wp_die('Data Is Not Delete, Plesae Try Again!'); 
	else{
		echo '<style>.popup{display:none;}</style><script>alert("Data Is Deleted Successfuly")</script>';
		echo '<script>window.location.reload();</script>';	
		}
		}
	if(isset($_POST['update'])){
		 $myid=$_POST['update_id'];
		  $mynamne=$_POST['update_name'];
		   $myrole=$_POST['update_role'];
			$mycontact=$_POST['update_contact'];
			$ids= $myid;
		     $result = $wpdb->update(
		$wpdb->prefix .'employee_list', 
		array( 
			'name' => $mynamne,
			'role' => $myrole,
			'contact' => $mycontact
		), 
		array(
			"id" => $myid
		) 
	);
	$urls=admin_url();
	if($result== false){
		echo '<style>.popup{display:none;}</style> <script>alert("Data Is Not Update! Try Again");</script>';	
		//echo '<script>window.location.reload();</script>';		
        echo'<script>window.location = "'.$urls.'admin.php?page=Employee+Listing";</script>';		
		
		
	}
	else{
			echo '<style>.popup{display:none;}</style>';
			echo '<script>alert("'.$mynamne.' Employee Data Is Update Successfuly");</script>';					
			 echo'<script>window.location = "'.$urls.'admin.php?page=Employee+Listing";</script>';	
		}
	}
?>
<style>
.box {
    margin: 0 auto;
    text-align: center;
}
.button {
  font-size: 1em;
  padding: 10px;
  color: #fff;
  border: 2px solid #06D85F;
  border-radius: 20px/50px;
  text-decoration: none;
  cursor: pointer;
  transition: all 0.3s ease-out;
}
.button:hover {
  background: #06D85F;
}

.overlay {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(0, 0, 0, 0.7);
  transition: opacity 500ms;
  visibility: hidden;
  opacity: 0;
}
.overlay:target {
  visibility: visible;
  opacity: 1;
}

.popup {
  margin: 70px auto;
  padding: 20px;
  background: #fff;
  border-radius: 5px;
  width: 20%;
  position: relative;
  transition: all 5s ease-in-out;
}

.popup h2 {
  margin-top: 0;
  color: #333;
  font-family: Tahoma, Arial, sans-serif;
}
.popup .close {
  position: absolute;
  top: 20px;
  right: 30px;
  transition: all 200ms;
  font-size: 30px;
  font-weight: bold;
  text-decoration: none;
  color: #333;
}
.popup .close:hover {
  color: #06D85F;
}
.popup .content {
  max-height: 30%;
  overflow: auto;
}
input#delete_datas {
    color: #fff;
    background: #085cde;
    padding: 8px 10px;
    border: 1px solid #fff;
    font-size: 14px;
}
input#delete_datas:hover {    
    background:#185abf;
 }
#update_datas {
    color: #fff;
    background: #085cde;
    padding: 5px 10px;
    border: 1px solid #fff;
    font-size: 14px;
    border-radius: 0px;
    height: auto;
}
#update_datas:hover{background:#185abf;}
#delete{margin-bottom:0px;}
p#update_name {
    text-align: left;
    font-size: 13px;
    color: #000;
}
#delete1 input {
    width: 100%;
    height: 30px;
}
input#display_popup_update{    
    color: #fff;
    background: #000;   
    border: 1px solid #fff;
    border-radius: 5px;
    font-size: 15px;
	height:30px;
}
input#display_popup_update:hover{    
    background: #5a5a5a;    
}
@media screen and (max-width: 700px){
  .box{
    width: 70%;
  }
  .popup{
    width: 70%;
  }
}
</style>
<?php	
}
?> 