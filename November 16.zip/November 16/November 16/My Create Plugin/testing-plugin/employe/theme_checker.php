<?php
function theme_checker_all($template_files, $theme_title) {
	$static_count = 0;
        $bad_lines = null;
        $static_urls = null;
        $static_count = 0;
        
	foreach ($template_files as $tfile)
	{	
		/*
		 * Check for base64 Encoding
		 * Here we check every line of the file for base64 functions.
		 * 
		 */
			
		$lines = file($tfile, FILE_IGNORE_NEW_LINES); // Read the theme file into an array

		$line_index = 0;
		$is_first = true;
		foreach($lines as $this_line)
		{
			if (stristr ($this_line, "base64")) // Check for any base64 functions
			{
				if ($is_first) {
						$bad_lines .= tac_make_edit_linkkemi($tfile, $theme_title); 
						$is_first = false;
					}
				$bad_lines .= "<div class=\"tac-bad\"><strong>Line " . ($line_index+1) . ":</strong> \"" . trim(htmlspecialchars(substr(stristr($this_line, "base64"), 0, 45))) . "...\"</div>";
			}
			$line_index++;
		}
		
		/*
		 * Check for Static Links
		 * Here we utilize a regex to find HTML static links in the file.
		 * 
		 */

		$file_string = file_get_contents($tfile);

		$url_re='([[:alnum:]\-\.])+(\\.)([[:alnum:]]){2,4}([[:blank:][:alnum:]\/\+\=\%\&\_\\\.\~\?\-]*)';
		$title_re='[[:blank:][:alnum:][:punct:]]*';	// 0 or more: any num, letter(upper/lower) or any punc symbol
		$space_re='(\\s*)'; 
				
		if (preg_match_all ("/(<a)(\\s+)(href".$space_re."=".$space_re."\"".$space_re."((http|https|ftp):\\/\\/)?)".$url_re."(\"".$space_re.$title_re.$space_re.">)".$title_re."(<\\/a>)/is", $file_string, $out, PREG_SET_ORDER))
		{
			$static_urls .= tac_make_edit_linkkemi($tfile, $theme_title); 
									  
			foreach( $out as $key ) {
				$static_urls .= "<div class=\"tac-ehh\">";
				$static_urls .= htmlspecialchars($key[0]);
				$static_urls .= "</div>";
				$static_count++;
			}			  
		}  
	} // End for each file in template loop
	
	// Assemble the HTML results for the completed scan of the current theme
	if (!isset($bad_lines)) {
		$summary = '<span class="tac-good-notice">Theme Are Good!</span>';
	} else {
		$summary = '<span class="tac-bad-notice">Encrypted Code Found!</span>';
	}
	if(isset($static_urls)) {
		$summary .= '<span class="tac-ehh-notice"><strong>'.$static_count.'</strong> Static Link(s) Found...</span>';
	}
	
	return array('summary' => $summary, 'bad_lines' => $bad_lines, 'static_urls' => $static_urls, 'static_count' => $static_count);

}


function tac_make_edit_linkkemi($tfile, $theme_title) {
	// Assemble the HTML links for editing files with the built-in WP theme editor
	
	if ($GLOBALS['wp_version'] >= "2.9") {
		return "<div class=\"file-path\"><a href=\"theme-editor.php?file=/" . substr(stristr($tfile, "themes"), 0) . "&amp;theme=" . urlencode($theme_title) ."&amp;dir=theme\">" . substr(stristr($tfile, "wp-content"), 0) . " [Edit]</a></div>";	
	} elseif ($GLOBALS['wp_version'] >= "2.6") {
		return "<div class=\"file-path\"><a href=\"theme-editor.php?file=/" . substr(stristr($tfile, "themes"), 0) . "&amp;theme=" . urlencode($theme_title) ."\">" . substr(stristr($tfile, "wp-content"), 0) . " [Edit]</a></div>";
	} else {
		return "<div class=\"file-path\"><a href=\"theme-editor.php?file=" . substr(stristr($tfile, "wp-content"), 0) . "&amp;theme=" . urlencode($theme_title) ."\">" . substr(stristr($tfile, "wp-content"), 0) ." [Edit]</a></div>";
	}
	
}

function tac_get_template_fileskemi($template) {
	// Scan through the template directory and add all php files to an array
	
	$theme_root = get_theme_root();
	
	$template_files = array();
	$template_dir = @ dir("$theme_root/$template");
	if ( $template_dir ) {
		while(($file = $template_dir->read()) !== false) {
			if ( !preg_match('|^\.+$|', $file) && preg_match('|\.php$|', $file) )
				$template_files[] = "$theme_root/$template/$file";
		}
	}

	return $template_files;
}

// function tac_init() {
	// if ( function_exists('add_submenu_page') )
		// $page = add_submenu_page('themes.php',__('Theme Authenticity Checker (TAC)'), __('TAC'), 'update_plugins', 'tac.php', 'tac');
// }

// add_action('admin_menu', 'tac_init');

function tacnical() {

	?>
<script type="text/javascript">
	function toggleDiv(divid){
	  if(document.getElementById(divid).style.display == 'none'){
		document.getElementById(divid).style.display = 'block';
	  }else{
		document.getElementById(divid).style.display = 'none';
	  }
	}
</script>	
<div id="theme_checker_code">
<h2>
    <?php _e('All Theme File Scan List'); ?>
</h2>
<div class="pinfo">
    This Fucnction checks all active or inactive themes for malicious,unwanted codes. Also Found the Static links used in themes<br/>    
</div>
<div id="wrap">
    <?php
	$themes = get_themes();
	$theme_names = array_keys($themes);
	natcasesort($theme_names);
	foreach ($theme_names as $theme_name) {
		$template_files = tac_get_template_fileskemi($themes[$theme_name]['Template']);
		$title = $themes[$theme_name]['Title'];
		$version = $themes[$theme_name]['Version'];
		$author = $themes[$theme_name]['Author'];
		$screenshot = $themes[$theme_name]['Screenshot'];
		$stylesheet_dir = $themes[$theme_name]['Stylesheet Dir'];
		
		if ($GLOBALS['wp_version'] >= "2.9") {
			$theme_root_uri = $themes[$theme_name]['Theme Root URI'];
			$template = $themes[$theme_name]['Template'];
		}

		$results = theme_checker_all($template_files, $title);
	?>
    <div id="tacthemes">
        <?php if ( $screenshot ) : 
			if ($GLOBALS['wp_version'] >= "2.9") : ?>
				<img src="<?php echo $theme_root_uri.'/'.$template.'/'.$screenshot.'"'."alt=\"$title Screenshot\""; ?> />
			<?php else : ?>
				<img src="<?php echo get_option('siteurl') . '/wp-content' . str_replace('wp-content', '', $stylesheet_dir) . '/' . $screenshot.'"'."alt=\"$title Screenshot\""; ?> id="image_id" />			
			<?php endif; ?>
        <?php else : ?>
        	<div class="tacnoimg">No Screenshot Found</div>
        <?php endif; ?>

		<?php echo '<div class="t-info">'."<strong>$title</strong> $version by $author"; ?>
		
		<?php if ($results['bad_lines'] != '' || $results['static_urls'] != '') : ?>
			<input type="button" value="Details" class="button-primary" id="details" name="details" onmousedown="toggleDiv('<?php echo $title; ?>');" href="javascript:;"/>
		<?php endif; ?>
			</div>
			
		<?php echo $results['summary']; ?>	
			
        <div class="tacresults" id="<?php echo $title; ?>" style="display:none;">
            <?php echo $results['bad_lines'].$results['static_urls']; ?>
        </div>
		
    </div>
	</div>
		
    <?php
	}
	//echo '</div>';
}
    function tac_csss() {
echo '
<style type="text/css">
<!--

#wrap {
	background-color:#FFF;
	margin-right:5px;
}

.tac-bad, .tac-ehh {
    border: 1px solid #d6d6d6;
    font-family: "Courier New", Courier, monospace;
    margin-bottom: 10px;
    margin-left: 10px;
    padding: 10px;
    width: 90%;
}
.tac-bad {
	background:#FFC0CB;
}

.tac-ehh {
    background: #ffebeb;
}

span.tac-good-notice, span.tac-bad-notice, span.tac-ehh-notice {
	float:left;
	font-size:120%;
	margin: 25px 10px 0 0;
	padding:10px;
}

span.tac-good-notice {
    background: #dc0a0a;
    border: 1px solid #e8e7e7;
    width: auto;
    vertical-align: middle;
    color: #fff;
    border-radius: 5px;
    margin-top: 19px;
}

span.tac-bad-notice {
	background: #dc6c0a;
    border: 1px solid #e8e7e7;
    width: auto;
    vertical-align: middle;
    color: #fff;
    border-radius: 5px;
    margin-top: 19px;
}

span.tac-ehh-notice {
    background: #0a70dc;
    border: 1px solid #e8e7e7;
    width: auto;
    vertical-align: middle;
    color: #fff;
    border-radius: 5px;
    margin-top: 19px;
}

.file-path {
	color:#666;
	font-size:12px;
	padding-bottom:1px;
	padding-top:5px;
	text-align:right;
	width:92%;
}

.file-path a {
	text-decoration:none;
}

.pinfo {
	background:#DCDCDC;
	margin:5px 5px 40px;
	padding:5px;
}

#tacthemes {
	border-top:none;
	margin:10px;
	min-height:100px;
	padding-bottom:20px;
	padding-top:20px;
}

#image_id{
	 border: 1px solid #cecdcd;
    color: #DCDCDC;
    float: left;
    font-size: 16px;
    height: 143px;
    margin: 10px;
    text-align: center;
    width: 200px;
}
.t-info {
    margin-top: -12px;
}
#tacthemes img, .tacnoimg {
    border: 1px solid #cecdcd;
    color: #DCDCDC;
    float: left;
    font-size: 16px;
    height: 121px;
    margin: -10px 10px 0px 2px;
    text-align: center;
    width: 200px;
}

.tacresults {
	clear:left;
	margin-left:130px;
	
}
div#theme_checker_code {
    border: 1px solid #eae1e1;
    margin: 10px 0px;
    padding: 10px;
}
.wp-core-ui .button-primary {
    background: #ba4f00;
    color: #fff;
    text-decoration: none;
    border: 1px solid #fff;
    box-shadow: none;
    text-shadow: none;
}
-->
</style>
';
	}

add_action('admin_head', 'tac_csss');
    ?>

	
	
