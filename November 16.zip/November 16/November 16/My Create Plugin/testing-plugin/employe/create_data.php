<?php 
function emplyoyee_insert_into_db() {
 
   if($_POST['Submit']) {
//$table_name = $wpdb->prefix . 'employee_list';  
// run validation if you're not doing it in js
global $wpdb;

$name=$_POST['employee_name'];
$role=$_POST['employee_role'];
$contact=$_POST['employee_contact'];

if($wpdb->insert(
        'wp_employee_list',
        array(
                'name' => $name,
                'role' => $role,
                'contact' =>$contact
            )
) == false) wp_die('Data Is Not Send, Plesae Try Again!'); 
else{
	echo '<h1 id="database_mesaage">Database insertion successful</h1>';
	echo '<a href="" id="addform"><p id="add_anoter_data">Add Another Employee</p></a>';
    }

?>

<?php
}
	else // else we didn't submit the form, so display the form
	{
		?>
		<div id="my_data_wrapper">
		<form action="" method="post" id="addcourse">
		<label for="visitor_name"><h3>Add New Employe Data</h3></label>
		<p id="datapera">Employee Name</p>
				<input type="text" name="employee_name" id="employee_name" required />
				<p id="datapera">Employee Role</p>
				<select name="employee_role" size="1">
					<option selected>Developer</option>
					<option>Designer</option>
					<option>Business Analyist</option>
					<option>Tester</option>
					<option>Business Integration and Technical Training</option>
				</select>
				
				<p id="datapera">Employee Contact No</p>
				 <input type="text" name="employee_contact" id="employee_contact" required />

		<p><input type="submit" name="Submit" id="addcoursesubmit" value="Submit" /></p>
		</form>
		</div>
		<?php
		}
		}
add_shortcode('employee_insert_data', 'emplyoyee_insert_into_db');		
?>