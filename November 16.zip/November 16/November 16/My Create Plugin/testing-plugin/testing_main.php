<?php
/*
Plugin Name: KK Testing Plugin
Plugin URI: http://kamaalkunwar.com
Description: KK Testing Plugin scans all of your theme files for potentially malicious or unwanted code.
Author: kamal kunwar
Version: 1.5.2
Author URI: http://kamaalkunwar.com
*/

/*  Copyright @2016 

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/
//error_reporting(0);
function at_alphansotech_menu() {
    add_menu_page('Employee Listing', //page title
            'Employee Listing', //menu title
            'manage_options', //capabilities
            'Employee Listing', //menu slug
            employee_list //function
    );	
	add_submenu_page(
        'Employee Listing',       // parent slug
        'Add New Employee',    // page title
        'Add New Employee',             // menu title
        'manage_options',           // capability
        'create_new_data',      // slug
        'emplyoyee_insert_into_db' // callback
    ); 
	add_submenu_page(
        'Employee Listing',       // parent slug
        'Theme Checker',    // page title
        'Theme Checker',             // menu title
        'manage_options',           // capability
        'theme_checker',      // slug
        'tacnical' // callback
    ); 
}
add_action('admin_menu', 'at_alphansotech_menu');
function at_datatable() {
    global $wpdb; 
	$charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'employee_list';   
 
    $sql = "CREATE TABLE $table_name (
		id mediumint(9) NOT NULL AUTO_INCREMENT,
		name varchar(100) NOT NULL,
		role varchar(100) NOT NULL,
		contact varchar(100) NOT NULL,
		UNIQUE KEY id (id)
	) $charset_collate;";
 
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta($sql); 
} 
register_activation_hook(__FILE__, 'at_datatable');
 
define('ROOTDIR', plugin_dir_path(__FILE__)); 
require_once(ROOTDIR . 'employe/employee_list.php');
require_once(ROOTDIR . 'employe/create_data.php');
require_once(ROOTDIR . 'employe/theme_checker.php');
require_once(ROOTDIR . 'employe/header.php');
//require_once(ROOTDIR . 'employe/ajax_loader.php');
wp_register_style ( 'mysample', plugins_url ( 'assets/testingcss.css', __FILE__ ) );
wp_enqueue_style('mysample');
?>