<html>
<head>
<style>
body
{
 margin:0 auto;
 padding:0px;
 text-align:center;
 width:100%;
 font-family: "Myriad Pro","Helvetica Neue",Helvetica,Arial,Sans-Serif;
 background-color:#01A9DB;
}
#wrapper
{
 margin:0 auto;
 padding:0px;
 text-align:center;
 width:995px;
}
#wrapper h1
{
 margin-top:50px;
 font-size:65px;
}
#wrapper a
{
 color:blue;
 font-size:20px;
}
</style>
</head>
<body>
<div id="wrapper">

<h1>Soory For The Inconvenience Please Try Again Later</h1>
<a href="www.google.com">google.com</a>

</div>
</body>
</html>