<html>
<head>
<link type="text/css" rel="stylesheet" href="preview_style.css"/>
<script src="jquery-1.12.4.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript">
function preview()
{
 $("#preview_div").html($("#text").val());
}
</script>
</head>
<body>
<div id="wrapper">

<textarea id="text"onkeyup="preview();" placeholder="Enter Text Or Code"></textarea>

<div id="preview_div"></div>

</div>
</body>
</html>

<style>
body
{
 margin:0 auto;
 padding:0px;
 text-align:center;
 width:100%;
 font-family: "Myriad Pro","Helvetica Neue",Helvetica,Arial,Sans-Serif;
 background-color:#0B2161;
}
#wrapper
{
 margin:0 auto;
 padding:0px;
 text-align:center;
 width:995px;
}
#wrapper h1
{
 margin-top:50px;
 font-size:45px;
 color:white;
}
#wrapper p
{
 font-size:16px;
}
#wrapper #text
{
 width:400px;
 height:100px;
 font-size:16px;
 padding:10px;
}
#preview_div
{
 background-color:white;
 width:400px;
 margin-left:297px;
 margin-top:20px;
 color:#2E2E2E;
 padding:10px;
 box-sizing:border-box;
}
</style>