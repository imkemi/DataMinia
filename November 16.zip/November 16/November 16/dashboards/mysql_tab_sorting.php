<!-- // Database Structure 
CREATE TABLE 'employee' (
 'Name' text NOT NULL,
 'Age' int NOT NULL,
 'Salary' int NOT NULL,
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1
-->
<html>
<head>
</head>
<body>
<div id="wrapper">
<div id="table_div">
<?php
$host="localhost";
$username="root";
$password="";
$databasename="sample";
$connect=mysql_connect($host,$username,$password);
$db=mysql_select_db($databasename);	 

$order="asc";
if($_GET['orderby']=="name" && $_GET['order']=="asc")
{
 $order="desc";
}
if($_GET['orderby']=="age" && $_GET['order']=="asc")
{
 $order="desc";
}
if($_GET['orderby']=="salary" && $_GET['order']=="asc")
{
 $order="desc";
}

if($_GET['orderby'])
{
 $orderby="order by ".$_GET['orderby'];
}
if($_GET['order'])
{
 $sort_order=$_GET['order'];
}
 
$get_result=mysql_query("select * from employee ".$orderby." ".$sort_order."");
echo "<table align=center border=1 cellpadding=10>";
echo "<tr>";
 echo "<th><a href='?orderby=name&order=".$order."'>Name</a></th>";
 echo "<th><a href='?orderby=age&order=".$order."'>Age</a></th>";
 echo "<th><a href='?orderby=salary&order=".$order."'>Salary</a></th>";
echo "</tr>";
while($row=mysql_fetch_array($get_result))
{
 echo "<tr>";
  echo "<td>".$row['Name']."</td>";
  echo "<td>".$row['Age']."</td>";
  echo "<td>".$row['Salary']."</td>";
 echo "</tr>";
}
echo "</table>";
?>
</div>

</div>
</body>
</html>
<style>
body
{
 margin:0 auto;
 padding:0px;
 text-align:center;
 width:100%;
 font-family: "Myriad Pro","Helvetica Neue",Helvetica,Arial,Sans-Serif;
 background-color:#D0ECE7;
}
#wrapper
{
 margin:0 auto;
 padding:0px;
 text-align:center;
 width:995px;	
}
#wrapper h1
{
 margin-top:50px;
 font-size:45px;
 color:#117A65;
}
#wrapper h1 p
{
font-size:18px;
}
#table_div table
{
 border-collapse:collapse;
 text-align:center;
 border:grey;
}
#table_div table a
{
 color:#117A65;
 font-size:18px;
}
#table_div td
{
 width:100px;
 color:#212F3D;
}
</style>