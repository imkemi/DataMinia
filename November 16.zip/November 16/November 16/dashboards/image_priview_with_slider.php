<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
</head>   
<body>

<script>
// This function is used to preview the image whenever sombody click on any image
function big_image(src,index)
{
 $("#slideshow_image").fadeIn(1000);
 $('#slideshow_image').attr('src',src);
 visibility();
 document.getElementById("img_no").value=index;
}

// This function is used to slide previous images on preview whenever somebody clicks on previous button
function prev()
{
 visibility();
 $('#slideshow_image').fadeOut(300,function()
 {
   var prev_val=document.getElementById("img_no").value;
   var prev_val=Number(prev_val)-1;

   if(prev_val<=0)
   {
     prev_val=4;
   }
   var img=document.getElementById("gallery");
   var src=img.children[prev_val-1].src;

   $('#slideshow_image').attr('src',src);
   document.getElementById("img_no").value=prev_val;
 });

 $('#slideshow_image').fadeIn(1000);
}

// This function is used to slide next images on preview whenever somebody clicks on next button
function next()
{
 visibility();
 $('#slideshow_image').fadeOut(300,function()
 {
  var next_val=document.getElementById("img_no").value;
  var next_val=Number(next_val)+1;
 
  if(next_val>4)
  {
   next_val=1;
  }
  var img=document.getElementById("gallery");
  var src=img.children[next_val-1].src;

  $('#slideshow_image').attr('src',src);
   
  document.getElementById("img_no").value=next_val;
 });

 $('#slideshow_image').fadeIn(1000);
}
</script>
<center>
<div id="gallery">
 <img class="gal_img" src="images/img.jpg" onclick="big_image(this.src,1)">
 <img class="gal_img" src="images/img.jpg" onclick="big_image(this.src,2)">
 <img class="gal_img" src="images/img.jpg" onclick="big_image(this.src,3)">
 <img class="gal_img" src="images/img.jpg" onclick="big_image(this.src,4)">
</div>
</center>

<img src="images/img.jpg" id="slideshow_image">
<input type="image" id="prev_image" src="images/previous.png">
<input type="image" id="next_image" src="images/next.png">
<input type="image" id="close_image" src="images/close.png">
<input type="hidden" id="img_no" value="1">

</body>
</html>
<style>
		body
		{
		 background-color:#6E6E6E;
		}
		#gallery
		{
		 margin-top:50px;
		 padding:5px;
		 width:400px;
		 height:400px;
		 border:5px solid #2E2E2E;
		}
		#gallery img
		{
		 margin:2px;
		 width:190px;
		 height:190px;
		}
		#slideshow_image
		{
		 visibility:hidden;
		 display:none;
		 position:absolute;
		 top:0px;
		 left:0px;
		 right:0px;
		 box-shadow:0px 0px 20px 0px black;
		 width:90%;
		 height:80%;
		 margin:5%;
		 padding:7px;
		 background-color:white;
		}
		#prev_image,#next_image
		{
		 visibility:hidden;
		 display:none;
		 width:40px;
		 height:40px;
		 position:absolute;
		}
		#prev_image
		{
		 top:80%;
		 left:400px;
		}
		#next_image
		{
		 top:80%;
		 left:540px;
		}
		#close_image
		{
		 width:20px;
		 height:20px;
		 visibility:hidden;
		 display:none;
		 position:absolute;
		}
		#close_image
		{
		 top:10%;
		 left:950px;
		}
</style>
<script>
$(document).ready(function()
{
 $("#prev_image").click(function(){
  prev();
 });
 $("#next_image").click(function(){
  next();
 });
 $("#close_image").click(function(){
  close();
 });
});

// This function is used to close the preview of the image whenever sombody click on 
   close button
function close()
{
 $('#slideshow_image').fadeOut(300,function()
 {
  document.getElementById("slideshow_image").style.visibility="hidden";
  document.getElementById("slideshow_image").style.display="none";
  document.getElementById("prev_image").style.visibility="hidden";
  document.getElementById("prev_image").style.display="none";
  document.getElementById("next_image").style.visibility="hidden";
  document.getElementById("next_image").style.display="none";
  document.getElementById("close_image").style.visibility="hidden";
  document.getElementById("close_image").style.display="none";
 });
}

function visibility()
{
 document.getElementById("slideshow_image").style.visibility="visible";
 document.getElementById("slideshow_image").style.display="block";
 document.getElementById("prev_image").style.visibility="visible";
 document.getElementById("prev_image").style.display="block";
 document.getElementById("next_image").style.visibility="visible";
 document.getElementById("next_image").style.display="block";
 document.getElementById("close_image").style.visibility="visible";
 document.getElementById("close_image").style.display="block";
}
</script>