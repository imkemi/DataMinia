<html>
<head>
<style>
body
{
 width:100%;
 margin:0 auto;
 padding:0px;
 font-family:helvetica;
}
#wrapper
{
 text-align:center;
 margin:0 auto;
 padding:0px;
 width:100%;
}
#animated_div
{
width: 100%;
height: 100%;
background: url(images/img.jpg) repeat-x;
background-size:cover;
-webkit-animation: animatebackground 60s linear infinite;
animation: animatebackground 60s linear infinite;
-ms-animation: animatebackground 60s linear infinite;
-moz-animation: animatebackground 60s linear infinite;
}
@keyframes animatebackground 
{
 from {background-position: 0 0;}
 to {background-position: -1000px 0;}
}
@-webkit-keyframes animatebackground 
{
 from {background-position: 0 0;}
 to {background-position: -1000px 0;}
}
@-ms-keyframes animatebackground 
{
 from {background-position: 0 0;}
 to {background-position: -1000px 0;}
}
@-moz-keyframes animatebackground 
{
 from {background-position: 0 0;}
 to {background-position: -1000px 0;}
}
#animated_div h1
{
 color:white;
 padding-top:100px;
 font-size:50px;
}
#animated_div h1 p
{
 font-size:20px;
}
</style>
</head>
<body>
<div id="wrapper">
 <div id="animated_div">
  <h1>Animated Background Using CSS3</h1>
 </div>
</div>
</body>
</html>