<?php
namespace Dompdf;
require_once 'include_file/dompdf/autoload.inc.php';

if(isset($_POST['submit_val']))
{
$dompdf = new Dompdf(); 
$dompdf->loadHtml('
<table border=1 align=center width=400>
<tr><td>Name : </td><td>'.$_POST['name'].'</td></tr>
<tr><td>Email : </td><td>'.$_POST['email'].'</td></tr>
<tr><td>Age : </td><td>'.$_POST['age'].'</td></tr>
<tr><td>Country : </td><td>'.$_POST['country'].'</td></tr>
</table>
');
$dompdf->setPaper('A4', 'landscape');
$dompdf->render();
$dompdf->stream("",array("Attachment" => false));
exit(0);
}
?>
<html>
<head>
</head>
<body>
<div id="wrapper">

<div id="html_div">
 <form action="htmltopdf_convert.php" method="post">
  <input type="text" name="name" placeholder="Enter Name">
  <br>
  <input type="text" name="email" placeholder="Enter Email">
  <br>
  <input type="text" name="age" placeholder="Enter Age">
  <br>
  <input type="text" name="country" placeholder="Enter Country">
  <br>
  <input type="submit" name="submit_val" value="GENERATE PDF">
 </form>
</div>

</div>
</body>
</html>
<style>
body
{
 margin:0 auto;
 padding:0px;
 text-align:center;
 width:100%;
 font-family: "Myriad Pro","Helvetica Neue",Helvetica,Arial,Sans-Serif;
}
#wrapper
{
 margin:0 auto;
 padding:0px;
 text-align:center;
 width:995px;
}
#wrapper h1
{
 margin-top:50px;
 font-size:45px;
 color:#585858
}
#wrapper h1 p
{
 font-size:18px;
}
#wrapper a
{
 color:blue;
 font-size:20px;
}
#html_div input[type="text"]
{
 margin-top:5px;
 width:250px;
 height:35px;
 padding:10px;
}
#html_div input[type="submit"]
{
 background-color:#585858;
 width:250px;
 height:35px;
 border:none;
 margin-top:5px;
 color:white;
 margin-left:-5px;
}
</style>