<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
 <script>
  $(document).ready(function() 
  {
   $('.text_conainer').hover(function()
   {
    $('.text_div').slideToggle('slow');
   },
   function()
   {
    $('.text_div').slideToggle('slow');
   });
  });
 </script>

</head>
<body>
<div id="wrapper">
 <div class="text_conainer">
  <img src="images/icons-390.jpg"/>
  <div class="text_div">
   <h2>TalkersCode.com</h2>
   <p>Demo Of Sliding Text On Image</p>
  </div>
 </div>
</div>
</body>
</html>
<style>
body
{
 text-align:center;
 width:100%;
 margin:0 auto;
 padding:0px;
 font-family:helvetica;
 background-color:#086A87;
}
#wrapper
{
 text-align:center;
 margin:0 auto;
 padding:0px;
 width:995px;
}
.text_conainer 
{
 width:400px;
 height:300px;
 position: relative;
 margin: 5px;
 margin-left:300px;
 color: #333;
}
.text_conainer img
{
 height:300px;
 width:400px;
}
.text_conainer .text_div 
{
 display: none;
 opacity: 0.8;
 background:#58ACFA;
 width: 400px;
 position: absolute;
 bottom: 0px;
 padding: 5px;
 box-sizing:border-box;
 text-align:center;
 color:white;
}
</style>