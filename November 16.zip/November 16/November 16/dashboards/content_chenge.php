<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
</head>

<body>

<div id="quote_box">
 <p id="quote">Your Content is Initializing Please Wait</p>
</div>

</body>
</html>
<style>
body
{
 background-color:#610B21;
}
#quote_box
{
 margin-top:25%;
 width:70%;
 margin-left:15%;
 background-color:#424242;
 padding:10px;
 border-radius:20px;
 box-shadow:0px 0px 30px 2px #2E2E2E;
}
#quote
{
 font-family:helvetica;
 font-style:italic;
 color:#E6E6E6;
 text-align:center;
 font-size:17px;
}
</style>
<script type="text/javascript">
$(document).ready(function() 
{
 $.ajaxSetup({ cache: false }); 
 setInterval(fetch_quotes,5000);
});

function fetch_quotes()
{
 $.ajax({
 type: 'post',
 url: 'content_chenge.php',
 data: {
  get_quote:"quote"
 },
 success: function (response) {
  document.getElementById("quote").innerHTML='"'+response+'"'; 
 }
 });
}
</script>
<?php
if(isset($_POST['get_quote']))
{
 $quote=array(
  'Learning gives creativity, Creativity leads to thinking, Thinking provides knowledge, Knowledge makes you great.',

  'Man needs his difficulties because they are neccessary to enjoy success.',
 
  'To succeed in your mission, you must have single-minded devotion to your goal.',

  'Dream is not that you see in the sleep; dream is that does not allow you to sleep.',

  'Always bear in mind that your own resolution to succeed is more important than any other.',

  'I am thankful to those who said NO to me. It is because of them i did it myself.',

  'Success is not the key to happiness. Happiness is the key to success. If you love what you are doing, you will be successful.'
 );

 $total=count($quote)-1;
 $var=mt_rand(0,$total);
 echo $quote[$var];
 exit();
}
?>
