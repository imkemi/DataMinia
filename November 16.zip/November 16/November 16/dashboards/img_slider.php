<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>
$(document).ready(function(){
 $( "#prev_image" ).click(function(){
  prev();
 });
 $( "#next_image" ).click(function(){
  next();
 });
});

// Write all the names of images in slideshow
var images = [ "img" , "icons-390" , "img" , "img" ];

function prev()
{
 $( '#slideshow_image' ).fadeOut(300,function()
 {
  var prev_val = document.getElementById( "img_no" ).value;
  var prev_val = Number(prev_val) - 1;
  if(prev_val< = -1)
  {
   prev_val = images.length - 1;
  }
  $( '#slideshow_image' ).attr( 'src' , 'images/'+images[prev_val]+'.jpg' );
  document.getElementById( "img_no" ).value = prev_val;
 });
 $( '#slideshow_image' ).fadeIn(1000);
}

function next()
{
 $( '#slideshow_image' ).fadeOut(300,function()
 {
  var next_val = document.getElementById( "img_no" ).value;
  var next_val = Number(next_val)+1;
  if(next_val >= images.length)
  {
   next_val = 0;
  }
  $( '#slideshow_image' ).attr( 'src' , 'images/'+images[next_val]+'.jpg' );
  document.getElementById( "img_no" ).value = next_val;
 });
 $( '#slideshow_image' ).fadeIn(1000);
}
</script>
</head>
   
<body>

<center>
 <div id="slide_cont">
  <img src="images/img.jpg" id="slideshow_image">
 </div>
 <input type="image" id="prev_image" src="images/previous.png" >
 <input type="image" id="next_image" src="images/next.png" >
 <input type="hidden" id="img_no" value="0">
</center>
  
</body>
</html>
<style>
#slide_cont
{
 box-shadow:0px 0px 10px 0px silver;
 width:600px;
 height:400px;
 margin-top:100px;
}
#slideshow_image
{
 width:600px;
 height:400px;
}
#prev_image,#next_image
{
 width:40px;
 height:40px;
}
</style>
