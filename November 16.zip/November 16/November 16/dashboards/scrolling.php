<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript">
function scroll_to_div(div_id)
{
 $('html,body').animate(
 {
  scrollTop: $("#"+div_id).offset().top
 },
 'slow');
}
</script>
</head>
<body>
<div id="wrapper">

<input type="button" class="scroll_button" value="Scroll To Div1" onclick="scroll_to_div('div1')">
<input type="button" class="scroll_button" value="Scroll To Div2" onclick="scroll_to_div('div2')">
<input type="button" class="scroll_button" value="Scroll To Div3" onclick="scroll_to_div('div3')">

<div id="div1" class="scroll_div">
<h2>DIV 1</h2>
<p>
This is a sample content and This is a demo of Smooth Scrolling Div Using jQuery
This is a sample content and This is a demo of Smooth Scrolling Div Using jQuery
</p>
</div>

<div id="div2" class="scroll_div">
<h2>DIV 2</h2>
<p>
This is a sample content and This is a demo of Smooth Scrolling Div Using jQuery
This is a sample content and This is a demo of Smooth Scrolling Div Using jQuery
</p>
</div>

<div id="div3" class="scroll_div">
<h2>DIV 3</h2>
<p>
This is a sample content and This is a demo of Smooth Scrolling Div Using jQuery
This is a sample content and This is a demo of Smooth Scrolling Div Using jQuery
</p>
</div>
</div>
</body>
</html>
<style>
body
{
 text-align:center;
 width:100%;
 margin:0 auto;
 padding:0px;
 font-family:helvetica;
 background-color:#E6E6E6;
}
#wrapper
{
 text-align:center;
 margin:0 auto;
 padding:0px;
 width:995px;
 height:2000px;
}
.scroll_button
{
 background:none;
 border:1px solid #585858;
 color:#585858;
 width:150px;
 height:35px;
 font-size:16px;
 cursor:pointer;
}
.scroll_div
{
 width:500px;
 border:1px solid;
 margin-left:245px;
 margin-top:50px;
}
</style>