<html>
<head>
<link type="text/css" rel="stylesheet" href="currency_style.css"/>
</head>
<body>
<div id="wrapper">

<div id="convert_div">
<form method="post"action="#">
 <input type="text" name="amount" placeholder="Enter Amount">
 <select name="convert_from">
  <option  value="INR">Indian Rupee</option>
  <option  value="USD">US Dollar</option>
  <option  value="SGD">Singapore Dollar</option>
  <option  value="EUR">Euro</option>
  <option  value="AED">UAE Dirham</option>
 </select>
 <select name="convert_to">
  <option  value="INR">Indian Rupee</option>
  <option  value="USD">US Dollar</option>
  <option  value="SGD">Singapore Dollar</option>
  <option  value="EUR">Euro</option>
  <option  value="AED">UAE Dirham</option>
 </select>
 <br>
 <input type="submit" name="convert_currency" value="Convert Currency">
</form>
</div>

</div>
</body>
</html>
<?php
function currency_converter($from,$to,$amount)
{
 $url = "http://www.google.com/finance/converter?a=$amount&from=$from&to=$to"; 
 
 $request = curl_init(); 
 $timeOut = 0; 
 curl_setopt ($request, CURLOPT_URL, $url); 
 curl_setopt ($request, CURLOPT_RETURNTRANSFER, 1); 
 
 curl_setopt ($request, CURLOPT_USERAGENT,"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)"); 
 curl_setopt ($request, CURLOPT_CONNECTTIMEOUT, $timeOut); 
 $response = curl_exec($request); 
 curl_close($request); 
 
 return $response;
} 

if(isset($_POST['convert_currency']))
{
 $amount=$_POST['amount'];
 $from=$_POST['convert_from'];
 $to=$_POST['convert_to'];
	
 $rawData = currency_converter($from,$to,$amount);
 $regex = '#\<span class=bld\>(.+?)\<\/span\>#s';
 preg_match($regex, $rawData, $converted);
 $result = $converted[0];
 echo $result;
}
?>
<style>
body
{
 margin:0 auto;
 padding:0px;
 text-align:center;
 width:100%;
 font-family: "Myriad Pro","Helvetica Neue",Helvetica,Arial,Sans-Serif;
 background-color:#F79F81;
}
#wrapper
{
 margin:0 auto;
 padding:0px;
 text-align:center;
 width:995px;
}
#wrapper h1
{
 margin-top:50px;
 font-size:45px;
 color:#B43104;
}
#wrapper h1 p
{
 font-size:18px;
}
#convert_div input[type="text"]
{
 width:300px;
 height:55px;
 padding-left:10px;
 font-size:18px;
 margin-bottom:15px;
 color:#424242;
 font-weight:bold;
 border:none;
}
#convert_div select
{
 margin:0px;
 padding:0px;
 width:150px;
 height:55px;
 font-size:15px;
 margin-bottom:15px;
 color:#424242;
 font-weight:bold;
 border:none;
}
#convert_div input[type="submit"]
{
 width:330px;
 height:45px;
 font-size:16px;
 font-weight:bold;
 background-color:#B43104;
 color:white;
 border:none;
 box-shadow:0px 3px 0px 0px #8A2908;
 border-radius:3px;
}
</style>