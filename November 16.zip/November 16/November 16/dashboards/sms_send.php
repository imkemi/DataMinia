<!-- Create a account on http://www.mvaayoo.com/ and get sms api and user id to send text message.They are giving 20 free message and after that they charge some amount per message.-->
<html>
<head>
</head>
<body>
<div id="wrapper">

<div id="sms_div">
 <form method="post" action="sms_send.php">
  <input type="text" name="recievers_no" placeholder="Enter Reciever's No">
  <br>
  <textarea name="message" placeholder="Enter Message Text"></textarea>
  <br>
  <input type="submit" name="send_message" value="SEND MESSAGE">
 </form>
</div>

</div>
</body>
</html>
<?php 
if(isset($_POST['send_message']))
{
 $curl_start = curl_init();
 $user_detail="kamal@jeronone.com:daju143bhauj";
 $receiver_no= $_POST['recievers_no']; 
 $sender_id="TEST SMS";  
 $msg_txt= $_POST['message']; 
 curl_setopt($curl_start,CURLOPT_URL,  "http://api.mVaayoo.com/mvaayooapi/MessageCompose");
 curl_setopt($curl_start, CURLOPT_RETURNTRANSFER, 1);
 curl_setopt($curl_start, CURLOPT_POST, 1);
 curl_setopt($curl_start, CURLOPT_POSTFIELDS, "user=$user_detail&senderID=$sender_id&receipientno=$receiver_no&msgtxt=$msg_txt");
 $buffer = curl_exec($curl_start);
 if(empty ($buffer))
 {
  echo " buffer is empty "; 
 }
 else
 {
  echo $buffer; 
 } 
 curl_close($curl_start);
}
?>
<style>
body
{
 margin:0 auto;
 padding:0px;
 text-align:center;
 width:100%;
 font-family: "Myriad Pro","Helvetica Neue",Helvetica,Arial,Sans-Serif;
 background-color:#01A9DB;
}
#wrapper
{
 margin:0 auto;
 padding:0px;
 text-align:center;
 width:995px;
}
#wrapper h1
{
 margin-top:50px;
 font-size:65px;
}
#wrapper h1 p
{
 font-size:18px;
}
#sms_div input[type="text"]
{
 width:450px;
 height:35px;
 border:none;
 padding-left:10px;
 font-size:17px;
}
#sms_div textarea
{
 width:450px;
 margin-top:5px;
 height:70px;
 border:none;
 padding-left:10px;
 font-size:17px;
}
#sms_div input[type="submit"]
{
 background:none;
 border:1px solid;
 width:200px;
 height:40px;
}
</style>