<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).scroll(function() 
{
 if ($(this).scrollTop() > 1)
 {
  $('#header').addClass("sticky_header");
 }
 else
 {
  $('#header').removeClass("sticky_header");
 }
});
</script>
</head>
<body>

<div id="header" class="big_header">
 <p>TalkersCode Sticky Header</p>
</div>

<div id="wrapper">
 <h1>Sticky Header Using jQuery And CSS</h1>
 <p>Scroll Down To View Changes In Header</p>
</div>

</body>
</html>
<style>
body
{
 text-align:center;
 width:100%;
 margin:0 auto;
 padding:0px;
 font-family:helvetica;
 background-color:#E6E6E6;
}
.big_header
{
 top:0px;
 position:fixed;
 width:100%;
 background-color:#084B8A;
 color:white;
 font-size:40px;
 z-index:2;
 transition: all 0.3s ease;
}
.sticky_header
{
 font-size: 17px;
}
#wrapper
{
 position:relative;
 top:150px;
 text-align:center;
 margin:0 auto;
 padding:0px;
 width:995px;
 height:1000px;
}
h1
{
 margin-top:50px;
 color:#585858;
 font-size:55px;
}
</style>
