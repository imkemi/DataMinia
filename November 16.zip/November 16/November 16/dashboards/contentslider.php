<!DOCTYPE html>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script type="text/javascript">
  function next()
  {
	var mar=$("#img_ul").css("margin-left");
	var nm=mar.replace("px","");
	if(nm==0)
	{
	  $("ul").animate({"marginLeft":"-500px"},"slow");
	}
	else if(nm>0 || nm!=-2000)
	{
	  nm=nm-500;
	  $("ul").animate({"marginLeft":nm+"px"},"slow");
	}
	else if(nm==-2000)
	{
	  $("ul").animate({"marginLeft":"0px"},"slow");
	}
  }

  function previous()
  {
	var mar=$("#img_ul").css("margin-left");
	var nm=mar.replace("px","");
	if(nm==0)
	{
	  $("ul").animate({"marginLeft":"-2000px"},"slow");
	}
	else
	{
	  nm=+nm + +500;
	  $("ul").animate({"marginLeft":nm+"px"},"slow");
	}
  }
  </script>
</head>

<body>

  <div id="slide_wrapper">
    <ul id="img_ul">

     <li>
      <q>
        Learn everything you can, anytime you can, from anyone you can there will always come a time when you will be grateful 
        you did.
      </q>
     </li>

     <li>
      <q>
        Make it simple. Make it memorable. Make it inviting to look at. Make it fun to read.
      </q>
     </li>

     <li>
      <q>
        If plan A fails, remember there are 25 more letters.
      </q>
     </li>

     <li>
      <q>
        Do not go where the path may lead, go instead where there is no path and leave a trail.
      </q>
     </li>

     <li>
      <q>
        A journey of a thousand miles must begin with a single step.
      </q>
     </li>


    </ul>
  </div>

<input type="button" id="previous" value="Previous" onclick="previous();">
<input type="button" id="next" value="Next" onclick="next();">

</body>
</html>
<style>
body
{
	margin:0px auto;
	padding:0px;
	text-align:center;
	background-color:#0B173B;
	font-family:helvetica;
}
#slide_wrapper
{
	margin:0px auto;
	padding:0px;
	background-color:#0B173B;
	margin-top:50px;
	overflow:hidden;
	width:500px;
	height:300px;
	text-align:center;
	border:2px dashed white;
}
ul
{
	margin:0px;
	padding:0px;
}
li
{
	margin:0px;
	padding:0px;
	float:left;
	width:500px;
	height:300px;
	font-family: Copperplate / Copperplate Gothic Light, sans-serif;
	font-style:italic;
	font-size:25px;
	padding:20px;
	padding-top:70px;
	box-sizing:border-box;
	color:white;
}
#previous
{
	margin-top:20px;
	width:150px;
	height:50px;
	background:none;
	color:white;
	border:1px solid white;
	font-size:18px;
}
#next
{
	margin-top:20px;
	width:150px;
	height:50px;
	background:none;
	color:white;
	border:1px solid white;
	font-size:18px;
}
</style>