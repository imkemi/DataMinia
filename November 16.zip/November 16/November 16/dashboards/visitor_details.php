<!-- // Database Structure 
CREATE TABLE `visitor_details` (
 `ip` text NOT NULL,
 `current_page` text NOT NULL,
 `referrer` text NOT NULL,
 `time` text NOT NULL,
 `user_agent` text NOT NULL,
 
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1
-->
<html>
<body>
<div id="wrapper">

<div id="detail_div">
<?php
 $ipaddress = $_SERVER['REMOTE_ADDR'];
 $page = "http://".$_SERVER['HTTP_HOST']."".$_SERVER['PHP_SELF'];
 $referrer = $_SERVER['HTTP_REFERER'];
 $datetime = date("F j, Y, g:i a");
 $useragent = $_SERVER['HTTP_USER_AGENT'];

 echo "<p>IP Address : ".$ipaddress."</p>";
 echo "<p>Current Page : ".$page."</p>";
 echo "<p>Referrer : ".$referrer."</p>";
 echo "<p>Current Time : ".$datetime."</p>";
 echo "<p>Browser : ".$useragent."</p>";

 // $host="localhost";
 // $username="root";
 // $password="";
 // $databasename="sample";
 // $connect=mysql_connect($host,$username,$password);
 // $db=mysql_select_db($databasename);
 
 // mysql_query("insert into visitor_details values('','$ipaddress','$page','$referrer','$datetime','$useragent')");
 
?>
</div>

</div>
</body>
</html>