<html>
<head>
<link rel="stylesheet" href="/dashboards/asset/style.css">
</head>
<body>
<div id="wrapper">
<div id='menu_div'>
<li id="sitename">Kemi</li>
<li><a href="index.php">Home</a></li>
<li><a href="currency_chkker.php">Currency Checker</a></li>
<li><a href="live_priview.php">Live Priview</a></li>
<li><a href="page_load_time.php">Page Load Time</a></li>
<li><a href="onepagewebsite.php">OnePage Site</a></li>
<li><a href="hide_table_coloumn.php">Hide Table Column</a></li>
<li><a href="page_cheche.php">Page Cheche</a></li>
<li><a href="stiky_header.php">Sticky Header</a></li>
<li><a href="short_tbale.php">Short Table</a></li>
<li><a href="alexa_rank.php">Alexa Rank</a></li>
<li><a href="pagination.php">Simple Pagination By Jquery</a></li>
<li><a href="useful_codes.php">Useful Codes</a></li>
<li><a href="useful_links.php">Useful links</a></li>
<li><a href="http://talkerscode.com">Referance</a></li>
</div>

<div id="content">
<table class="table table-bordered table-hover table-striped" style="table-layout: fixed" border="1">
		 <thead>
			 <tr>
				<th></th>
				<th></th>
				<th></th>
					
				
				
			 </tr>
		 </thead>
		 <tbody>
		  <tr>
				<td><h4 id="mytext"><a href="slide_image.php">Slide Text On Image</a></h4></td>
				<td><h4 id="mytext"><a href="csschengebg.php">Chenge Backgroung CSS Animation</a></h4></td>
				<td><h4 id="mytext"><a href="animated_bg.php">Animated Background</a></h4></td>
		 </tr>
		 <tr>
				<td><h4 id="mytext"><a href="rss.php">Rss Feedburner</a></h4></td>	
				<td><h4 id="mytext"><a href="img_priview.php">Image Priview</a></h4></td> 															      
				<td><h4 id="mytext"><a href="tooltip.php">Hover Tooltip</a></h4></td>
		
		 </tr>
		  <tr>
				<td><h4 id="mytext"><a href="highlightword.php">Highlight Word</a></h4></td>	
				<td><h4 id="mytext"><a href="slowdatashow.php">Slow Data Show</a></h4></td> 															      
				<td><h4 id="mytext"><a href="dynamic_table.php">Dynamic Tbale DML</a></h4></td>
		
		 </tr>
		  <tr>
				<td><h4 id="mytext"><a href="multiple_form_leve.php">Multilevel Form</a></h4></td>	
				<td><h4 id="mytext"><a href="longatti.php">Longitude & Latitude</a></h4></td> 															      
				<td><h4 id="mytext"><a href="tabs.php">Muultiple Tabs</a></h4></td> 
		
		 </tr>
		   <tr>
				<td><h4 id="mytext"><a href="sendemail.php">Send Email</a></h4></td> 
				<td><h4 id="mytext"><a href="contentslider.php">Content Slider</a></h4></td> 															      
				<td><h4 id="mytext"><a href="addtocart.php">Add To Cart</a></h4></td> 
		
		 </tr>
		 <tr>
				<td><h4 id="mytext"><a href="mega_menu.php">Mega Menu</a></h4></td> 
				<td><h4 id="mytext"><a href="delete_confermation.php">Delete Confermation Popup</a></h4></td> 															      
				<td><h4 id="mytext"><a href="feedback_button.php">Feedback Form Toggle</a></h4></td> 
		
		 </tr>
		 <tr>
				<td><h4 id="mytext"><a href="share_button.php">Social Media Buttom</a></h4></td> 
				<td><h4 id="mytext"><a href="accordian_menu.php">Accordion Menu</a></h4></td> 															      
				<td><h4 id="mytext"><a href="slide_navigation.php">Slide In & Slide Out Navigation</a></h4></td> 
		
		 </tr>
		  <tr>
				<td><h4 id="mytext"><a href="chaenmge_layout.php">Change Page Layout</a></h4></td> 
				<td><h4 id="mytext"><a href="content_chenge.php">Change Content By Time Schedule</a></h4></td> 															      
				<td><h4 id="mytext"><a href="login_popup.php">Login Popup</a></h4></td> 
		
		 </tr>
		  <tr>
				<td><h4 id="mytext"><a href="image_priview_with_slider.php">Image Priview With Slider(error)</a></h4></td> 
				<td><h4 id="mytext"><a href="img_slider.php">Image Slider (error)</a></h4></td> 															      
				<td><h4 id="mytext"><a href="popup_box.php">Popup Box</a></h4></td> 
		
		 </tr>
		  <tr>
				<td><h4 id="mytext"><a href="drop_down_menu.php">Drop Down Menu</a></h4></td> 
				<td><h4 id="mytext"><a href="mysql_tab_sorting.php">MySQL Tbale Sorting</a></h4></td> 															      
				<td><h4 id="mytext"><a href="floating_naivagtion_menu.php">Floating Navigation Menu</a></h4></td> 
		
		 </tr>
		 <tr>
				<td><h4 id="mytext"><a href="barcode_genreter.php">Barcode Generator</a></h4></td> 
				<td><h4 id="mytext"><a href="htmltopdf_convert.php">HTML To PDF Converter</a></h4></td> 															      
				<td><h4 id="mytext"><a href="custom_error_page.php">Custom Error Page</a></h4></td> 
		
		 </tr>
		  <tr>
				<td><h4 id="mytext"><a href="sms_send.php">Send Text SMS</a></h4></td> 
				<td><h4 id="mytext"><a href="data_in_piechart.php">Data In Pie Chart</a></h4></td> 															      
				<td><h4 id="mytext"><a href="visitor_details.php">Visitor Details On Site</a></h4></td> 
		
		 </tr>
		  <tr>
				<td><h4 id="mytext"><a href="tabs1.php">Pure CSS Tabs Without Script</a></h4></td> 
				<td><h4 id="mytext"><a href="accordian_menu1.php">Accordian Menu</a></h4></td> 
				<td><h4 id="mytext"><a href="magento_bx_slider.html">Magento Bx Slider</a></h4></td> 
		
		 </tr>
		  <tr>
				<td><h4 id="mytext"><a href="currency_converter.php">Currency Converter</a></h4></td> 
				<td><h4 id="mytext"><a href="topic_list.php">Topic List</a></h4></td> 
				<td><h4 id="mytext"><a href="expend_table_row.php">Expend Table Row</a></h4></td> 
		 </tr>
		 <tr>
				<td><h4 id="mytext"><a href="table_hide.php">Show Hide Table Column Using JS</a></h4></td> 
				<td><h4 id="mytext"><a href="scrolling.php">Smooth Scrolling To Div Using jQuery</a></h4></td> 
				<td><h4 id="mytext"><a href="short_order.php">Sort Table Using jQuery</a></h4></td> 
		 </tr>
		  <tr>
				<td><h4 id="mytext"><a href="sliders_collections.php">Sliders (Product,brands,simple)</a></h4></td> 
				<td><h4 id="mytext"><a href="javascript_popup.html">Javascript/jquery popup</a></h4></td> 
				<td><h4 id="mytext"><a href="ajax_loader.php">ajex loader code</a></h4></td> 
		 </tr>
		 </tbody>
		 </table>
</div>
</div>
</body>
</html>

