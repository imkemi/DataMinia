<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<div><h1>USEFUL LINKS</h1>

<div class="content">
<p>http://shopifyexperts.biz/apps/blinds/</p>
</div>

<div class="content">
<h4>online technical blog site</h4>
<p>http://www.iamrohit.in/</p>
<p>http://talkerscode.com/</p>
</div>

<div class="content">
<h4>CDN ICONS USE IN WEBSITE</h4>
<p>https://icons8.com/web-app/533/phone</p>
</div>

<div class="content">
<h4>ONLINE IDE,TERMINAL AND TOTORIALS</h4>
<p>http://www.tutorialspoint.com/codingground.htm</p>
</div>

<div class="content">
<h4>R PROGRAMMING LANGUAGE REFERNCE/ ONLINE TOOLS</h4>
<p>http://tryr.codeschool.com/</p>
</div>

<div class="content">
<h4>MAGENTO LOGIN/ACCONT GET URLS</h4>
<p>https://mayankpatel104.wordpress.com/2012/06/27/how-to-get-the-customer-login-logout-register-and-checkout-url/</p>
<p>https://gist.github.com/thagxt/11212820</p>
</div>

<div class="content">
<h4>How to add static block to left side on magento homepage </h4>
<p>http://www.w3bdeveloper.com/how-to/how-to-add-static-block-to-left-side-on-magento-homepage/</p>
</div>

<div class="content">
<h4>Magento : Get Base Url , Skin Url , Media Url , Js Url , Store Url and Current Url</h4>
<p>http://www.extensionhut.com/blog/magento-get-base-url-skin-url-media-url-js-url-store-url-and-current-url/</p>
</div>

<div class="content">
<h4> Add compare products block to the left column 1.9 rwd theme</h4>
<p>http://magento.stackexchange.com/questions/41228/add-compare-products-block-to-the-left-column-1-9-rwd-theme</p>
</div>

<div class="content">
<h4>How to add logout link in topmenu in header section? </h4>
<p>http://stackoverflow.com/questions/21110345/how-to-add-logout-link-in-topmenu-in-header-section</p>
</div>
<div class="content">
<h4>MAGENTO CONTACT FORM </h4>
<p>http://inchoo.net/magento/contact-form-in-magento/</p>
</div>

<div class="content">
<h4>Magento Bx Custom Slider </h4>
<p>http://bxslider.com/</p>
</div>

<div class="content">
<h4>Magento character limit discription</h4>
<p>http://magento.stackexchange.com/questions/36026/show-excerpt-of-short-description</p>
</div>

<div class="content">
<h4> How to Display WordPress blog posts with Featured Images on Magento’s Homepage using FishPig module </h4>
<p>http://www.milessebesta.com/web-design/how-to-display-wordpress-blog-on-magento/</p>
</div>

<div class="content">
<h4> MEDIA QUERY SIZES</h4>
<p>http://stackoverflow.com/questions/16704243/widths-to-use-in-media-queries</p>
</div>

<div class="content">
<h4>DROP DOWNMENU </h4>
<p>http://red-team-design.com/css3-animated-dropdown-menu/</p>
</div>

<div class="content">
<h4> DOWNLOAD PALCEHOND IMAGES </h4>
<p>https://placehold.it/</p>
</div>

<div class="content">
<h4>Accordian </h4>
<p>http://www.jqueryscript.net/demo/Simple-Responsive-jQuery-Accordion-Plugin-SMK%20Accordion/</p>
</div>

<div class="content">
<h4>Pagination </h4>
<p>http://stackoverflow.com/questions/10034724/simple-jquery-pagination</p>
</div>
<div class="content">
<h4>WP CODE EDITOR PLUGIN </h4>
<p>WPide</p>
</div>

<div class="content">
<h4>Bootstrap Product Slider </h4>
<p>http://www.designerslib.com/bootstrap-product-slider/</p>
</div>

<div class="content">
<h4>MAGENTO Get Realted, Upsell, Cross sell Product collection in magento </h4>
<p>http://krcodex.blogspot.in/2013/06/get-realted-upsell-cross-sell-product.html</p>
</div>
<div class="content">
<h4>WORDPRESS PLUGIN LIST 1</h4>
<p>http://www.alphansotech.com/blogs/learn-wordpress-plugin-development/
http://wordpress.stackexchange.com/questions/66498/add-menu-page-with-different-name-for-first-submenu-item
</p>
</div>
<div class="content">
<h4>WORDPRESS PLUGIN LIST 2</h4>
<p>
http://stackoverflow.com/questions/19197558/insert-custom-field-input-data-from-user-into-wpdb-in-wordpress-without-using-p
http://stackoverflow.com/questions/15185425/wpdb-update-query-not-working
http://mac-blog.org.ua/wordpress-custom-database-table-example-full/</p>
</div>
<div class="content">
<h4>jquery popup window that opens on page load</h4>
<p>http://www.dynamicdrive.com/forums/showthread.php?56899-jquery-popup-window-that-opens-on-page-load</p>
</div>
<div class="content">
<h4>WORDPRESS SITE</h4>
<p>http://iwellnesscenter.com/ 
http://createhealthybabies.com/
http://acupuncturenutrition.com/
http://evergreentx.com/
http://lizlira.com/
http://enhancedfertility.com/</p>
</div>
<div class="content">
<h4>Shopify</h4>
<p>http://cheapwindowblinds.com/
http://billboardflex.com/
http://acupuncturenutrition.com/
https://www.onceuponarun.com.au/
https://jaeluxe.myshopify.com/</p>
</div>
<div class="content">
<h4>Magento</h4>
<p>http://dipit.ca/
http://billboardflex.com/
http://acupuncturenutrition.com/</p>
</div>
<div class="content">
<h4>X-Cart</h4>
<p>http://www.freez.com.au/</p>
</div>
<div class="content">
<h4>Magento free theme url</h4>
<p>http://www.emthemes.com/free-magento-themes/em-charm.html</p>
</div>

</div>
<ol id="pagin">        
</ol>
<script>
var currentpage = 1;
var pagecount = 0;

function showpage(page) {
    $('.content').hide();
    $('.content').eq((page-1)*6).show().next().show().next().show().next().show().next().show().next().show();
    $('#pagin').find('a').removeClass('current').eq(page).addClass('current');

}

$("#pagin").on("click", "a", function(event){
    event.preventDefault();
    if($(this).html() == "next") {
        currentpage++;
    }
    else if($(this).html() == "prev") {
        currentpage--;
    } else {
            currentpage = $(this).html();
    }
    if(currentpage < 1) {currentpage = 1;}
    if(currentpage > pagecount) {currentpage = pagecount;}
    showpage(currentpage);
});                                                                  

$(document).ready(function() {
    pagecount = Math.floor(($('.content').size()) / 6);
    if (($('.content').size()) % 6 > 0) {
        pagecount++;
    }

    $('#pagin').html('<li><a>prev</a></li>');
    for (var i = 1; i <= pagecount; i++) {
        $('#pagin').append('<li><a class="current">' + i + '</a></li>');
    }
    $('#pagin').append('<li><a>next</a></li>');
    showpage(1);

});
</script>
<style>
.content {
    border: 1px solid #adadad;
    margin: 10px 6px;
    padding: 10px;
    float: left;
    width: 350px;
    height: 167px;
    background: #f2f2f233;
    border-radius: 5px;
}
.content h4 {
    margin: 10px 0px;
    text-align: center;
}
.content p {
    margin: 0px;    
    text-align: center;
}
h1 {
    text-transform: uppercase;
    text-align: center;
}

#pagin {
    clear: both;
    padding:0;
    width:250px;
    margin:0 auto;
}
#pagin li {
    float:left;
    margin-right:10px;
	display: inline;
}
#pagin li a {
    display:block;
    color:#717171;
    font:bold 11px;
    text-shadow:0px 1px white;
    padding:5px 8px;
    -webkit-border-radius:3px;
    -moz-border-radius:3px;
    border-radius:3px;
    -webkit-box-shadow:0px 1px 3px 0px rgba(0,0,0,0.35);
    -moz-box-shadow:0px 1px 3px 0px rgba(0,0,0,0.35);
    box-shadow:0px 1px 3px 0px rgba(0,0,0,0.35);
    background:#f9f9f9;
    background:-webkit-linear-gradient(top,#f9f9f9 0%,#e8e8e8 100%);
    background:-moz-linear-gradient(top,#f9f9f9 0%,#e8e8e8 100%);
    background:-o-linear-gradient(top,#f9f9f9 0%,#e8e8e8 100%);
    background:-ms-linear-gradient(top,#f9f9f9 0%,#e8e8e8 100%);
    background:linear-gradient(top,#f9f9f9 0%,#e8e8e8 100%);
    filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#f9f9f9',endColorstr='#e8e8e8',GradientType=0 );
}
#pagin li a.current {
    color:white;
    text-shadow:0px 1px #3f789f;
    -webkit-box-shadow:0px 1px 2px 0px rgba(0,0,0,0.8);
    -moz-box-shadow:0px 1px 2px 0px rgba(0,0,0,0.8);
    box-shadow:0px 1px 2px 0px rgba(0,0,0,0.8);
    background:#7cb9e5;
    background:-webkit-linear-gradient(top,#7cb9e5 0%,#57a1d8 100%);
    background:-moz-linear-gradient(top,#7cb9e5 0%,#57a1d8 100%);
    background:-o-linear-gradient(top,#7cb9e5 0%,#57a1d8 100%);
    background:-ms-linear-gradient(top,#7cb9e5 0%,#57a1d8 100%);
    background:linear-gradient(top,#7cb9e5 0%,#57a1d8 100%);
    filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#7cb9e5',endColorstr='#57a1d8',GradientType=0 );
}
#pagin li a:hover {
    -webkit-box-shadow:0px 1px 3px 0px rgba(0,0,0,0.55);
    -moz-box-shadow:0px 1px 3px 0px rgba(0,0,0,0.55);
    box-shadow:0px 1px 3px 0px rgba(0,0,0,0.55);
    background:#fff;
    background:-webkit-linear-gradient(top,#fff 0%,#e8e8e8 100%);
    background:-moz-linear-gradient(top,#fff 0%,#e8e8e8 100%);
    background:-o-linear-gradient(top,#fff 0%,#e8e8e8 100%);
    background:-ms-linear-gradient(top,#fff 0%,#e8e8e8 100%);
    background:linear-gradient(top,#fff 0%,#e8e8e8 100%);
    filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#fff',endColorstr='#e8e8e8',GradientType=0 );
}
#pagin li a:active,#pagin li a.current:active {
    -webkit-box-shadow:inset 0px 1px 3px 0px rgba(0,0,0,0.5),0px 1px 1px 0px rgba(255,255,255,1) !important;
    -moz-box-shadow:inset 0px 1px 3px 0px rgba(0,0,0,0.5),0px 1px 1px 0px rgba(255,255,255,1) !important;
    box-shadow:inset 0px 1px 3px 0px rgba(0,0,0,0.5),0px 1px 1px 0px rgba(255,255,255,1) !important;
}
#pagin li a.current:hover {
    -webkit-box-shadow:0px 1px 2px 0px rgba(0,0,0,0.9);
    -moz-box-shadow:0px 1px 2px 0px rgba(0,0,0,0.9);
    box-shadow:0px 1px 2px 0px rgba(0,0,0,0.9);
    background:#99cefc;
    background:-webkit-linear-gradient(top,#99cefc 0%,#57a1d8 100%);
    background:-moz-linear-gradient(top,#99cefc 0%,#57a1d8 100%);
    background:-o-linear-gradient(top,#99cefc 0%,#57a1d8 100%);
    background:-ms-linear-gradient(top,#99cefc 0%,#57a1d8 100%);
    background:linear-gradient(top,#99cefc 0%,#57a1d8 100%);
    filter:progid:DXImageTransform.Microsoft.gradient( startColorstr='#99cefc',endColorstr='#57a1d8',GradientType=0 );
}
</style>