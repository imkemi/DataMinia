<html>
<head>
<link rel="stylesheet" type="text/css" href="page_style.css">
</head>
<body>
<div id="wrapper">
<ul>
<li><a href="sliders_collection/demo1.html">Simple Slider (simple or product slider)</a></li>
<li><a href="sliders_collection/demo2.html">Slider 2</a></li>
<li><a href="sliders_collection/demo3.html">Slider 3</a></li>
<li><a href="sliders_collection/demo4.html">Slider 4 (Simple or product silder)</a></li>
<li><a href="sliders_collection/demo5.html">Slider 5 (Tooltip Slider)</a></li>
<li><a href="sliders_collection/demo6.html">Slider 6 (Gallery Slider)</a></li>
<li><a href="sliders_collection/demo7.html">Slider 7 (Product Slider)</a></li>
</ul>
</div>
</body>
</html>
</style>
