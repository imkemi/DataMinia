<html>
   <head>
     <link rel="stylesheet" type="text/css" href="menu_style.css">
   </head>
   
   <body>

     <center>     
     <ul>

        <li id="link1" class="mainlink"><a href="#" class="main_anchor">Link1
           <ol class="link1_sublink">
              
              <li><a href="#">Sublink1</a></li>
              <li><a href="#">Sublink2</a></li>
              <li><a href="#">Sublink3</a></li>
           
           </ol>
        </li>
        <li class="mainlink"><a href="#" class="main_anchor">Link2</a></li>
        <li class="mainlink"><a href="#" class="main_anchor">Link3</a></li>
        <li class="mainlink"><a href="#" class="main_anchor">Link4</a></li>
        <li class="mainlink"><a href="#" class="main_anchor">Link5</a></li>

     </ul>
     </center>     


   </body>
</html>
<style>
ul,ol
{
   margin:0px;
   padding:0px;
   margin-top:180px;
   box-shadow:inset 0px 0px 10px 0px grey;
   text-align:center;
   font-size:24px;
   font-family:helvetica;
   width:150px;
}

li
{
   list-style-type:none;
   height:40px;
   line-height:40px;
   border:1px solid silver;
   border-left:none;
   border-right:none;
}

li:hover
{
   background-color:#819FF7;
   box-shadow:inset 0px 0px 10px 0px #5882FA;
   border:1px solid #5882FA;
   border-left:none;
   border-right:none;
}

li:hover .main_anchor
{
   color:white;
}

li a
{
   display:block;
   color:grey;
   text-decoration:none;
}

.link1_sublink
{
   visibility:hidden;
   display:none;
}

#link1:hover .link1_sublink 
{
   top:0px;
   left:585px;
   position:absolute;
   visibility:visible;
   display:block;
}

.link1_sublink li:hover a
{
   color:white;
}
</style>