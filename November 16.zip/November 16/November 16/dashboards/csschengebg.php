<html>
<head>
<style>
body
{
 text-align:center;
 width:100%;
 margin:0 auto;
 padding:0px;
 font-family:helvetica;
 animation: back_animate 25s infinite linear;
}
@keyframes back_animate 
{
 0%{background-color:#3B240B;} 
 10% {background-color:#FF8000;}
 20%{background-color:#ACFA58;}
 30%{background-color:#298A08;}
 40%{background-color:#81F7D8;}
 50%{background-color:#088A68;}
 60%{background-color:#5882FA;}
 70%{background-color:#0B2161;}
 80%{background-color:#BE81F7;}
 90%{background-color:#170B3B;}
 100%{background-color:#424242;}
}
h1
{
 margin-top:200px;
 color:white;
 font-size:40px;
}
h1 p
{
 font-size:14px;
}
</style>
</head>
<body>

<h1>Change Background With Animation Using CSS3 And HTML</h1>

</body>
</html>