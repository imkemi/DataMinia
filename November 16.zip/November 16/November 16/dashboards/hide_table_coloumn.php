<html>
<head>
<script type="text/javascript">
function hide_show_table(col_name)
{
 var checkbox_val=document.getElementById(col_name).value;
 if(checkbox_val=="hide")
 {
  var all_col=document.getElementsByClassName(col_name);
  for(var i=0;i<all_col.length;i++)
  {
   all_col[i].style.display="none";
  }
  document.getElementById(col_name+"_head").style.display="none";
  document.getElementById(col_name).value="show";
 }
	
 else
 {
  var all_col=document.getElementsByClassName(col_name);
  for(var i=0;i<all_col.length;i++)
  {
   all_col[i].style.display="table-cell";
  }
  document.getElementById(col_name+"_head").style.display="table-cell";
  document.getElementById(col_name).value="hide";
 }
}
</script>
</head>
<body>
<div id="wrapper">

<div id="checkbox_div">
 <p>Show Hide Column</p>
 <li><input type="checkbox" value="hide" id="name_col" onchange="hide_show_table(this.id);">Name</li>
 <li><input type="checkbox" value="hide" id="age_col" onchange="hide_show_table(this.id);">Age</li>
 <li><input type="checkbox" value="hide" id="city_col" onchange="hide_show_table(this.id);">City</li>
</div>

<table id="employee_table" align="center" cellpadding=10>
<tr>
 <th>S.no</th>
 <th id="name_col_head">Name</th>
 <th id="age_col_head">Age</th>
 <th id="city_col_head">City</th>
</tr>

<tr>
 <td>1</td>
 <td class="name_col">Amit</td>
 <td class="age_col">26</td>
 <td class="city_col">Agra</td>
</tr>

<tr>
 <td>2</td>
 <td class="name_col">Rahul</td>
 <td class="age_col">22</td>
 <td class="city_col">Mumbai</td>
</tr>

<tr>
 <td>3</td>
 <td class="name_col">Manoj</td>
 <td class="age_col">31</td>
 <td class="city_col">Delhi</td>
</tr>

<tr>
 <td>4</td>
 <td class="name_col">Rashmi</td>
 <td class="age_col">25</td>
 <td class="city_col">Bhopal</td>
</tr>

<tr>
 <td>5</td>
 <td class="name_col">Shivam</td>
 <td class="age_col">23</td>
 <td class="city_col">Jaipur</td>
</tr>

</table>

</div>
</body>
</html>
<style>
body
{
 text-align:center;
 width:100%;
 margin:0 auto;
 padding:0px;
 font-family:helvetica;
 background-color:#FA8258;
}
#wrapper
{
 text-align:center;
 margin:0 auto;
 padding:0px;
 width:995px;
}
#checkbox_div
{
 width:375px;
 margin-left:309px;
}
#checkbox_div p
{
 margin:5px;
 color:white;
 font-weight:bold;
 font-size:17px;
}
#checkbox_div li
{
 color:white;
 display:inline-block;
 margin:5px;
 font-size:17px;
 font-weight:bold;
}
#checkbox_div input[type="checkbox"]
{
 width:20px;
 height:20px;
}
#employee_table
{
 color:#FE642E;
 background-color:white;
 text-align:center;
}
#employee_table th
{
 border:1px dashed #FE642E;
}
#employee_table td
{
 min-width:70px;
 border:1px dashed #FE642E;
}
</style>
<html>
<body>
<div id="wrapper">
 <form method="post" action="hide_table_coloumn.php">
  <p>Enter Your Name : <input typ="text" name="sender_name"></p>
  <p>Enter Your Email : <input typ="text" name="sender_email"></p>
  <p>Enter Recipient Email : <input typ="text" name="reciever_email"></p>
  <p>Enter Email Subject : <input typ="text" name="subject"></p>
  <p>Enter Message : <textarea id="text" name="message"></textarea></p>
  <p>Select File : <input type="file" name="attach_file"></p>
  <p><input type="submit" name="send_mail" value="Send"></p>
 </form>
</div>
</body>
</html>
<?php
if(isset($_POST['send_mail']))
{
 $name=$_POST['sender_name'];
 $sender_email=$_POST['sender_email'];
 $send_to=$_POST['reciever_email'];
 $subject=$_POST['subject'];
 $message=$_POST['message'];
	
 $attachment=$_FILES["attach_file"]["tmp_name"];
 $folder="files/";
 $file_name=$_FILES["attach_file"]["name"];
 move_uploaded_file($_FILES["attach_file"]["tmp_name"], "$folder".$_FILES["attach_file"]["name"]);
	
 require_once('class.phpmailer.php');	
 $send_mail = new PHPMailer();
 $send_mail->From = $sender_email;
 $send_mail->FromName = $name;
 $send_mail->Subject = $subject;
 $send_mail->Body = $message;
 $send_mail->AddAddress($send_to);

 $attach_file = $folder."".$file_name;
 $send_mail->AddAttachment($attach_file);

 return $send_mail->Send();
}
?>