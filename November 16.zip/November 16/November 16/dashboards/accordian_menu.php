<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script type="text/javascript">
    function paragraph(id)
    {
	   $("#"+id+"-para").slideToggle();
    }
  </script>
</head>

<body>
  <h1>Accordion Menu Using jQuery And CSS</h1>
  <div>

    <li id="li-one" onclick="paragraph(this.id);">First Para Info</li>
    <p id="li-one-para">
      This is just an example of Simple Accordion
      This is just an example of Simple Accordion
      This is just an example of Simple Accordion
    </p>
	
    <li id="li-two" onclick="paragraph(this.id);">Second Para Info</li>
    <p id="li-two-para">
      This is just an example of Simple Accordion
      This is just an example of Simple Accordion
      This is just an example of Simple Accordion
    </p>

    <li id="li-third" onclick="paragraph(this.id);">Third Para Info</li>
    <p id="li-third-para">
      This is just an example of Simple Accordion
      This is just an example of Simple Accordion
      This is just an example of Simple Accordion
    </p>

    <li id="li-fourth" onclick="paragraph(this.id);">Third Para Info</li>
    <p id="li-fourth-para">
      This is just an example of Simple Accordion
      This is just an example of Simple Accordion
      This is just an example of Simple Accordion
    </p>

  </div>
  
</body>
</html>
<style>
body
{
	background-color:#CED8F6;
	font-family:helvetica;
}
h1
{
	text-align:center;
	color:blue;
	margin-top:100px;
}
div
{
	margin:0px auto; 
	width:250px;
}	
div li
{
	background-color:#2E64FE;
	font-size:20px;
	color:white;
	padding:10px;
	cursor:pointer;
	border:1px solid #A4A4A4;
}
div p
{
	display:none;
	background-color:#F2F2F2;
	color:#585858;
	font-size:18px;
	margin:0px;
	padding:10px;
}
</style>