<html>
<div id="code_dicv">
<h1>Image Thumbnail iamge show on main image </h1>
<p>jQuery( document ).ready(function( $ ) {
$('.product-image-thumbs li a img').click(function() {
  var newImage = $(this).attr('src');
  $( '.product-image-gallery img' ).attr({ src: newImage });
 
  return false;
  });
  });</p>
</div>
<div id="code_dicv">
<h1>Email and number validation using jQuiery </h1>
<p>
  jQuery(document).ready(function(){
    jQuery('.formbuilder-form #custom_form .button').click(function(e){

 jQuery('#options_9_text').css('border', '2px solid rgba(235, 235, 235, 1)');
     jQuery('#options_17_text').css('border', '2px solid rgba(235, 235, 235, 1)');

  var phone_val = jQuery('#options_9_text').val();
     var booking_email = jQuery('#options_17_text').val();
      
      if( phone_val.length < 1 || booking_email.length < 1 )
      {
    e.preventDefault();
  if(phone_val.length < 1)
      {
       jQuery('#options_9_text').css('border', '1px solid #ff3333');
      }
      if(booking_email.length < 1)
      {
       jQuery('#options_17_text').css('border', '1px solid #ff3333');
      }
      }
      else {
      
      
      }
      
      if( /(.+)@(.+){2,}\.(.+){2,}/.test(booking_email) ){
  // valid email
  } else {
   e.preventDefault();
   jQuery('#options_17_text').css('border', '1px solid #ff3333'); 
  }
        
    })
	jQuery("#options_9_text").keypress(function(e){
		if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)){return false;}});//number validation
   });
  
</p>
</div>
<div id="code_dicv">
<h1>Cookies set for popup box</h1>
<p>      $(document).ready(function(){
        var check_cookie = $.cookie('select_quiz_delay_popup');
        if(check_cookie == null){
          $.cookie('select_quiz_delay_popup', 'expires_one_day', { expires: 1 });
          //fire your fancybox here
          setTimeout(function(){
            $("#dialog").show();
          }, 200);
        }
        else{         
          
          $("#dialog").css("display","none");     
          $("#mask").css("display","none");  
          
        }
      });
 
  </p>
</div>
</html>
<style>
#code_dicv{
	border:1px solid grey;
	margin:10px 0px;
}
</style>