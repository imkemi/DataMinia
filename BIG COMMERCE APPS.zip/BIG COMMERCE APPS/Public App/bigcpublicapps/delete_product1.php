<?php
/**
 * User: Kamal Kunwar
 * Date: 12/15/14
 * Time: 9:29 PM
 */

include 'appheader.php';
require_once 'vendor/autoload.php';
use Bigcommerce\Api\Client as Bigcommerce;
$ids=$_GET['del'];
$access_token=$_GET['token'];
$store_hash=$_GET['store_hash'];
$client_id=$_GET['client_id'];
$client_ids=$client_id;
Bigcommerce::configure(array(
    'client_id' => $client_id,
    'auth_token' => $access_token,
    'store_hash' => $store_hash
));
Bigcommerce::deleteProduct($ids);	 
echo '<script> alert("Your Product are successfully Deleted");</script>';
echo "<script>window.open('delete_product.php?token=$access_token&store_hash=$store_hash&client_id=$client_ids','_self')</script>";
 
?>


