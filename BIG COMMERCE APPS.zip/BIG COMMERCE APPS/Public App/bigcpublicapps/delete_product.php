<?php
/**
 * User: Kamal Kunwar
 * Date: 12/8/16
 * Time: 9:29 PM
 */
// session_start();
include 'appheader.php';
require_once 'vendor/autoload.php';
use Bigcommerce\Api\Client as Bigcommerce;
$access_token=$_GET['token'];
$store_hash=$_GET['store_hash'];
$client_id=$_GET['client_id'];
// echo $_SESSION['accesstoken'];
// echo $_SESSION['storehash'];
Bigcommerce::configure(array(
    'client_id' => $client_id,
    'auth_token' => $access_token,
    'store_hash' => $store_hash
));
$count = Bigcommerce::getProductsCount()/200;
    for ($i = 1; $i <= $count+1; $i++) {
        $filter = array('limit' => 200, 'page' => $i);
        $products = Bigcommerce::getProducts($filter);     
	
?>
<?php include 'top_header.php'; ?>
<div id="main_border_products">
<h2 style="text-align:center; margin-top: 0px;"> App Store Products</h2>
<table class="table" style="table-layout: fixed">
		 <thead>
			 <tr>
				<th>Product Id</th>
				<th>Product Name</th>
				<th>Product Description</th>
				<th>SKU</th> 
				<th>Price</th>			
				<th>Calculated Price</th>	
				<th>Delete</th>	
				
			 </tr>
		 </thead>
		 <tbody>
		 
		 <?php		 	
		 foreach($products as $value)
		{		      
		    ?>
			 <tr>
			 <td><?php echo $value->id;  ?></td>
			 			 <td><?php echo $value->name;  ?></td>
						 			 <td id="datass"><?php echo $value->description; ?></td>	
										<td><?php echo $value->sku; ?></td>
												<td><?php echo $value->price;  ?></td> 															      
														<td><?php echo $value->calculated_price;  ?></td>
															<td><a href="delete_product1.php?del=<?php echo $value->id; ?>&token=<?php echo $access_token ?>&store_hash=<?php echo $store_hash ?>&client_id=<?php echo $client_id ?>"><button class="mybutton">Delete</button></a></td>
		
		 </tr>
		
	<?php		 
	  }
	   }?>
</table>
</div>

