<?php
/**
 * User: Kamal Kunwar
 * Date: 12/8/16
 * Time: 9:29 PM
 */
include 'appheader.php';
require_once 'vendor/autoload.php';
use Bigcommerce\Api\Client as Bigcommerce;
$access_token=$_GET['token'];
$store_hash=$_GET['store_hash'];
$client_id=$_GET['client_id'];
Bigcommerce::configure(array(
    'client_id' => $client_id,
    'auth_token' => $access_token,
    'store_hash' => $store_hash
));
$count = Bigcommerce::getProductsCount()/200;    	
?>
 <div class="row">
        <div class="col-md-4">     
		     <h3 class="panel-title">Create Product</h3>
                <div class="panel-bodyfef">              
					<form action="create_product1.php" method="post">
                        <fieldset>
                            <div class="form-group">		
                             <input class="pro_id" id="access_token" name="access_token" type="hidden" value="<?php echo $access_token; ?>">
							<input class="pro_id" id="store_hash" name="store_hash" type="hidden" value="<?php echo $store_hash; ?>">
							<input class="pro_id" id="client_id" name="client_id" type="hidden" value="<?php echo $client_id; ?>">							
							<label id="testing">Product Name :</label>
                                <input class="name" id="name" placeholder="Product Name" name="name" type="text" value="" required>
                            </div>                            
							<div class="form-group">
							    <label id="lable"> Product Price</label>                                
								<input class="price" id="price" placeholder="Ex:200" name="price" type="text" value="" required>
                            </div>							
							<div class="form-group">
							<label id="lable" id="lable"> Product Description</label>
							<textarea class="description" id="description" name="description" cols="35" wrap="soft" required></textarea>                           
                            </div>
							<div class="form-group">
								<label id="lable"> Product Type</label>
                                <select class = "sect_type" id="sec_type" name="type">								  
								  <option value = "physical">Physical</option>								 							                          
								</select>
                            </div>
							<div class="form-group">
							<label id="lable"> Product Availability</label>
                               <select class = "availability" id="availability" name="availability">								  
								  <option value = "available">Available</option>								 							                          
								</select>
                            </div> 
                            <div class="form-group">
							    <label id="lable"> Product Weight(Gm)</label>
                                <input class="weight" id="weight" placeholder="Ex: 2.0" name="weight" type="text" value="" required>
                            </div> 
						  <!--  <td><input type="button" id="insertt" class="add_to_cart_btn button btn_style" name="insertt" value = "Update Product"></td>	 -->
						  <input class="mybutton" name="submit" type="submit" value="Update Product">					  
                        </fieldset>
                    </form>
                </div>       
		     </div>		
<div class="col-md-488">
		<table class="table table-bordered table-hover table-striped" style="table-layout: fixed" id="my_tables">
		 <thead>
			 <tr>
				<th>Product Id</th>
				<th>Product Name</th>
				<th>Product Description</th>
				<th>Type</th> 
				<th>Availability</th>
				<th>Weight</th>
				<th>Price</th>	                				
				<th>Calculated Price</th>				
				
			 </tr>
		 </thead>
		 <tbody>
		 <tr>
		
		 <?php
		    for ($i = 1; $i <= $count+1; $i++) {
			$filter = array('limit' => 200, 'page' => $i);
			$products = Bigcommerce::getProducts($filter);   
			 foreach($products as $value)
		{
		?>
			<td><?php echo $value->id;  ?></td>
			<td><?php echo $value->name;  ?></td>
			<td id="datass"><?php echo $value->description; ?></td>	
			<td><?php echo $value->type; ?></td>
			<td><?php echo $value->availability;  ?></td>
			<td><?php echo $value->weight;  ?></td>
			<td><?php echo $value->price;  ?></td> 															      
			<td><?php echo $value->calculated_price;  ?></td>		
		 </tr>
		 <?php		 
		}
			}
	  ?>
		 </tbody>
	</table>
 </div>
</div>




