<?php
/**
 * User: Kamal Kunwar
 * Date: 12/15/16
 * Time: 9:29 PM
 */

$request = $_REQUEST;
require_once 'vendor/autoload.php';
use Bigcommerce\Api\Client as Bigcommerce;
use Bigcommerce\Api\Connection;
$tokenUrl = "https://login.bigcommerce.com/oauth2/token";
$connection = new Connection();
$connection->verifyPeer();
//$connection->useUrlencoded();
$response = $connection->post($tokenUrl, array(
    "client_id" => "spt86qih1i5pavtjzjpcgl6wltf23ev", //I won't type it here but it is correct
    "client_secret" => "qg5320wfs3wwisqsp0f0dtevolm3mh7", //also correct        
    "redirect_uri" => "https://shopifyexperts.biz/apps/blinds/bigcpublicapp/auth.php", //this is the Auth Callback URL
    "grant_type" => "authorization_code",
    "code" => $request["code"], //when I echo these variables out they work
    "scope" => $request["scope"],
    "context" => $request["context"],
	"store_hash" =>$request["store_hash"],
));  

//print_r($response);
	$access_token = $response->{'access_token'};
	$scope = $response->{'scope'};
	$id =  $response->{'user'}->{'id'};
	$email =  $response->{'user'}->{'email'};
	$context = $response->{'context'};
	$hasu_explode =( explode( '/', $context ) );
	$store_hash = $hasu_explode[1]; 
	// $_SESSION['accesstoken'] = $access_token;
	// $_SESSION['storehash'] = $store_hash;
?>
<div id="mainn_div">
<h2 style="text-align:center;" id="main_headrh1"> Welcome To The Public App</h2>
<h3 style="text-align:center;" id="main_headrh4">Store Details</h3>
<table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
		 <thead>
			 <tr>
			    <th>Client Id</th>
				<th>Username</th>
				<th>Access Token</th>
				<th>Scope</th>
				<th>Context</th>				
			 </tr>
		 </thead>
		 <tbody>
		 <tr>
		 <td id="datass"><?php echo $id ?></td>	
		 <td><?php echo $email;  ?></td>
		 <td><?php echo $access_token;  ?></td> 	
		 <td><?php echo $scope;  ?></td> 
		 <td><?php echo $context; ?></td> 		
	</tr> </tbody>
</table>	
		 <?php
print_r($connection->getLastError()); 
?>


<div id="main_div">
<span id="text_span"><a href="get_product.php?token=<?php echo $access_token ?>&store_hash=<?php echo $store_hash ?>"><h4 id="border_box">View Products</h4></a></span>
<span id="text_span"><a href="delete_product.php?token=<?php echo $access_token ?>&store_hash=<?php echo $store_hash ?>"><h4 id="border_box">Delete Products</h4></a></span>
<span id="text_span"><a href="update_product.php?token=<?php echo $access_token ?>&store_hash=<?php echo $store_hash ?>"><h4 id="border_box">Update Products</h4></a></span>
<span id="text_span"><a href="create_product.php?token=<?php echo $access_token ?>&store_hash=<?php echo $store_hash ?>"><h4 id="border_box">Create Products</h4></a></span>
</div>
</div>
<?php
//********************************PUBLIC APP SETUP BY USING PHP CURL *******************************
// $data = array( "client_id" => "spt86qih1i5pavtjzjpcgl6wltf23ev",
                    // "client_secret" => "qg5320wfs3wwisqsp0f0dtevolm3mh7",
                    // "redirect_uri" => "https://shopifyexperts.biz/apps/blinds/bigcpublicapp/auth.php",
                    // "grant_type" => "authorization_code",
                    // "code" => $_GET["code"], "scope" => $_REQUEST["scope"], "context" => $_GET["context"], );

    // $postfields = http_build_query($data);

    // $ch = curl_init();
    // $url = "https://login.bigcommerce.com/oauth2/token";
    // curl_setopt($ch, CURLOPT_URL,$url);
    // curl_setopt($ch, CURLOPT_POST, true);
    // curl_setopt($ch, CURLOPT_POSTFIELDS, $postfields);
    // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // $output = curl_exec ($ch);
    // curl_close ($ch);
	
// $obj = json_decode($output);
//var_dump($obj);
//print_r($obj);
// $access_token = $obj->{'access_token'};
// $scope = $obj->{'scope'};
// $id =  $obj->{'user'}->{'id'};
// $email =  $obj->{'user'}->{'email'};
// $context = $obj->{'context'};
		      
?>
			 <!-- <tr>
			 <td id="datass"><?php //echo $id ?></td>	
			 <td><?php //echo $email;  ?></td>
			 <td><?php //echo $access_token;  ?></td> 	
			 <td><?php //echo $scope;  ?></td> 
			 <td><?php //echo $context; ?></td> 		 
		
		 </tr> -->

<style>
#mainn_div {
    color: rgb(38, 116, 183);
    background: rgb(249, 249, 249) none repeat scroll 0% 0%;
    border: 1px solid rgb(206, 202, 202);
    padding: 10px;
    border-radius: 10px;
	float:left;
}
.table{
	    border: 1px solid rgba(128, 128, 128, 0.39);
 }
.table td {
        border: 1px solid rgba(128, 128, 128, 0.39);
		padding: 20px 10px;
		background: #fff;
}
.table th {
    border: 1px solid rgba(128, 128, 128, 0.39);
    background: #1ca2ec;
    color: #fff;padding: 6px;
}
#text_span{
		float: left;
}
#text_span a {
        text-decoration: none;
}
#border_box {
    background: rgb(28, 162, 236) none repeat scroll 0% 0%;
    border-radius: 5px;
    color: #fff;
    text-decoration: none !important;
    padding: 40px 35px;
    margin-right: 20px;
    font-size: 22px;
}
#border_box:hover {   
    background:rgb(28, 104, 236);    
}
 </style>