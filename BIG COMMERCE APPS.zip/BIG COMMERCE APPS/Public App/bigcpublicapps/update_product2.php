<!-- <table class="table table-bordered table-hover table-striped" style="table-layout: fixed" id="my_tables">
		 <thead>
			 <tr>
				<th>Product Id</th>
				<th>Product Name</th>
				<th>Product Description</th>
				<th>Type</th> 
				<th>Availability</th>
				<th>Weight</th>
				<th>Price</th>	                				
				<th>Calculated Price</th>				
				
			 </tr>
		 </thead>
		 <tbody> -->
<?php
if(isset($_POST['submit'])) 
{ 
             $access_token = $_POST['access_token'];	
			 $store_hash = $_POST['store_hash'];	
			 $client_id = $_POST['client_id'];
			 $pro_id = $_POST['pro_id'];
			 $name = $_POST['name'];		 
			 $price = $_POST['price'];	
			 $description = $_POST['description'];	
			 $sec_type = $_POST['type'];	
			 $availability = $_POST['availability'];			 
			 $weight = $_POST['weight'];
			 	
			 
    }		
		include 'appheader.php';
		require_once 'vendor/autoload.php';
		use Bigcommerce\Api\Client as Bigcommerce;
		 Bigcommerce::configure(array(
					'client_id' =>  $client_id,
					'auth_token' => $access_token,
					'store_hash' => $store_hash
				));	

		 $product = array(
			   'name' => $name,
			   'price' => $price,			   
			   'type' => $sec_type,
			   'availability' =>$availability,
			   'weight' =>$weight,
			   'description'=>$description

			);	
         $result=Bigcommerce::updateProduct($pro_id, $product);		 
		//$result = json_decode($response); 
		//print_r($result); 
		if($result>0){
         echo '<script> alert("Your Product are successfully Updated");</script>';
         echo "<script>window.open('update_product1.php?token=$access_token&store_hash=$store_hash&client_id=$client_id&update_ids=$pro_id','_self')</script>";	
		}
        else{
			   echo '<script> alert("Your Product are Not Updates Deleted");</script>';
			   echo "<script>window.open('update_product1.php?token=$access_token&store_hash=$store_hash&client_id=$client_id&update_ids=$pro_id','_self')</script>";
		}		
 ?>
 
		<!--	<tr>
			<td><?php //echo $result->id;  ?></td>
			<td><?php //echo $result->name;  ?></td>
			<td id="datass"><?php //echo $result->description; ?></td>	
			<td><?php //echo $result->type; ?></td>
			<td><?php //echo $result->availability;  ?></td>
			<td><?php //echo $result->weight;  ?></td>
			<td><?php// echo $result->price;  ?></td> 															      
			<td><?php// echo $result->calculated_price;  ?></td>		
		 </tr>
		 </tbody>
	</table> -->
		
