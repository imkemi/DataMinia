<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
<?php include 'appheader.php' ?>
		<!-- start: Header -->
	<div class="navbar">
		<div class="navbar-inner">
			<?php include 'topheader.php' ?>		
		
	<!-- start: Header -->	
		<div class="container-fluid-full">
		<div class="row-fluid">
			<!-- start: Main Menu -->			
			<!-- end: Main Menu -->			
			<?php include 'left_menu.php'; ?>
			<!-- start: Content -->			
			<div id="content" class="span10" style="min-height: none !important;">	
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Dashboard</a></li>
			</ul>	
			
               <div class="row-fluid">	
				<div class="box blue span12" id="quick-buttons">
					<div class="box-header">
						<h2><i class="halflings-icon hand-top"></i><span class="break"></span>Quick Buttons</h2>
					</div>
					<div class="box-content">
						
						<a class="quick-button span2" href="create_products.php">
							<i class="icon-barcode"></i>
							<p>Create Products</p>
							<span class="notification blue">1267</span>
						</a>
						<a class="quick-button span2" href="view_product.php">
							<i class="icon-barcode"></i>
							<p>View Products</p>							
						</a>
						<a class="quick-button span2" href="delete_upadte_product.php">
							<i class="icon-barcode"></i>
							<p>Update & Detele Products</p>							
						</a>
						
						
						
					</div>	
				</div><!--/span-->
				
			</div>		
			
			</div>
			
       

	</div><!--/.fluid-container-->	
			<!-- end: Content -->			
		</div><!--/#content.span10-->
		</div><!--/fluid-row-->		
	<div class="clearfix"></div>	
	<?php //include 'footer.php'; ?>	
	
</body>
</html>
