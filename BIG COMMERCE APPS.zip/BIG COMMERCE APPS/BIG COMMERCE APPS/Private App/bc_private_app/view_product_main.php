<?php
/**
 * User: Kamal Kunwar
 * Date: 12/15/14
 * Time: 9:29 PM
 */
 require 'vendor/autoload.php';
 use Bigcommerce\Api\Client as Bigcommerce;
Bigcommerce::configure(array(
				'store_url' => 'https://store-phshofok8b.mybigcommerce.com/',
				 'username' => 'legacyapp',
				 'api_key' => 'c413d076d2a135698336e0c04482b952f13b4db4'
			));	
$count = Bigcommerce::getProductsCount()/200;
    for ($i = 1; $i <= $count+1; $i++) {
        $filter = array('limit' => 200, 'page' => $i);
        $products = Bigcommerce::getProducts($filter);      
	 
//$products = Bigcommerce::getProducts();
// echo '<pre>';
// print_r ($products);
 // foreach ($products as $product) {
  // echo $product->name;
  //  echo $product->price;
	 	 
 // }
?>


<table class="table" style="table-layout: fixed">
		 <thead>
			 <tr>
				<th>Product Id</th>
				<th>Product Name</th>
				<th>Product Description</th>
				<th>SKU</th> 
				<th>Price</th>			
				<th>Calculated Price</th>				
				
			 </tr>
		 </thead>
		 <tbody>
		 
		 <?php		 	
		 foreach($products as $value)
		{		      
		    ?>
			 <tr>
			 <td><?php echo $value->id;  ?></td>
			 			 <td><?php echo $value->name;  ?></td>
						 			 <td id="datass"><?php echo $value->description; ?></td>	
										<td><?php echo $value->sku; ?></td>
												<td><?php echo $value->price;  ?></td> 															      
														<td><?php echo $value->calculated_price;  ?></td>
		
		 </tr>
		
	<?php		 
	  }
	   }?>
</table>
<style>
.table{
	    border: 1px solid rgba(128, 128, 128, 0.39);
 }
.table td {
        border: 1px solid rgba(128, 128, 128, 0.39);
}
.table th {
    border: 1px solid rgba(128, 128, 128, 0.39);
    background: #1ca2ec;
    color: #fff;
}
 </style>