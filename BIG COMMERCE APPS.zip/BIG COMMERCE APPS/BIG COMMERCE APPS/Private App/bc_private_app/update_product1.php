<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
<?php include 'appheader.php' ?>
		<!-- start: Header -->
	<div class="navbar">
		<div class="navbar-inner">
			<?php include 'topheader.php' ?>		
		
	<!-- start: Header -->	
		<div class="container-fluid-full">
		<div class="row-fluid" id="row_fluewd">
			<!-- start: Main Menu -->			
			<!-- end: Main Menu -->			
			<?php include 'left_menu.php'; ?>
			<!-- start: Content -->			
			<div id="content" class="span10" style="min-height: none !important;">	
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Delete Product</a></li>
			</ul>	
			
               <div class="row-fluid">	
			   <div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="login-panel panel panel-success">
			<?php		 
			require 'vendor/autoload.php';
			use Bigcommerce\Api\Client as Bigcommerce;
			$ids=$_GET['update_ids'];
			//echo $ids;
			Bigcommerce::configure(array(
				'store_url' => 'https://store-phshofok8b.mybigcommerce.com/',
				 'username' => 'legacyapp',
				 'api_key' => 'c413d076d2a135698336e0c04482b952f13b4db4'
			));		
			$products = Bigcommerce::getProduct($ids);
			//print_r ($products);


 ?>
		    
                <div class="panel-heading">
                    <h3 class="panel-title">Updates Products</h3>
                </div>
                <div class="panel-body">
                    <form role="form" method="post" action="">
                        <fieldset>
                            <div class="form-group">
							<input class="pro_id" id="pro_id" name="pro_id" type="hidden" value="<?php echo $products->id; ?>">
							<label id="testing">Product Name : <?php echo $products->name; ?></label>
                                <input class="name" id="name" placeholder="Product Name" name="name" type="hidden" value="<?php echo $products->name; ?>">
                            </div>                            
							<div class="form-group">
							    <label id="lable"> Product Price</label>
                                <input class="price" id="price" placeholder="Ex:200" name="price" step="1" type="number" value="<?php echo $products->price; ?>">
                            </div>							
							<div class="form-group">
							<label id="lable" id="lable"> Product Description</label>
							<textarea class="description" id="description" name="description" cols="35" wrap="soft"><?php echo $products->description; ?></textarea>                           
                            </div>
							<div class="form-group">
								<label id="lable"> Product Type</label>
                                <select class = "sect_type" id="sec_type" name="type">								  
								  <option value = "physical">Physical</option>								 							                          
								</select>
                            </div>
							<div class="form-group">
							<label id="lable"> Product Availability</label>
                               <select class = "availability" id="availability" name="availability">								  
								  <option value = "available">Available</option>								 							                          
								</select>
                            </div> 
                            <div class="form-group">
							    <label id="lable"> Product Weight(Gm)</label>
                                <input class="weight" id="weight" placeholder="Ex: 2.0" name="weight" type="text" value="<?php echo $products->weight; ?>">
                            </div> 
						   <td><input type="button" id="insertt" class="add_to_cart_btn button btn_style" name="insertt" value = "Update Product"></td>	
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>		
    </div>
</div>
<div id="message"></div>
			
		</div>				
		</div>		
	</div><!--/.fluid-container-->	
			<!-- end: Content -->			
		</div><!--/#content.span10-->
		</div><!--/fluid-row-->		
	<div class="clearfix"></div>	
	<?php include "ajax_loader.php" ?>	
</body>
</html>
<script type="text/javascript">
$(document).ready(function(){
	$("#insertt").click(function(){
	  var pro_id = $("#pro_id").val();
       var name = $("#name").val();       
       var price = $("#price").val();  
       var sec_type= $("#sec_type").val();
       var availability = $("#availability").val();	   
	   var description= $("#description").val();	       
	   var weight = $("#weight").val();
	 if(name !="" && description !="" && weight !=""){		
    $.post('update_product2.php', {pro_id:pro_id, name:name, price:price, sec_type:sec_type, availability:availability, description:description,weight:weight},
    function(data){
        alert('Your Product are successfully Updated'); 
        $("#message").html(data);
        $("#message").hide();
        $("#message").fadeIn(1500);	      
          });  
        }
           else alert('Wrong Input..! Please Input The Correct Values'); 
      });
  });
</script>
<style>
.col-md-4 {
    border: 1px solid #cecece;
    width: 30%;
    padding: 10px 30px;
    background: #f9f9f9;
    border-radius: 5px;
}
#name, #price, #categories, #sec_type, #availability, #weight {
    width: 100%;
    height: 26px;
}
select#sec_type {
    height: 40px;
}
select#availability {
    height: 40px;
}
#description{
	
}
#description {
    width: 97%;
}
#lable {
    font-weight: bold;
}
h3.panel-title {
    text-align: center;
    font-size: 25px;
}
#message{margin-top:2em;}
#insertt {
    padding: 10px;
    background: #1a71d2;
    color: #fff;
    border: 1px solid #1a71d2;
    border-radius: 5px;
}
#insertt:hover{    
    background: #1a98d2;  
    border: 1px solid #1a98d2;    
}
#testing {
    font-weight: bold;
    font-size: 18px;
    margin: 14px 0px;
}
</style>