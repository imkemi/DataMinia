<table class="table table-bordered table-hover table-striped" style="table-layout: fixed" id="my_tables">
		 <thead>
			 <tr>
				<th>Product Id</th>
				<th>Product Name</th>
				<th>Product Description</th>
				<th>Type</th> 
				<th>Availability</th>
				<th>Weight</th>
				<th>Price</th>	                				
				<th>Calculated Price</th>				
				
			 </tr>
		 </thead>
		 <tbody>
<?php
         $pro_id = $_POST['pro_id'];
		 $name = $_POST['name'];		 
		 $price = $_POST['price'];	
         $sec_type = $_POST['sec_type'];	
		 $availability = $_POST['availability'];			 
		 $weight = $_POST['weight'];
		 $description = $_POST['description'];			 		 
		 require 'vendor/autoload.php';
		 use Bigcommerce\Api\Client as Bigcommerce;
		 Bigcommerce::configure(array(
				'store_url' => 'https://store-phshofok8b.mybigcommerce.com/',
				 'username' => 'legacyapp',
				 'api_key' => 'c413d076d2a135698336e0c04482b952f13b4db4'
			));	

		 $product = array(
			   'name' => $name,
			   'price' => $price,			   
			   'type' => $sec_type,
			   'availability' =>$availability,
			   'weight' =>$weight,
			   'description'=>$description

			);	
         $result=Bigcommerce::updateProduct($pro_id, $product);		 
		//$result = json_decode($response); 
		//print_r($result);  
 ?>
			<tr>
			<td><?php echo $result->id;  ?></td>
			<td><?php echo $result->name;  ?></td>
			<td id="datass"><?php echo $result->description; ?></td>	
			<td><?php echo $result->type; ?></td>
			<td><?php echo $result->availability;  ?></td>
			<td><?php echo $result->weight;  ?></td>
			<td><?php echo $result->price;  ?></td> 															      
			<td><?php echo $result->calculated_price;  ?></td>		
		 </tr>
		
<style>
#my_tables th {
    background: #2487cf;
    color: #fff;
}
</style>
