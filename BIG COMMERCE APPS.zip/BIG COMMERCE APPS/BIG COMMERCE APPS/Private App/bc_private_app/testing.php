<?php
/**
 * User: Kamal Kunwar
 * Date: 12/15/14
 * Time: 9:29 PM
 */
require 'vendor/autoload.php';
use Bigcommerce\Api\Client as Bigcommerce;
Bigcommerce::configure(array(
    'store_url' => 'https://store-y4n6vngk09.mybigcommerce.com/',
     'username' => 'kktest',
     'api_key' => 'f7d7df16a97d47cc66167503b3c9672a563905c8'
));

$product = array(
'name' => 'STAR WORLD',
'type' => 'physical',
'description' =>'This timeless fashion staple will never go out of style!',
'price' => '19.99',
'weight' => 2.3,
'categories' => array(18),
'availability' => 'available',
'is_visible' => false
);

 $products = Bigcommerce::createProduct($product);  
?>