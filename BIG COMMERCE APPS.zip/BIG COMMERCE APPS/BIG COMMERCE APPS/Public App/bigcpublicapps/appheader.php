 <html>
<head>
<title>White Blinds</title>
<link rel="stylesheet" href="/billboard/assets/formstyle.css">
        
<!-- start: Meta -->
	<meta charset="utf-8">
	<title>Bigcommerce Public App Header</title>
	<meta name="description" content="Bootstrap Metro Dashboard">
	<meta name="author" content="Dennis Ji">
	<meta name="keyword" content="Metro, Metro UI, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
	<!-- end: Meta -->
	
	<!-- start: Mobile Specific -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- end: Mobile Specific -->
	
	<!-- start: CSS -->
	<link id="bootstrap-style" href="style.css" rel="stylesheet">	
	<!-- end: CSS -->
	
	
</head>
</html>
