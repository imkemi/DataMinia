<?php
				/**
				 * User: Kamal Kunwar
				 * Date: 12/8/16
				 * Time: 9:29 PM
				 */
				// session_start();
				include 'appheader.php';
				require_once 'vendor/autoload.php';
				use Bigcommerce\Api\Client as Bigcommerce;
				$ids=$_GET['update_ids'];
				$access_token=$_GET['token'];
				$store_hash=$_GET['store_hash'];
				$client_id=$_GET['client_id'];
				// echo $_SESSION['accesstoken'];
				// echo $_SESSION['storehash'];
				Bigcommerce::configure(array(
					'client_id' => $client_id,
					'auth_token' => $access_token,
					'store_hash' => $store_hash
				));			
					
			$products = Bigcommerce::getProduct($ids);
			//print_r ($products);


 ?>
 <div class="row">
        <div class="col-md-4">     
		     <h3 class="panel-title">Update Product</h3>
                <div class="panel-bodyfef">              
					<form action="update_product2.php" method="post">
                        <fieldset>
                            <div class="form-group">
							<input class="pro_id" id="access_token" name="access_token" type="hidden" value="<?php echo $access_token; ?>">
							<input class="pro_id" id="store_hash" name="store_hash" type="hidden" value="<?php echo $store_hash; ?>">
							<input class="pro_id" id="client_id" name="client_id" type="hidden" value="<?php echo $client_id; ?>">
							<input class="pro_id" id="pro_id" name="pro_id" type="hidden" value="<?php echo $products->id; ?>">
							<label id="testing">Product Name : <?php echo $products->name; ?></label>
                                <input class="name" id="name" placeholder="Product Name" name="name" type="hidden" value="<?php echo $products->name; ?>">
                            </div>                            
							<div class="form-group">
							    <label id="lable"> Product Price</label>
                                <input class="price" id="price" placeholder="Ex:200" name="price" step="1" type="number" value="<?php echo $products->price; ?>">
                            </div>							
							<div class="form-group">
							<label id="lable" id="lable"> Product Description</label>
							<textarea class="description" id="description" name="description" cols="35" wrap="soft"><?php echo $products->description; ?></textarea>                           
                            </div>
							<div class="form-group">
								<label id="lable"> Product Type</label>
                                <select class = "sect_type" id="sec_type" name="type">								  
								  <option value = "physical">Physical</option>								 							                          
								</select>
                            </div>
							<div class="form-group">
							<label id="lable"> Product Availability</label>
                               <select class = "availability" id="availability" name="availability">								  
								  <option value = "available">Available</option>								 							                          
								</select>
                            </div> 
                            <div class="form-group">
							    <label id="lable"> Product Weight(Gm)</label>
                                <input class="weight" id="weight" placeholder="Ex: 2.0" name="weight" type="text" value="<?php echo $products->weight; ?>">
                            </div> 
						  <!--  <td><input type="button" id="insertt" class="add_to_cart_btn button btn_style" name="insertt" value = "Update Product"></td>	 -->
						  <input class="mybutton" name="submit" type="submit" value="Update Product">					  
                        </fieldset>
                    </form>
                </div>       
		     </div>		
<div class="col-md-48">
		<table class="table table-bordered table-hover table-striped" style="table-layout: fixed" id="my_tables">
		 <thead>
			 <tr>
				<th>Product Id</th>
				<th>Product Name</th>
				<th>Product Description</th>
				<th>Type</th> 
				<th>Availability</th>
				<th>Weight</th>
				<th>Price</th>	                				
				<th>Calculated Price</th>				
				
			 </tr>
		 </thead>
		 <tbody>
		 <tr>
			<td><?php echo $products->id;  ?></td>
			<td><?php echo $products->name;  ?></td>
			<td id="datass"><?php echo $products->description; ?></td>	
			<td><?php echo $products->type; ?></td>
			<td><?php echo $products->availability;  ?></td>
			<td><?php echo $products->weight;  ?></td>
			<td><?php echo $products->price;  ?></td> 															      
			<td><?php echo $products->calculated_price;  ?></td>		
		 </tr>
		 </tbody>
	</table>
 </div>
</div>


