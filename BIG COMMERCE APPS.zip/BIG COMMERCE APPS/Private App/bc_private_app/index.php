<?php
/**
 * Created by PhpStorm.
 * User: Kamal Kunwar
 * Date: 12/8/16
 * Time: 9:29 PM
 */
require 'vendor/autoload.php';
use Bigcommerce\Api\Client as Bigcommerce;
Bigcommerce::configure(array(
    'store_url' => 'https://xyz.mybigcommerce.com/',
     'username' => 'your user name',
     'api_key' => '**********************************'
));

$products = Bigcommerce::getProducts();
echo '<pre>';
print_r ($products);
 foreach ($products as $product) {
    echo $product->name;
    echo $product->price;
	 	 
 }
?>
