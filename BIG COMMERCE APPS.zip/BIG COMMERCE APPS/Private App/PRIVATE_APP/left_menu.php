<div id="sidebar-left" class="span2">
<div class="nav-collapse sidebar-nav">
<ul class="nav nav-tabs nav-stacked main-menu">
	<li><a href="index.php"><i class="icon-bar-chart"></i><span class="hidden-tablet"> Dashboard</span></a></li>
	<li><a href="view_product.php"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> View Product</span></a></li>
	<li><a href="create_products.php"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Create Product</span></a></li>
	<li><a href="delete_upadte_product.php"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Update/Delete Product</span></a></li>	
	<!--<li><a href="get_products.php"><i class="icon-tasks"></i><span class="hidden-tablet"> View Store Product</span></a></li>	
 	<li>
							<a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Update Matrix</span><span class="label label-important" style="display:none"> 2 </span></a>
							<ul>
								<li><a class="submenu" href="product_update.php"><i class="icon-file-alt"></i><span class="hidden-tablet">Table One</span></a></li>
								<li><a class="submenu" href="product_update1.php"><i class="icon-file-alt"></i><span class="hidden-tablet">Table Two</span></a></li>
								<li><a class="submenu" href="product_update_img_sku_price.php"><i class="icon-file-alt"></i><span class="hidden-tablet"> Table One With SKU And Images</span></a></li>
								<li><a class="submenu" href="product_update_img_sku_pricefaux.php"><i class="icon-file-alt"></i><span class="hidden-tablet"> Table One With SKU And Images</span></a></li>
							</ul>	
						</li>	-->
	
</ul>
</div></div>

