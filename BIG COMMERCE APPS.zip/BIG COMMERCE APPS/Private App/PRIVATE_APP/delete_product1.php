<?php
/**
 * User: Kamal Kunwar
 * Date: 12/15/14
 * Time: 9:29 PM
 */
require 'vendor/autoload.php';
use Bigcommerce\Api\Client as Bigcommerce;
$ids=$_GET['del'];
//echo $ids;
Bigcommerce::configure(array(
				'store_url' => 'https://store-phshofok8b.mybigcommerce.com/',
				 'username' => 'legacyapp',
				 'api_key' => 'c413d076d2a135698336e0c04482b952f13b4db4'
			));	

 Bigcommerce::deleteProduct($ids);	 
 echo '<script> alert("Your Product are successfully Deleted"); window.location.href = "delete_upadte_product.php";</script>';
 
?>