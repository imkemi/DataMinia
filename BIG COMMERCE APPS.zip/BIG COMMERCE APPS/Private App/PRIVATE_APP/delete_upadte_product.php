<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
<?php include 'appheader.php' ?>
		<!-- start: Header -->
	<div class="navbar">
		<div class="navbar-inner">
			<?php include 'topheader.php' ?>		
		
	<!-- start: Header -->	
		<div class="container-fluid-full">
		<div class="row-fluid" id="row_fluewd">
			<!-- start: Main Menu -->			
			<!-- end: Main Menu -->			
			<?php include 'left_menu.php'; ?>
			<!-- start: Content -->			
			<div id="content" class="span10" style="min-height: none !important;">	
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Update/Delete Product</a></li>
			</ul>	
			
               <div class="row-fluid">	
			<table class="table table-bordered table-hover table-striped" style="table-layout: fixed" id="my_tables">
		 <thead>
			 <tr>
				<th>Product Id</th>
				<th>Product Name</th>
				<th>Product Description</th>
				<th>SKU</th> 
				<th>Price</th>			
				<th>Calculated Price</th>	
                <th>Delete</th>		
                <th>Update</th>				
				
			 </tr>
		 </thead>
		 <tbody>
		 
		 <?php		 
			require 'vendor/autoload.php';
			use Bigcommerce\Api\Client as Bigcommerce;
			Bigcommerce::configure(array(
				'store_url' => 'https://store-phshofok8b.mybigcommerce.com/',
				 'username' => 'legacyapp',
				 'api_key' => 'c413d076d2a135698336e0c04482b952f13b4db4'
			));			
			$products = Bigcommerce::getProducts();  			
		    foreach($products as $value)
		    {		      
		    ?>
			<tr>
			<td><?php echo $value->id;  ?></td>
			<td><?php echo $value->name;  ?></td>
			<td id="datass"><?php echo $value->description; ?></td>	
			<td><?php echo $value->sku; ?></td>
			<td><?php echo $value->price;  ?></td> 															      
			<td><?php echo $value->calculated_price;  ?></td>
			<td><a href="delete_product1.php?del=<?php echo $value->id; ?>"><button class="btn btn-danger">Delete</button></a></td>
			<td><a href="update_product1.php?update_ids=<?php echo $value->id; ?>"><button class="btn btn-danger">Update</button></a></td>
		
		  </tr>
		
	<?php		 
	  }	
	  ?>	  
		</div>				
		</div>		
	</div><!--/.fluid-container-->	
			<!-- end: Content -->			
		</div><!--/#content.span10-->
		</div><!--/fluid-row-->		
	<div class="clearfix"></div>	
	<?php //include 'footer.php'; ?>	
	
</body>
</html>
<style>
#my_tables th {
    background: #2487cf;
    color: #fff;
}
</style>