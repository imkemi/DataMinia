<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
<?php include 'appheader.php' ?>
		<!-- start: Header -->
	<div class="navbar">
		<div class="navbar-inner">
			<?php include 'topheader.php' ?>		
		
	<!-- start: Header -->	
		<div class="container-fluid-full">
		<div class="row-fluid" id="row_fluewd">
			<!-- start: Main Menu -->			
			<!-- end: Main Menu -->			
			<?php include 'left_menu.php'; ?>
			<!-- start: Content -->			
			<div id="content" class="span10" style="min-height: none !important;">	
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Create Products</a></li>
			</ul>	
			
               <div class="row-fluid">	
			<?php include 'create_products1.php'; ?>					
			</div>		
			
			</div>
			
       

	</div><!--/.fluid-container-->	
			<!-- end: Content -->			
		</div><!--/#content.span10-->
		</div><!--/fluid-row-->		
	<div class="clearfix"></div>	
	<?php //include 'footer.php'; ?>	
	
</body>
</html>
