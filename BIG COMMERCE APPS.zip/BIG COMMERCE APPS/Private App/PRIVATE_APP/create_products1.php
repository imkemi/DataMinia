<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="login-panel panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">Create Products</h3>
                </div>
                <div class="panel-body">
                    <form role="form" method="post" action="">
                        <fieldset>
                            <div class="form-group">
							<label id="lable">Product Name</label>
                                <input class="name" id="name" placeholder="Product Name" name="name" type="text" value="">
                            </div>                            
							<div class="form-group">
							    <label id="lable"> Product Price</label>
                                <input class="price" id="price" placeholder="Ex:200" name="price" step="1" type="number" value="1">
                            </div>
							<div class="form-group">							
                                <input class="categories" placeholder="Ex:Enter Number" name="categories" step="1" type="number" value="1" style="display:none;">
                            </div>
							<div class="form-group">
							<label id="lable" id="lable"> Product Description</label>
							<textarea class="description" id="description" name="description" cols="35" wrap="soft"></textarea>                           
                            </div>
								<div class="form-group">
								<label id="lable"> Product Type</label>
                                <select class = "sect_type" id="sec_type" name="type">								  
								  <option value = "physical">Physical</option>								 							                          
								</select>
                            </div>
							<div class="form-group">
							<label id="lable"> Product Availability</label>
                               <select class = "availability" id="availability" name="availability">								  
								  <option value = "available">Available</option>								 							                          
								</select>
                            </div> 
							
                            <div class="form-group">
							    <label id="lable"> Product Weight(Gm)</label>
                                <input class="weight" id="weight" placeholder="Ex: 2.0" name="weight" type="text" value="">
                            </div> 

                                <!-- <input class="btn btn-lg btn-success btn-block" type="submit" value="create" name="create" > -->								

                            <!-- Change this to a button or input when using this as a form -->
                          <!--  <a href="index.html" class="btn btn-lg btn-success btn-block">Login</a> -->
						   <td><input type="button" id="insertt" class="add_to_cart_btn button btn_style" name="insertt" value = "Create Product"></td>	
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>		
    </div>
</div>
<div id="message"></div>
<?php include "ajax_loader.php" ?>
<script type="text/javascript">
$(document).ready(function(){
	$("#insertt").click(function(){

       var name = $("#name").val();
       var categories = $("#categories").val();
       var price = $("#price").val();       
	   var description= $("#description").val();
	   var sec_type= $("#sec_type").val();
       var availability = $("#availability").val();
	   var weight = $("#weight").val();
	 if(name !="" && description !="" && weight !=""){		
    $.post('create_products2.php', {name:name, categories:categories, price:price, description:description, sec_type:sec_type, availability:availability, weight:weight},
    function(data){
        alert('Your Product Are Successfully Created'); 
        $("#message").html(data);
        $("#message").hide();
        $("#message").fadeIn(1500);	      
          });  
        }
           else alert('Wrong Input..! Please Input The Correct Values'); 
      });
  });
</script>
<style>
.col-md-4 {
    border: 1px solid #cecece;
    width: 30%;
    padding: 10px 30px;
    background: #f9f9f9;
    border-radius: 5px;
}
#name, #price, #categories, #sec_type, #availability, #weight {
    width: 100%;
    height: 26px;
}
select#sec_type {
    height: 40px;
}
select#availability {
    height: 40px;
}
#description{
	
}
#description {
    width: 97%;
}
#lable {
    font-weight: bold;
}
h3.panel-title {
    text-align: center;
    font-size: 25px;
}
#message{margin-top:2em;}
#insertt {
    padding: 10px;
    background: #1a71d2;
    color: #fff;
    border: 1px solid #1a71d2;
    border-radius: 5px;
}
#insertt:hover{    
    background: #1a98d2;  
    border: 1px solid #1a98d2;    
}
</style>