<?php
	session_start();

	require __DIR__.'/vendor/autoload.php';
	use phpish\shopify;

	require __DIR__.'/conf.php';
	ini_set('max_execution_time', 300000);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Import CSV File Data into MySQL Database using PHP by CodexWorld</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="assets/style.css" rel="stylesheet">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style type="text/css">
    .panel-heading a{float: right;}
    #importFrm{margin-bottom: 20px;display: none;}
    #importFrm input[type=file] {display: inline;}
  </style>
</head>
<body>
<?php
	$shopify = shopify\client(SHOPIFY_SHOP, SHOPIFY_APP_API_KEY, SHOPIFY_APP_PASSWORD, true);
	$counts=0;

	try
	{
		# Making an API request can throw an exception
		$products = $shopify('GET /admin/products.json', array('published_status'=>'published'));		
		$products_pro = $shopify('GET /admin/products/count.json', array('published_status'=>'published'));	
		//echo '<pre>';
		//print_r($products);	
if(!empty($_GET['status'])){
    switch($_GET['status']){
        case 'succ':
            $statusMsgClass = 'alert-success';
            $statusMsg = 'Product data has been inserted successfully.';
            break;
        case 'err':
            $statusMsgClass = 'alert-danger';
            $statusMsg = 'Some problem occurred, please try again.';
            break;
        case 'invalid_file':
            $statusMsgClass = 'alert-danger';
            $statusMsg = 'Please upload a valid CSV file.';
            break;
        default:
            $statusMsgClass = '';
            $statusMsg = '';
    }
}
?>
<div class="container">
    <h2 style="text-align:center;">Import CSV File Data In Shopify Store</h2>
    <?php if(!empty($statusMsg)){
        echo '<div class="alert '.$statusMsgClass.'">'.$statusMsg.'</div>';
    } ?>
    <div class="panel panel-default">
        <div class="panel-heading">
            Product list
            <a id="product_import" href="javascript:void(0);" onclick="$('#importFrm').slideToggle();">Import Products</a>
        </div>
        <div class="panel-body">
            <form action="importData.php" method="post" enctype="multipart/form-data" id="importFrm">
                <input type="file" name="file"/>
                <input type="submit" class="btn btn-primary" name="importSubmit" value="IMPORT">
            </form>			
            <table class="table table-bordered">
                <thead>
                    <tr>
                      <th>Product Id</th>					 
                      <th>Product Image</th>					  
                      <th>Product Title</th>
                      <th>Description</th>
                      <th>Product Type</th>
                      <th>Vendor</th>
					  <th>Handle</th>	
					  <th>Price</th>					  
                    </tr>
                </thead>
                <tbody>
				
				<?php
					foreach($products as $key=>$value)
		{			
			?>
			 <tr>
			  <td class="porduct_id_cls"><?php echo $value['id']  ?></td>			  
			<?php  $images=array($value['image']) ;	 
	                foreach($images as $value1){
		
		            echo"<td><div  id='image_div'><img id='images_css' src='".$value1['src']."' alt='product_image'/></div></td>";
	        } ?>
						  
			 	<td class="product_title_cls"><?php echo $value['title']  ?></td>
					<td class="disdcription_cls"><?php echo $value['body_html']  ?></td>									 			 
						<td class="product_type_cls"><?php echo $value['product_type']  ?></td>						  	
							<td class="vendor_cls"><?php echo $value['vendor'] ?></td>
							  <td class="product_handle_cls"><?php echo $value['handle']  ?></td>
								<?php  $vaint = $value['variants'];			
										foreach($vaint as $variantt)
										echo ' <td class="price_cls">'.$variantt['price'].'</td>';?>	  
			</tr>
	<?php	
	     $counts++;
	}
	
			   echo '<p> Total '.$products_pro	.' Products And '.$counts.' In This Page</p>';					
			?>           
                </tbody>
            </table>			
        </div>
    </div>
</div>
<?php
}
	catch (shopify\ApiException $e)
	{
		# HTTP status code was >= 400 or response contained the key 'errors'
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
	catch (shopify\CurlException $e)
	{
		# cURL error
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
?>
</body>
</html>