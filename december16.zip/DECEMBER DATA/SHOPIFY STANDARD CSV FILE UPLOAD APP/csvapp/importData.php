<?php
header('Access-Control-Allow-Origin: *'); 
require __DIR__.'/vendor/autoload.php';
use phpish\shopify;
require __DIR__.'/conf.php';
ini_set('max_execution_time', 300000);
?>
<?php
if(isset($_POST['importSubmit'])){
    
    //validate whether uploaded file is a csv file
    $csvMimes = array('text/plain','text/csv','text/tsv','text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel');
    if(!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'],$csvMimes)){
        if(is_uploaded_file($_FILES['file']['tmp_name'])){
            
            //open uploaded csv file with read only mode
            $csvFile = fopen($_FILES['file']['tmp_name'], 'r');
            
            //skip first line
            fgetcsv($csvFile);
            
            //parse data from csv file line by line
            while(($line = fgetcsv($csvFile)) !== FALSE){
                
                //insert member data into database
                //$db->query("INSERT INTO members (name, email, phone, created, modified, status) VALUES ('".$line[0]."','".$line[1]."','".$line[2]."','".$line[3]."','".$line[3]."','".$line[4]."')");
	$shopify = shopify\client(SHOPIFY_SHOP, SHOPIFY_APP_API_KEY, SHOPIFY_APP_PASSWORD, true);

	try
	{
		# Making an API request can throw an exception
		$product = $shopify('POST /admin/products.json', array(), array
		(
			'product' => array
			(
				"title" => "$line[1]",
				"body_html" => "$line[2]",
				"handle" => "$line[0]",	
				"vendor" => "$line[3]",                			
				"product_type" => "$line[4]",
				"tags" => "$line[5]",                					
				"variants" => array
				(
					array
					(
						
						"title" => "$line[7]",
						"option1" => "$line[8]",
						"price" => "$line[19]",
						"compare_at_price" => "$line[20]",						
						"sku" => "$line[13]",
                        "weight" => "$line[14]",	
                        "inventory_quantity" => "$line[16]",
                        "weight_unit" => "$line[43]",
						"inventory_management" => "$line[15]",
						"inventory_policy" => "$line[17]",
						"fulfillment_service" => "$line[18]",	
                        "requires_shipping" => "$line[21]",
                        "taxable" => "$line[22]",						
												
					)
				),
				"images" => Array
                (
                     Array
                        (
                            "position" => "1",                            
                            "src" =>"$line[24]",
                            "variant_ids" => Array
                                (
                                )

                        )

                ),

             "image" => Array
                (
                    "position" => "1",   
                    "src" =>"$line[24]",
                    "variant_ids" => Array
                        (
                        )

                )
			)
		));
	//	echo '<pre>';
		//print_r($product);
	}

	catch (shopify\ApiException $e)
	{
		# HTTP status code was >= 400 or response contained the key 'errors'
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
	catch (shopify\CurlException $e)
	{
		# cURL error
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
	
	
	
            }
            
            //close opened csv file
            fclose($csvFile);

            $qstring = '?status=succ';
        }else{
            $qstring = '?status=err';
        }
    }else{
        $qstring = '?status=invalid_file';
    }
}

//redirect to the listing page
header("Location: index.php".$qstring);