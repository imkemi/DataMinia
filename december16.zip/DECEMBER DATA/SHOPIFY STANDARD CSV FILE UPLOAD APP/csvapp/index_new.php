<?php
	session_start();

	require __DIR__.'/vendor/autoload.php';
	use phpish\shopify;

	require __DIR__.'/conf.php';
	ini_set('max_execution_time', 300000);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Import CSV File Data into MySQL Database using PHP by CodexWorld</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="assets/style.css" rel="stylesheet">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style type="text/css">
    .panel-heading a{float: right;}
    #importFrm{margin-bottom: 20px;display: none;}
    #importFrm input[type=file] {display: inline;}
  </style>
</head>
<body>
<?php
	$shopify = shopify\client(SHOPIFY_SHOP, SHOPIFY_APP_API_KEY, SHOPIFY_APP_PASSWORD, true);

	try
	{
		# Making an API request can throw an exception
		$products = $shopify('GET /admin/products/count.json', array('published_status'=>'published'));
	    $counts= $products;
        $totalproducts = $shopify('GET /admin/products/count.json', array('published_status'=>'published'));
        $limit =250;
	    $count_product=0;
        $totalpage = ceil(6000/$limit);
	    //$totalpage = ceil(150/$limit);
		?>
    <input type='hidden' id='current_page' />  
    <input type='hidden' id='show_per_page' />
    <div class="container">
    <h2 style="text-align:center;">Import CSV File Data In Shopify Store</h2>
    <?php if(!empty($statusMsg)){
        echo '<div class="alert '.$statusMsgClass.'">'.$statusMsg.'</div>';
    } ?>
    <div class="panel panel-default">
        <div class="panel-heading">
            Product list
            <a id="product_import" href="javascript:void(0);" onclick="$('#importFrm').slideToggle();">Import Products</a>
        </div>
        <div class="panel-body">
            <form action="importData.php" method="post" enctype="multipart/form-data" id="importFrm">
                <input type="file" name="file"/>
                <input type="submit" class="btn btn-primary" name="importSubmit" value="IMPORT">
            </form>				
</div>	
<?php echo '<p id="main_totl_number"> Total '.$counts	.' Products And '.$limit.' In This Page</p>'; ?>
    <div id="content"> 
	<?php
        for($i=1; $i<=$totalpage; $i++){ 
		 $products = $shopify('GET /admin/products.json?limit=250&page='.$i.'', array('published_status'=>'published'));
		//echo '<pre>';
		//print_r($products);	
if(!empty($_GET['status'])){
    switch($_GET['status']){
        case 'succ':
            $statusMsgClass = 'alert-success';
            $statusMsg = 'Product data has been inserted successfully.';
            break;
        case 'err':
            $statusMsgClass = 'alert-danger';
            $statusMsg = 'Some problem occurred, please try again.';
            break;
        case 'invalid_file':
            $statusMsgClass = 'alert-danger';
            $statusMsg = 'Please upload a valid CSV file.';
            break;
        default:
            $statusMsgClass = '';
            $statusMsg = '';
    }
}
?>
<div class="container_inner">    			
            <table class="table table-bordered">
                <thead>
                    <tr>
                      <th>Product Id</th>					 
                      <th>Product Image</th>					  
                      <th>Product Title</th>
                      <th>Description</th>
                      <th>Product Type</th>
                      <th>Vendor</th>
					  <th>Handle</th>	
					  <th>Price</th>					  
                    </tr>
                </thead>
                <tbody>
				
				<?php
					foreach($products as $key=>$value)
		{			
			?>
			 <tr>
			  <td class="porduct_id_cls"><?php echo $value['id']  ?></td>			  
			<?php  $images=array($value['image']) ;	 
	                foreach($images as $value1){
		
		            echo"<td><div  id='image_div'><img id='images_css' src='".$value1['src']."' alt='product_image'/></div></td>";
	        } ?>
						  
			 	<td class="product_title_cls"><?php echo $value['title']  ?></td>
					<td class="disdcription_cls"><?php echo $value['body_html']  ?></td>									 			 
						<td class="product_type_cls"><?php echo $value['product_type']  ?></td>						  	
							<td class="vendor_cls"><?php echo $value['vendor'] ?></td>
							  <td class="product_handle_cls"><?php echo $value['handle']  ?></td>
								<?php  $vaint = $value['variants'];			
										foreach($vaint as $variantt)
										echo ' <td class="price_cls">'.$variantt['price'].'</td>';?>	  
			</tr>
	<?php	
	     $counts++;
	}
	
			   //echo '<p id="main_totl_number"> Total '.$counts	.' Products And '.$limit.' In This Page</p>';					
			?>           
                </tbody>
            </table>			
        </div>

<?php
}
?>
</div><!-- content -->
<div id="pagination_bar"><div id="page_navigation"></div></div>
</div><!-- panel panel-default -->
</div><!-- contentner -->
	<?php }
	catch (shopify\ApiException $e)
	{
		# HTTP status code was >= 400 or response contained the key 'errors'
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
	catch (shopify\CurlException $e)
	{
		# cURL error
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
?>
<script>
	    $(document).ready(function(){  
      
        //how much items per page to show  
        var show_per_page = 1;  
        //getting the amount of elements inside content div  
        var number_of_items = $('#content').children().size();  
        //calculate the number of pages we are going to have  
        var number_of_pages = Math.ceil(number_of_items/show_per_page);  
      
        //set the value of our hidden input fields  
        $('#current_page').val(0);  
        $('#show_per_page').val(show_per_page);  
      
        //now when we got all we need for the navigation let's make it '  
      
        /* 
        what are we going to have in the navigation? 
            - link to previous page 
            - links to specific pages 
            - link to next page 
        */  
        var navigation_html = '<a class="previous_link" href="javascript:previous();">Prev</a>';  
        var current_link = 0;  
        while(number_of_pages > current_link){  
            navigation_html += '<a class="page_link" href="javascript:go_to_page(' + current_link +')" longdesc="' + current_link +'">'+ (current_link + 1) +'</a>';  
            current_link++;  
        }  
        navigation_html += '<a class="next_link" href="javascript:next();">Next</a>';  
      
        $('#page_navigation').html(navigation_html);  
      
        //add active_page class to the first page link  
        $('#page_navigation .page_link:first').addClass('active_page');  
      
        //hide all the elements inside content div  
        $('#content').children().css('display', 'none');  
      
        //and show the first n (show_per_page) elements  
        $('#content').children().slice(0, show_per_page).css('display', 'block');  
      
    });  
      
    function previous(){  
      
        new_page = parseInt($('#current_page').val()) - 1;  
        //if there is an item before the current active link run the function  
        if($('.active_page').prev('.page_link').length==true){  
            go_to_page(new_page);  
        }  
      
    }  
      
    function next(){  
        new_page = parseInt($('#current_page').val()) + 1;  
        //if there is an item after the current active link run the function  
        if($('.active_page').next('.page_link').length==true){  
            go_to_page(new_page);  
        }  
      
    }  
    function go_to_page(page_num){  
        //get the number of items shown per page  
        var show_per_page = parseInt($('#show_per_page').val());  
      
        //get the element number where to start the slice from  
        start_from = page_num * show_per_page;  
      
        //get the element number where to end the slice  
        end_on = start_from + show_per_page;  
      
        //hide all children elements of content div, get specific items and show them  
        $('#content').children().css('display', 'none').slice(start_from, end_on).css('display', 'block');  
      
        /*get the page link that has longdesc attribute of the current page and add active_page class to it 
        and remove that class from previously active page link*/  
        $('.page_link[longdesc=' + page_num +']').addClass('active_page').siblings('.active_page').removeClass('active_page');  
      
        //update the current page input field  
        $('#current_page').val(page_num);  
    }  
	</script>
</body>
</html>