<?php

	define('SHOPIFY_SHOP', 'kamal007.myshopify.com');
	define('SHOPIFY_APP_API_KEY', '491e960711f6cbf8f5a3c966d2de0a7d');
	define('SHOPIFY_APP_PASSWORD', '939ba03cb714df34ddccbde4e247dde2');

?>
