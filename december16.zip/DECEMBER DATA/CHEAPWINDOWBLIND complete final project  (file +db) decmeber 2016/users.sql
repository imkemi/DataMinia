-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 21, 2016 at 05:16 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `users`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `admin_pass` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `basswood_blinds`
--

CREATE TABLE `basswood_blinds` (
  `id` int(11) NOT NULL,
  `height_ft` int(11) NOT NULL,
  `width_ft` int(11) NOT NULL,
  `material_type` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `minimum_price` int(11) NOT NULL,
  `secondary_id` int(11) NOT NULL,
  `sku` varchar(50) DEFAULT 'BASSWOOD',
  `color_box` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `basswood_blinds`
--

INSERT INTO `basswood_blinds` (`id`, `height_ft`, `width_ft`, `material_type`, `price`, `minimum_price`, `secondary_id`, `sku`, `color_box`) VALUES
(0, 36, 24, 'BASSWOOD 2" Blinds', 100, 70, 1001001, 'BASS', 'off'),
(1, 36, 27, 'BASSWOOD 2" Blinds', 2, 70, 1001001, 'BASS', 'off'),
(2, 36, 30, 'BASSWOOD 2" Blinds', 3, 70, 1001001, 'BASS', 'off'),
(3, 36, 33, 'BASSWOOD 2" Blinds', 4, 70, 1001001, 'BASS', 'off'),
(4, 36, 36, 'BASSWOOD 2" Blinds', 5, 70, 1001001, 'BASS', 'off'),
(5, 36, 39, 'BASSWOOD 2" Blinds', 6, 70, 1001001, 'BASS', 'off'),
(6, 36, 42, 'BASSWOOD 2" Blinds', 7, 70, 1001001, 'BASS', 'off'),
(7, 36, 45, 'BASSWOOD 2" Blinds', 8, 70, 1001001, 'BASS', 'off'),
(8, 36, 48, 'BASSWOOD 2" Blinds', 9, 70, 1001001, 'BASS', 'off'),
(9, 36, 51, 'BASSWOOD 2" Blinds', 10, 70, 1001001, 'BASS', 'off'),
(10, 36, 54, 'BASSWOOD 2" Blinds', 11, 70, 1001001, 'BASS', 'off'),
(11, 36, 57, 'BASSWOOD 2" Blinds', 12, 70, 1001001, 'BASS', 'off'),
(12, 36, 60, 'BASSWOOD 2" Blinds', 13, 70, 1001001, 'BASS', 'off'),
(13, 36, 63, 'BASSWOOD 2" Blinds', 14, 70, 1001001, 'BASS', 'off'),
(14, 36, 66, 'BASSWOOD 2" Blinds', 15, 70, 1001001, 'BASS', 'off'),
(15, 36, 69, 'BASSWOOD 2" Blinds', 16, 70, 1001001, 'BASS', 'off'),
(16, 36, 72, 'BASSWOOD 2" Blinds', 17, 70, 1001001, 'BASS', 'off'),
(17, 42, 24, 'BASSWOOD 2" Blinds', 18, 70, 1001001, 'BASS', 'off'),
(18, 42, 27, 'BASSWOOD 2" Blinds', 19, 70, 1001001, 'BASS', 'off'),
(19, 42, 30, 'BASSWOOD 2" Blinds', 21, 70, 1001001, 'BASS', 'off'),
(20, 42, 33, 'BASSWOOD 2" Blinds', 21, 70, 1001001, 'BASS', 'off'),
(21, 42, 36, 'BASSWOOD 2" Blinds', 22, 70, 1001001, 'BASS', 'off'),
(22, 42, 39, 'BASSWOOD 2" Blinds', 23, 70, 1001001, 'BASS', 'off'),
(23, 42, 42, 'BASSWOOD 2" Blinds', 24, 70, 1001001, 'BASS', 'off'),
(24, 42, 45, 'BASSWOOD 2" Blinds', 25, 70, 1001001, 'BASS', 'off'),
(25, 42, 48, 'BASSWOOD 2" Blinds', 26, 70, 1001001, 'BASS', 'off'),
(26, 42, 51, 'BASSWOOD 2" Blinds', 27, 70, 1001001, 'BASS', 'off'),
(27, 42, 54, 'BASSWOOD 2" Blinds', 28, 70, 1001001, 'BASS', 'off'),
(28, 42, 57, 'BASSWOOD 2" Blinds', 29, 70, 1001001, 'BASS', 'off'),
(29, 42, 60, 'BASSWOOD 2" Blinds', 30, 70, 1001001, 'BASS', 'off'),
(30, 42, 63, 'BASSWOOD 2" Blinds', 31, 70, 1001001, 'BASS', 'off'),
(31, 42, 66, 'BASSWOOD 2" Blinds', 32, 70, 1001001, 'BASS', 'off'),
(32, 42, 69, 'BASSWOOD 2" Blinds', 33, 70, 1001001, 'BASS', 'off'),
(33, 42, 72, 'BASSWOOD 2" Blinds', 34, 70, 1001001, 'BASS', 'off'),
(34, 48, 24, 'BASSWOOD 2" Blinds', 35, 70, 1001001, 'BASS', 'off'),
(35, 48, 27, 'BASSWOOD 2" Blinds', 36, 70, 1001001, 'BASS', 'off'),
(36, 48, 30, 'BASSWOOD 2" Blinds', 37, 70, 1001001, 'BASS', 'off'),
(37, 48, 33, 'BASSWOOD 2" Blinds', 38, 70, 1001001, 'BASS', 'off'),
(38, 48, 36, 'BASSWOOD 2" Blinds', 39, 70, 1001001, 'BASS', 'off'),
(39, 48, 39, 'BASSWOOD 2" Blinds', 40, 70, 1001001, 'BASS', 'off'),
(40, 48, 42, 'BASSWOOD 2" Blinds', 41, 70, 1001001, 'BASS', 'off'),
(41, 48, 45, 'BASSWOOD 2" Blinds', 42, 70, 1001001, 'BASS', 'off'),
(42, 48, 48, 'BASSWOOD 2" Blinds', 43, 70, 1001001, 'BASS', 'off'),
(43, 48, 51, 'BASSWOOD 2" Blinds', 44, 70, 1001001, 'BASS', 'off'),
(44, 48, 54, 'BASSWOOD 2" Blinds', 45, 70, 1001001, 'BASS', 'off'),
(45, 48, 57, 'BASSWOOD 2" Blinds', 46, 70, 1001001, 'BASS', 'off'),
(46, 48, 60, 'BASSWOOD 2" Blinds', 47, 70, 1001001, 'BASS', 'off'),
(47, 48, 63, 'BASSWOOD 2" Blinds', 48, 70, 1001001, 'BASS', 'off'),
(48, 48, 66, 'BASSWOOD 2" Blinds', 49, 70, 1001001, 'BASS', 'off'),
(49, 48, 69, 'BASSWOOD 2" Blinds', 50, 70, 1001001, 'BASS', 'off'),
(50, 48, 72, 'BASSWOOD 2" Blinds', 51, 70, 1001001, 'BASS', 'off'),
(51, 54, 24, 'BASSWOOD 2" Blinds', 52, 70, 1001001, 'BASS', 'off'),
(52, 54, 27, 'BASSWOOD 2" Blinds', 53, 70, 1001001, 'BASS', 'off'),
(53, 54, 33, 'BASSWOOD 2" Blinds', 54, 70, 1001001, 'BASS', 'off'),
(54, 54, 33, 'BASSWOOD 2" Blinds', 55, 70, 1001001, 'BASS', 'off'),
(55, 54, 36, 'BASSWOOD 2" Blinds', 56, 70, 1001001, 'BASS', 'off'),
(56, 54, 39, 'BASSWOOD 2" Blinds', 57, 70, 1001001, 'BASS', 'off'),
(57, 54, 42, 'BASSWOOD 2" Blinds', 58, 70, 1001001, 'BASS', 'off'),
(58, 54, 45, 'BASSWOOD 2" Blinds', 59, 70, 1001001, 'BASS', 'off'),
(59, 54, 48, 'BASSWOOD 2" Blinds', 60, 70, 1001001, 'BASS', 'off'),
(60, 54, 51, 'BASSWOOD 2" Blinds', 61, 70, 1001001, 'BASS', 'off'),
(61, 54, 54, 'BASSWOOD 2" Blinds', 62, 70, 1001001, 'BASS', 'off'),
(62, 54, 57, 'BASSWOOD 2" Blinds', 63, 70, 1001001, 'BASS', 'off'),
(63, 54, 60, 'BASSWOOD 2" Blinds', 64, 70, 1001001, 'BASS', 'off'),
(64, 54, 63, 'BASSWOOD 2" Blinds', 65, 70, 1001001, 'BASS', 'off'),
(65, 54, 66, 'BASSWOOD 2" Blinds', 66, 70, 1001001, 'BASS', 'off'),
(66, 54, 69, 'BASSWOOD 2" Blinds', 67, 70, 1001001, 'BASS', 'off'),
(67, 54, 72, 'BASSWOOD 2" Blinds', 68, 70, 1001001, 'BASS', 'off'),
(68, 60, 24, 'BASSWOOD 2" Blinds', 69, 70, 1001001, 'BASS', 'off'),
(69, 60, 27, 'BASSWOOD 2" Blinds', 70, 70, 1001001, 'BASS', 'off'),
(70, 60, 30, 'BASSWOOD 2" Blinds', 71, 70, 1001001, 'BASS', 'off'),
(71, 60, 33, 'BASSWOOD 2" Blinds', 72, 70, 1001001, 'BASS', 'off'),
(72, 60, 36, 'BASSWOOD 2" Blinds', 73, 70, 1001001, 'BASS', 'off'),
(73, 60, 39, 'BASSWOOD 2" Blinds', 74, 70, 1001001, 'BASS', 'off'),
(74, 60, 42, 'BASSWOOD 2" Blinds', 75, 70, 1001001, 'BASS', 'off'),
(75, 60, 45, 'BASSWOOD 2" Blinds', 76, 70, 1001001, 'BASS', 'off'),
(76, 60, 48, 'BASSWOOD 2" Blinds', 77, 70, 1001001, 'BASS', 'off'),
(77, 60, 51, 'BASSWOOD 2" Blinds', 78, 70, 1001001, 'BASS', 'off'),
(78, 60, 54, 'BASSWOOD 2" Blinds', 79, 70, 1001001, 'BASS', 'off'),
(79, 60, 57, 'BASSWOOD 2" Blinds', 80, 70, 1001001, 'BASS', 'off'),
(80, 60, 60, 'BASSWOOD 2" Blinds', 81, 70, 1001001, 'BASS', 'off'),
(81, 60, 63, 'BASSWOOD 2" Blinds', 82, 70, 1001001, 'BASS', 'off'),
(82, 60, 66, 'BASSWOOD 2" Blinds', 83, 70, 1001001, 'BASS', 'off'),
(83, 60, 69, 'BASSWOOD 2" Blinds', 84, 70, 1001001, 'BASS', 'off'),
(84, 60, 72, 'BASSWOOD 2" Blinds', 85, 70, 1001001, 'BASS', 'off'),
(85, 66, 24, 'BASSWOOD 2" Blinds', 86, 70, 1001001, 'BASS', 'off'),
(86, 66, 27, 'BASSWOOD 2" Blinds', 87, 70, 1001001, 'BASS', 'off'),
(87, 66, 30, 'BASSWOOD 2" Blinds', 78, 70, 1001001, 'BASS', 'off'),
(88, 66, 33, 'BASSWOOD 2" Blinds', 88, 70, 1001001, 'BASS', 'off'),
(89, 66, 36, 'BASSWOOD 2" Blinds', 89, 70, 1001001, 'BASS', 'off'),
(90, 66, 39, 'BASSWOOD 2" Blinds', 90, 70, 1001001, 'BASS', 'off'),
(91, 66, 42, 'BASSWOOD 2" Blinds', 91, 70, 1001001, 'BASS', 'off'),
(92, 66, 45, 'BASSWOOD 2" Blinds', 92, 70, 1001001, 'BASS', 'off'),
(93, 66, 48, 'BASSWOOD 2" Blinds', 93, 70, 1001001, 'BASS', 'off'),
(94, 66, 51, 'BASSWOOD 2" Blinds', 94, 70, 1001001, 'BASS', 'off'),
(95, 66, 54, 'BASSWOOD 2" Blinds', 95, 70, 1001001, 'BASS', 'off'),
(96, 66, 57, 'BASSWOOD 2" Blinds', 96, 70, 1001001, 'BASS', 'off'),
(97, 66, 60, 'BASSWOOD 2" Blinds', 97, 70, 1001001, 'BASS', 'off'),
(98, 66, 63, 'BASSWOOD 2" Blinds', 98, 70, 1001001, 'BASS', 'off'),
(99, 66, 66, 'BASSWOOD 2" Blinds', 99, 70, 1001001, 'BASS', 'off'),
(100, 66, 69, 'BASSWOOD 2" Blinds', 100, 70, 1001001, 'BASS', 'off'),
(101, 66, 72, 'BASSWOOD 2" Blinds', 101, 70, 1001001, 'BASS', 'off'),
(102, 72, 24, 'BASSWOOD 2" Blinds', 102, 70, 1001001, 'BASS', 'off'),
(103, 72, 27, 'BASSWOOD 2" Blinds', 103, 70, 1001001, 'BASS', 'off'),
(104, 72, 30, 'BASSWOOD 2" Blinds', 104, 70, 1001001, 'BASS', 'off'),
(105, 72, 33, 'BASSWOOD 2" Blinds', 105, 70, 1001001, 'BASS', 'off'),
(106, 72, 36, 'BASSWOOD 2" Blinds', 106, 70, 1001001, 'BASS', 'off'),
(107, 72, 39, 'BASSWOOD 2" Blinds', 107, 70, 1001001, 'BASS', 'off'),
(108, 72, 42, 'BASSWOOD 2" Blinds', 108, 70, 1001001, 'BASS', 'off'),
(109, 72, 45, 'BASSWOOD 2" Blinds', 109, 70, 1001001, 'BASS', 'off'),
(110, 72, 48, 'BASSWOOD 2" Blinds', 110, 70, 1001001, 'BASS', 'off'),
(111, 72, 51, 'BASSWOOD 2" Blinds', 111, 70, 1001001, 'BASS', 'off'),
(112, 72, 54, 'BASSWOOD 2" Blinds', 112, 70, 1001001, 'BASS', 'off'),
(113, 72, 57, 'BASSWOOD 2" Blinds', 113, 70, 1001001, 'BASS', 'off'),
(114, 72, 60, 'BASSWOOD 2" Blinds', 114, 70, 1001001, 'BASS', 'off'),
(115, 72, 63, 'BASSWOOD 2" Blinds', 115, 70, 1001001, 'BASS', 'off'),
(116, 72, 66, 'BASSWOOD 2" Blinds', 116, 70, 1001001, 'BASS', 'off'),
(117, 72, 69, 'BASSWOOD 2" Blinds', 117, 70, 1001001, 'BASS', 'off'),
(118, 72, 72, 'BASSWOOD 2" Blinds', 118, 70, 1001001, 'BASS', 'off'),
(119, 78, 24, 'BASSWOOD 2" Blinds', 119, 70, 1001001, 'BASS', 'off'),
(120, 78, 27, 'BASSWOOD 2" Blinds', 120, 70, 1001001, 'BASS', 'off'),
(121, 78, 30, 'BASSWOOD 2" Blinds', 121, 70, 1001001, 'BASS', 'off'),
(122, 78, 33, 'BASSWOOD 2" Blinds', 123, 70, 1001001, 'BASS', 'off'),
(123, 78, 36, 'BASSWOOD 2" Blinds', 124, 70, 1001001, 'BASS', 'off'),
(124, 78, 39, 'BASSWOOD 2" Blinds', 125, 70, 1001001, 'BASS', 'off'),
(125, 78, 42, 'BASSWOOD 2" Blinds', 126, 70, 1001001, 'BASS', 'off'),
(126, 78, 45, 'BASSWOOD 2" Blinds', 127, 70, 1001001, 'BASS', 'off'),
(127, 78, 48, 'BASSWOOD 2" Blinds', 128, 70, 1001001, 'BASS', 'off'),
(128, 78, 51, 'BASSWOOD 2" Blinds', 129, 70, 1001001, 'BASS', 'off'),
(129, 78, 54, 'BASSWOOD 2" Blinds', 130, 70, 1001001, 'BASS', 'off'),
(130, 78, 57, 'BASSWOOD 2" Blinds', 131, 70, 1001001, 'BASS', 'off'),
(131, 78, 60, 'BASSWOOD 2" Blinds', 132, 70, 1001001, 'BASS', 'off'),
(132, 78, 63, 'BASSWOOD 2" Blinds', 134, 70, 1001001, 'BASS', 'off'),
(133, 78, 66, 'BASSWOOD 2" Blinds', 135, 70, 1001001, 'BASS', 'off'),
(134, 78, 69, 'BASSWOOD 2" Blinds', 136, 70, 1001001, 'BASS', 'off'),
(135, 78, 72, 'BASSWOOD 2" Blinds', 137, 70, 1001001, 'BASS', 'off'),
(136, 84, 24, 'BASSWOOD 2" Blinds', 138, 70, 1001001, 'BASS', 'off'),
(137, 84, 27, 'BASSWOOD 2" Blinds', 139, 70, 1001001, 'BASS', 'off'),
(138, 84, 30, 'BASSWOOD 2" Blinds', 140, 70, 1001001, 'BASS', 'off'),
(139, 84, 33, 'BASSWOOD 2" Blinds', 141, 70, 1001001, 'BASS', 'off'),
(140, 84, 36, 'BASSWOOD 2" Blinds', 142, 70, 1001001, 'BASS', 'off'),
(141, 84, 39, 'BASSWOOD 2" Blinds', 143, 70, 1001001, 'BASS', 'off'),
(142, 84, 42, 'BASSWOOD 2" Blinds', 144, 70, 1001001, 'BASS', 'off'),
(143, 84, 45, 'BASSWOOD 2" Blinds', 145, 70, 1001001, 'BASS', 'off'),
(144, 84, 48, 'BASSWOOD 2" Blinds', 146, 70, 1001001, 'BASS', 'off'),
(145, 84, 51, 'BASSWOOD 2" Blinds', 147, 70, 1001001, 'BASS', 'off'),
(146, 84, 54, 'BASSWOOD 2" Blinds', 148, 70, 1001001, 'BASS', 'off'),
(147, 84, 57, 'BASSWOOD 2" Blinds', 149, 70, 1001001, 'BASS', 'off'),
(148, 84, 60, 'BASSWOOD 2" Blinds', 150, 70, 1001001, 'BASS', 'off'),
(149, 84, 63, 'BASSWOOD 2" Blinds', 151, 70, 1001001, 'BASS', 'off'),
(150, 84, 66, 'BASSWOOD 2" Blinds', 152, 70, 1001001, 'BASS', 'off'),
(151, 84, 69, 'BASSWOOD 2" Blinds', 153, 70, 1001001, 'BASS', 'off'),
(152, 84, 72, 'BASSWOOD 2" Blinds', 154, 70, 1001001, 'BASS', 'off'),
(153, 90, 24, 'BASSWOOD 2" Blinds', 155, 70, 1001001, 'BASS', 'off'),
(154, 90, 27, 'BASSWOOD 2" Blinds', 156, 70, 1001001, 'BASS', 'off'),
(155, 90, 30, 'BASSWOOD 2" Blinds', 157, 70, 1001001, 'BASS', 'off'),
(156, 90, 33, 'BASSWOOD 2" Blinds', 158, 70, 1001001, 'BASS', 'off'),
(157, 90, 36, 'BASSWOOD 2" Blinds', 159, 70, 1001001, 'BASS', 'off'),
(158, 90, 39, 'BASSWOOD 2" Blinds', 160, 70, 1001001, 'BASS', 'off'),
(159, 90, 42, 'BASSWOOD 2" Blinds', 161, 70, 1001001, 'BASS', 'off'),
(160, 90, 45, 'BASSWOOD 2" Blinds', 163, 70, 1001001, 'BASS', 'off'),
(161, 90, 48, 'BASSWOOD 2" Blinds', 163, 70, 1001001, 'BASS', 'off'),
(162, 90, 51, 'BASSWOOD 2" Blinds', 164, 70, 1001001, 'BASS', 'off'),
(163, 90, 54, 'BASSWOOD 2" Blinds', 156, 70, 1001001, 'BASS', 'off'),
(164, 90, 57, 'BASSWOOD 2" Blinds', 166, 70, 1001001, 'BASS', 'off'),
(165, 90, 60, 'BASSWOOD 2" Blinds', 167, 70, 1001001, 'BASS', 'off'),
(166, 90, 63, 'BASSWOOD 2" Blinds', 168, 70, 1001001, 'BASS', 'off'),
(167, 90, 66, 'BASSWOOD 2" Blinds', 169, 70, 1001001, 'BASS', 'off'),
(168, 90, 69, 'BASSWOOD 2" Blinds', 170, 70, 1001001, 'BASS', 'off'),
(169, 90, 72, 'BASSWOOD 2" Blinds', 171, 70, 1001001, 'BASS', 'off'),
(170, 96, 24, 'BASSWOOD 2" Blinds', 172, 70, 1001001, 'BASS', 'off'),
(171, 96, 27, 'BASSWOOD 2" Blinds', 173, 70, 1001001, 'BASS', 'off'),
(172, 96, 30, 'BASSWOOD 2" Blinds', 174, 70, 1001001, 'BASS', 'off'),
(173, 96, 33, 'BASSWOOD 2" Blinds', 175, 70, 1001001, 'BASS', 'off'),
(174, 96, 36, 'BASSWOOD 2" Blinds', 176, 70, 1001001, 'BASS', 'off'),
(175, 96, 39, 'BASSWOOD 2" Blinds', 177, 70, 1001001, 'BASS', 'off'),
(176, 96, 42, 'BASSWOOD 2" Blinds', 178, 70, 1001001, 'BASS', 'off'),
(177, 96, 45, 'BASSWOOD 2" Blinds', 179, 70, 1001001, 'BASS', 'off'),
(178, 96, 48, 'BASSWOOD 2" Blinds', 180, 70, 1001001, 'BASS', 'off'),
(179, 96, 51, 'BASSWOOD 2" Blinds', 181, 70, 1001001, 'BASS', 'off'),
(180, 96, 54, 'BASSWOOD 2" Blinds', 182, 70, 1001001, 'BASS', 'off'),
(181, 96, 57, 'BASSWOOD 2" Blinds', 183, 70, 1001001, 'BASS', 'off'),
(182, 96, 60, 'BASSWOOD 2" Blinds', 184, 70, 1001001, 'BASS', 'off'),
(183, 96, 63, 'BASSWOOD 2" Blinds', 185, 70, 1001001, 'BASS', 'off'),
(184, 96, 66, 'BASSWOOD 2" Blinds', 186, 70, 1001001, 'BASS', 'off'),
(185, 96, 69, 'BASSWOOD 2" Blinds', 187, 70, 1001001, 'BASS', 'off'),
(186, 96, 72, 'BASSWOOD 2" Blinds', 188, 70, 1001001, 'BASS', 'off');

-- --------------------------------------------------------

--
-- Table structure for table `colors_products`
--

CREATE TABLE `colors_products` (
  `id` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `colours_name` varchar(300) NOT NULL,
  `secondary_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `colors_products`
--

INSERT INTO `colors_products` (`id`, `product_name`, `colours_name`, `secondary_id`) VALUES
(0, 'basswood_blinds', 'Red,Green,Yellow,Pink', 1001001),
(1, 'faux_blinds', 'Red,Green,Yellow,Pink', 1001001);

-- --------------------------------------------------------

--
-- Table structure for table `color_table`
--

CREATE TABLE `color_table` (
  `id` int(11) NOT NULL,
  `products_names` varchar(50) NOT NULL,
  `color_names` varchar(50) NOT NULL,
  `secondary_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `color_table`
--

INSERT INTO `color_table` (`id`, `products_names`, `color_names`, `secondary_id`) VALUES
(0, 'basswood_blinds', 'grey', 1001001),
(1, 'basswood_blinds', 'green', 1001001),
(5, 'basswood_blinds', 'red', 1001001),
(6, 'basswood_blinds', 'yellow', 1001001),
(7, 'basswood_blinds', 'black', 1001001),
(8, 'basswood_blinds', 'brown', 1001001),
(9, 'basswood_blinds', 'redsky', 1001001);

-- --------------------------------------------------------

--
-- Table structure for table `color_table1`
--

CREATE TABLE `color_table1` (
  `id` int(11) NOT NULL,
  `products_names` varchar(50) NOT NULL,
  `color_names` varchar(50) NOT NULL,
  `secondary_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `color_table1`
--

INSERT INTO `color_table1` (`id`, `products_names`, `color_names`, `secondary_id`) VALUES
(0, 'faux_blinds', 'green', 1001001),
(1, 'faux_blinds', 'grey', 1001001),
(6, 'faux_blinds', 'red', 1001001),
(8, 'faux_blinds', 'black', 1001001),
(9, 'faux_blinds', 'pink', 1001001),
(10, 'faux_blinds', 'sky', 1001001),
(11, 'faux_blinds', 'skyblue', 1001001);

-- --------------------------------------------------------

--
-- Table structure for table `faux_blinds`
--

CREATE TABLE `faux_blinds` (
  `id` int(11) NOT NULL,
  `height_ft` int(11) NOT NULL,
  `width_ft` int(11) NOT NULL,
  `material_type` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `minimum_price` int(11) NOT NULL,
  `secondary_id` int(11) NOT NULL,
  `sku` varchar(50) DEFAULT NULL,
  `color_box` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faux_blinds`
--

INSERT INTO `faux_blinds` (`id`, `height_ft`, `width_ft`, `material_type`, `price`, `minimum_price`, `secondary_id`, `sku`, `color_box`) VALUES
(0, 36, 24, 'FAUX 2" Blinds', 1, 75, 1001001, 'FAUX', 'off'),
(1, 36, 27, 'FAUX 2" Blinds', 2, 75, 1001001, 'FAUX', 'off'),
(2, 36, 30, 'FAUX 2" Blinds', 3, 75, 1001001, 'FAUX', 'off'),
(3, 36, 33, 'FAUX 2" Blinds', 4, 75, 1001001, 'FAUX', 'off'),
(4, 36, 36, 'FAUX 2" Blinds', 5, 75, 1001001, 'FAUX', 'off'),
(5, 36, 39, 'FAUX 2" Blinds', 6, 75, 1001001, 'FAUX', 'off'),
(6, 36, 42, 'FAUX 2" Blinds', 7, 75, 1001001, 'FAUX', 'off'),
(7, 36, 45, 'FAUX 2" Blinds', 8, 75, 1001001, 'FAUX', 'off'),
(8, 36, 48, 'FAUX 2" Blinds', 9, 75, 1001001, 'FAUX', 'off'),
(9, 36, 51, 'FAUX 2" Blinds', 10, 75, 1001001, 'FAUX', 'off'),
(10, 36, 54, 'FAUX 2" Blinds', 45, 75, 1001001, 'FAUX', 'off'),
(11, 36, 57, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(12, 36, 60, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(13, 36, 63, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(14, 36, 66, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(15, 36, 69, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(16, 36, 72, 'FAUX 2" Blinds', 6, 75, 1001001, 'FAUX', 'off'),
(17, 42, 24, 'FAUX 2" Blinds', 20, 75, 1001001, 'FAUX', 'off'),
(18, 42, 27, 'FAUX 2" Blinds', 12, 75, 1001001, 'FAUX', 'off'),
(19, 42, 30, 'FAUX 2" Blinds', 35, 75, 1001001, 'FAUX', 'off'),
(20, 42, 33, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(21, 42, 36, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(22, 42, 39, 'FAUX 2" Blinds', 89, 75, 1001001, 'FAUX', 'off'),
(23, 42, 42, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(24, 42, 45, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(25, 42, 48, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(26, 42, 51, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(27, 42, 54, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(28, 42, 57, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(29, 42, 60, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(30, 42, 63, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(31, 42, 66, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(32, 42, 69, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(33, 42, 72, 'FAUX 2" Blinds', 2, 75, 1001001, 'FAUX', 'off'),
(34, 48, 24, 'FAUX 2" Blinds', 30, 75, 1001001, 'FAUX', 'off'),
(35, 48, 27, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(36, 48, 30, 'FAUX 2" Blinds', 78, 75, 1001001, 'FAUX', 'off'),
(37, 48, 33, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(38, 48, 36, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(39, 48, 39, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(40, 48, 42, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(41, 48, 45, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(42, 48, 48, 'FAUX 2" Blinds', 44, 75, 1001001, 'FAUX', 'off'),
(43, 48, 51, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(44, 48, 54, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(45, 48, 57, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(46, 48, 60, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(47, 48, 63, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(48, 48, 66, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(49, 48, 69, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(50, 48, 72, 'FAUX 2" Blinds', 7, 75, 1001001, 'FAUX', 'off'),
(51, 54, 24, 'FAUX 2" Blinds', 40, 75, 1001001, 'FAUX', 'off'),
(52, 54, 27, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(53, 54, 33, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(54, 54, 33, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(55, 54, 36, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(56, 54, 39, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(57, 54, 42, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(58, 54, 45, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(59, 54, 48, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(60, 54, 51, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(61, 54, 54, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(62, 54, 57, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(63, 54, 60, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(64, 54, 63, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(65, 54, 66, 'FAUX 2" Blinds', 12, 75, 1001001, 'FAUX', 'off'),
(66, 54, 69, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(67, 54, 72, 'FAUX 2" Blinds', 2, 75, 1001001, 'FAUX', 'off'),
(68, 60, 24, 'FAUX 2" Blinds', 50, 75, 1001001, 'FAUX', 'off'),
(69, 60, 27, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(70, 60, 30, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(71, 60, 33, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(72, 60, 36, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(73, 60, 39, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(74, 60, 42, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(75, 60, 45, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(76, 60, 48, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(77, 60, 51, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(78, 60, 54, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(79, 60, 57, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(80, 60, 60, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(81, 60, 63, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(82, 60, 66, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(83, 60, 69, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(84, 60, 72, 'FAUX 2" Blinds', 7, 75, 1001001, 'FAUX', 'off'),
(85, 66, 24, 'FAUX 2" Blinds', 30, 75, 1001001, 'FAUX', 'off'),
(86, 66, 27, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(87, 66, 30, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(88, 66, 33, 'FAUX 2" Blinds', 45, 75, 1001001, 'FAUX', 'off'),
(89, 66, 36, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(90, 66, 39, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(91, 66, 42, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(92, 66, 45, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(93, 66, 48, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(94, 66, 51, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(95, 66, 54, 'FAUX 2" Blinds', 66, 75, 1001001, 'FAUX', 'off'),
(96, 66, 57, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(97, 66, 60, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(98, 66, 63, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(99, 66, 66, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(100, 66, 69, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(101, 66, 72, 'FAUX 2" Blinds', 44, 75, 1001001, 'FAUX', 'off'),
(102, 72, 24, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(103, 72, 27, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(104, 72, 30, 'FAUX 2" Blinds', 78, 75, 1001001, 'FAUX', 'off'),
(105, 72, 33, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(106, 72, 36, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(107, 72, 39, 'FAUX 2" Blinds', 78, 75, 1001001, 'FAUX', 'off'),
(108, 72, 42, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(109, 72, 45, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(110, 72, 48, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(111, 72, 51, 'FAUX 2" Blinds', 88, 75, 1001001, 'FAUX', 'off'),
(112, 72, 54, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(113, 72, 57, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(114, 72, 60, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(115, 72, 63, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(116, 72, 66, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(117, 72, 69, 'FAUX 2" Blinds', 5, 75, 1001001, 'FAUX', 'off'),
(118, 72, 72, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(119, 78, 24, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(120, 78, 27, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(121, 78, 30, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(122, 78, 33, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(123, 78, 36, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(124, 78, 39, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(125, 78, 42, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(126, 78, 45, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(127, 78, 48, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(128, 78, 51, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(129, 78, 54, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(130, 78, 57, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(131, 78, 60, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(132, 78, 63, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(133, 78, 66, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(134, 78, 69, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(135, 78, 72, 'FAUX 2" Blinds', 12, 75, 1001001, 'FAUX', 'off'),
(136, 84, 24, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(137, 84, 27, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(138, 84, 30, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(139, 84, 33, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(140, 84, 36, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(141, 84, 39, 'FAUX 2" Blinds', 98, 75, 1001001, 'FAUX', 'off'),
(142, 84, 42, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(143, 84, 45, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(144, 84, 48, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(145, 84, 51, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(146, 84, 54, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(147, 84, 57, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(148, 84, 60, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(149, 84, 63, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(150, 84, 66, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(151, 84, 69, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(152, 84, 72, 'FAUX 2" Blinds', 90, 75, 1001001, 'FAUX', 'off'),
(153, 90, 24, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(154, 90, 27, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(155, 90, 30, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(156, 90, 33, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(157, 90, 36, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(158, 90, 39, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(159, 90, 42, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(160, 90, 45, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(161, 90, 48, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(162, 90, 51, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(163, 90, 54, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(164, 90, 57, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(165, 90, 60, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(166, 90, 63, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(167, 90, 66, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(168, 90, 69, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(169, 90, 72, 'FAUX 2" Blinds', 70, 75, 1001001, 'FAUX', 'off'),
(170, 96, 24, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(171, 96, 27, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(172, 96, 30, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(173, 96, 33, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(174, 96, 36, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(175, 96, 39, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(176, 96, 42, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(177, 96, 45, 'FAUX 2" Blinds', 12, 75, 1001001, 'FAUX', 'off'),
(178, 96, 48, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(179, 96, 51, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(180, 96, 54, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(181, 96, 57, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(182, 96, 60, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(183, 96, 63, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(184, 96, 66, 'FAUX 2" Blinds', 28, 75, 1001001, 'FAUX', 'off'),
(185, 96, 69, 'FAUX 2" Blinds', 32, 75, 1001001, 'FAUX', 'off'),
(186, 96, 72, 'FAUX 2" Blinds', 90, 75, 1001001, 'FAUX', 'off');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `height_ft` int(11) NOT NULL,
  `width_ft` int(11) NOT NULL,
  `material_type` varchar(100) NOT NULL,
  `rates` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `height_ft`, `width_ft`, `material_type`, `rates`) VALUES
(1, 36, 24, 'BASSWOOD 2 Blinds', 28),
(2, 36, 27, 'BASSWOOD 2 Blinds', 32),
(4, 36, 30, 'BASSWOOD 2 Blinds\r\n', 35),
(5, 36, 36, 'BASSWOOD 2 Blinds\r\n', 40),
(6, 36, 39, 'BASSWOOD 2 Blinds\r\n', 44),
(7, 36, 42, 'BASSWOOD 2 Blinds\r\n', 48),
(8, 36, 45, 'BASSWOOD 2 Blinds\r\n', 52),
(9, 36, 48, 'BASSWOOD 2 Blinds\r\n', 55),
(10, 36, 51, 'BASSWOOD 2 Blinds\r\n', 60),
(11, 36, 54, 'BASSWOOD 2 Blinds\r\n', 63),
(12, 36, 57, 'BASSWOOD 2 Blinds\r\n', 72),
(13, 36, 60, 'BASSWOOD 2 Blinds\r\n', 76),
(14, 36, 63, 'BASSWOOD 2 Blinds\r\n', 80),
(15, 36, 66, 'BASSWOOD 2 Blinds\r\n', 84),
(16, 36, 69, 'BASSWOOD 2 Blinds\r\n', 87),
(17, 36, 72, 'BASSWOOD 2 Blinds\r\n', 92),
(18, 42, 24, 'BASSWOOD 2 Blinds\r\n', 31),
(19, 42, 27, 'BASSWOOD 2 Blinds\r\n', 34),
(20, 42, 30, 'BASSWOOD 2 Blinds\r\n', 37),
(21, 42, 33, 'BASSWOOD 2 Blinds\r\n', 40),
(22, 42, 36, 'BASSWOOD 2 Blinds\r\n', 44),
(23, 42, 39, 'BASSWOOD 2 Blinds\r\n', 48),
(24, 42, 42, 'BASSWOOD 2 Blinds\r\n', 52),
(25, 42, 45, 'BASSWOOD 2 Blinds\r\n', 56),
(26, 42, 48, 'BASSWOOD 2 Blinds\r\n', 60),
(27, 42, 51, 'BASSWOOD 2 Blinds\r\n', 64),
(28, 42, 54, 'BASSWOOD 2 Blinds\r\n', 68),
(29, 42, 57, 'BASSWOOD 2 Blinds\r\n', 79),
(30, 42, 60, 'BASSWOOD 2 Blinds\r\n', 82),
(31, 42, 63, 'BASSWOOD 2 Blinds\r\n', 87),
(32, 42, 66, 'BASSWOOD 2 Blinds\r\n', 90),
(33, 42, 69, 'BASSWOOD 2 Blinds\r\n', 93),
(34, 42, 72, 'BASSWOOD 2 Blinds\r\n', 98),
(35, 42, 51, 'BASSWOOD 2 Blinds\r\n', 64),
(36, 42, 54, 'BASSWOOD 2 Blinds\r\n', 68);

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` int(11) NOT NULL,
  `Product Name` varchar(50) NOT NULL,
  `product_image` longblob NOT NULL,
  `secondary_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `Product Name`, `product_image`, `secondary_id`, `name`) VALUES
(0, 'Basswood Blinds', 0xffd8ffe000104a46494600010101006000600000fffe003250726f6365737365642042792065426179207769746820496d6167654d616769636b2c207a312e312e302e207c7c4232ffdb0043000302020302020303030304030304050805050404050a070706080c0a0c0c0b0a0b0b0d0e12100d0e110e0b0b1016101113141515150c0f171816141812141514ffdb00430103040405040509050509140d0b0d1414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414ffc200110800c800c803011100021101031101ffc4001c0000030101010101010000000000000000000102030405060708ffc40017010101010100000000000000000000000000010203ffda000c03010002100310000001fea900000000000000000000000000000828000000000000000000396dc8824889a0215b52318c620244211248964e94ab7956082440219432a9c390025a1244b2cc4b2b07a173da715d4902244201c32863002449225444b3107afae7a9e3358ae6672aa020a72318d6810804a248ad925493e935cfdd4e097e5e6fceb7cbc6950287568c06a208a262564cd3a6b1b7957efef1facd40e45f9e9be3979f26067575400208400665926a631cf5f5bae7efd819af35714aed5446505366565524acc21260ba08b8c8c0fa363d3a0e75f9ecef90c9645110e802442a98421550d77cc8acabe9af3f7ec09316b89688a462004a410b090b2b3189455952c1947bac7b56062bf3f37c32e392032286226b3252092622b428d14334fa7d63e8ec094caeb856ec8551cf0f4690b2419904131800d6e49588f799f6ac0c4f033ae45e79b944908d450499a499ac0a5c4baa352484fabd73fa2a09325e457524d630ec2544ac266419db9e582ba0b92093de67d940c4f9fcef933ac04040ee5da0a4921336a48338aa0d48225faedf3f7ac094caeb901a1039e4bd1cb35290b999912c9c86a38b32a83e8667d340c17e7b3ac3370b4b5112502410490255511251077ea7998aabed35cbdca0839eebc83d04a2579e290208a858a9891462691055be3464bf6971eb20722f859d793a9cdc75d7ab46682a4912434a90482a2c423cb5e23f49df2f7ec085c17cb3857d32d39eaa88924952c021473c694d12e27996fd5ccfaa81ccbf318d724d67444564395588610e9a0a448e92cac49ce9f6fbe7eed8199cc676e708cce65b040000600d60ac09660cebdd99f4400420010806000000048c400234280000000000000000000000000fffc40026100001030403010101010003010000000000010204031213150511142210212306314050ffda0008010100010502ff00e939dfdb8bcbd4bd4bd4bd4bd4c8a5ea64532297a97a97a9914c8a647191c657199e66799de7a2a11abb9d52ba3b27d9f47d1d38fb3a79f67d9d3cfa3e8fa3e8fa3e8fa3e8fa3e8fa3e8fa3e882d72d5928fbbfd0ff43baa7750ff0043ba87fa1f676f3b79dbcfb3b79dbcede76e3b71db8fa3b71f476a76a71c8eee6d5ad44772359a2f2af370a6e8dc9b937486e4dc1b836e6dcdb1b636a6d4da9b53686d0da1b4362e71c63ead56931b732b44bcad011696a914d4a1a84354c444e250d521ab435686b10d621ad435a82f1886b9bd6b505e310a1c7a255ad013bd79ff001ea78637e57efaa95eb355f22b9e8ae7a641e9903a4d63d55cf5563d354f5553d350f5543d2f3d4f3d4e1d2154f51e92957fbab5bfbe944388fba1f8f15a2b533d885885883d8d2c42d2d42d42d42d42d43a42d41c88ab6a16208d41cd431a1013aa1f95aeb6a56988aead2eef4ce3d738f5ce1d2e65bec9a7ae61eb967b251ed927ba41ee907beb9b0aa3a7bd5362e362a32776b5269ef43899292297e3bfeba15a99ad42d42d41ed42d42d42d42d42d42d42d42c42c42a536a894d0c685883d886269c6b51adfca9df55644b6abe4cc3db38f6ce3dd3474e976fbe59ee947ba51ee927ba51ef927be41efae6c6b8ee42a289c8d4362f1b3dc3a72a2ec0e22be76fe2968ad4cd6a16a16a155a82310b10b10b10b10b1056218d0c6854a4d5129a18d0b13a56218d0e39b6b7f2a77d559729aae99290d84c36134d8cc1dc84aeb6328d84a3df24f7c93df2059f20d8573615cd8d61fc85436550d93c49ef51d3dc86c550e1eb67a7f8a2a0e6a5d6a1621621518825342c42c42c42c431a0b4d0c686342a516aae2431218d05a6862438e6db4ff2a77d55972d8e74c9689b09a6c269b09a3b9095d6c259b0947be51b0926c241b0906c6b9b0ac6c6aa0ee42a29b1a86c9e24f7a8b3dc6c54e26a2d5a1f8a7482b7fb621621621529a778d0b10b10b10b10b10c6863431a0ea29912921890c482d34ef121013aa1f9555512a4f94d73a749436528d9ca369285e4e475b4906ce41b3906d241b4ae6d2b9b4ac6cea9b3aa3b92a86cde6d5ea39d52571cbc8be9a6d5c713573c5fc70e4fe324b55f6a1621621529a2ae342c4169a18d0c6863431a18da62416925d8905a2d1cc5752e458a9329daa71dfc8ff922e46d39b232ab9244a672d2d04e52629b3983b9295d6ce59b3966d251b3946d249b3926ce41b3906ceb8bc955ef6754da541393a84a915a4566cba94ce16a2d585f8e2d42447638a7413b6d342c42a534bac42c431a18d0c6863698d0c68624169a5d890c4d31a0fa48a8ea09df1adb637e5757352af252d8abc94c53612cd9cc36b310772b294db4b36b2cdacb3692cd9cb3652cd94b36328d94a179191deca51b2946ca48bc94a17919270f51d561fe38b1056216216218d07d36dd890c6d31b4c4862431a1890c686341d4d3bc6863431a18d05a68424ea87ef47485a85a85886369634b1a58d2c69634b1a58d2c69634c6d31b4c6d3134c4c313046a37ff5ff00ffc4001e11010101000300030101000000000000001100011012202130403150ffda0008010301013f01ff00488f072479393c111f80fab7f4ef922223c1f41eb266666666ed769997967866ed6fcf922222222222223c1cef867d33ed999d99b7c7f62323232322323222222222eb1116fd8cf0ccccf1f3cff2df045d72222222222222222222df2f8666667ea6df1f111919119758c8888888c888e4b7f1b3e1b7c11111111111111111758bac5be5e199999999999999e19b7c17588c8cbae5d722232eb7588c8c8c88ce08b7c3e3e6f9e199fa7fbcefa222eb9111111975cbae5d7222eb975cbae416fa7c333f832c88c8888c8c8c88c8c888c88c8c8c8c8b7d333c7cf2ccccf2cf1f33feafffc40020110003010003010003010100000000000000011112102021300231405060ffda0008010201013f01ff0096bfe4de294a5294a5e94a5294bdff006421084210842108421084213bde2b2b294a5294a5294d14a5297e7084210842108427109d7d3d2b2b2b2b2b2b2b2b2b2b2b2b345294a52f69f28427109d276a56565656565656699a6699a6699a6699a66994a5ed3eb08421084ebe95959595959595959595959a656699a669959a346bf9bce7ceb5f1a6699a6699a65656699a6699a6699a6699a6699a6699a62f87855f0bc421e1084eacacacd334cd32b2b2b2b2b2b34cd33468d336c4cd313bfc7e1e73fa2764f8db34cd334cd334cd334cd334cd334cd334cd334cd334cd3175852f59da978a52f0fa7a5fc8d334cdb37f91a6699a6699a6699a656699a6699a66d9a66989dfaf879f2f3fd5ffc4003b10000102030604020707030500000000000001023134920311123391e11020213241810422426171a1a2131430517293d12340624350a3b1c1ffda0008010100063f02ff007389122448a91522a4548915224489dca44ee53b94ee53b94ee53b94ee3b8b956f3a5da9e1a9e1a9e1a9e1a9e1a9e1a9e1a9e1a9e1a9e1a9e1a9e1a9e1a9b9bf2438408102f5f04130b51c6534ca6996d329a6534cb6996d329a6534cb432da65b4cb432d0cb432d0cb432d0cb432d0cb4328ca1cb870a08e6331b4eb6577c48335dcff4eadceeb2ab73bacaa4fe4eeb2ab73bac6b4fe48d955b91b3a88d9d446cea2367511b3a88d9d4459511b3a8f62a3d8a8f62a3d8a8f62a3d8a8e8c45f838573db859e1c1080d6dde2abff44081017d5890204081020408103b481018b74148102d1bfe77f1e971d2c9aa64b6ff008990dd4c86ea4bb6a12fb044b9618a24bb6a3213532135321353212a323e6647ccc9f9990ba8d5fb25f85e64aea64a8dfe92a7532d4cb70e7dd8515795dfa53ff7912f4fc28439605defe3ea9eaa3342fbacf1ddd7a2c0edb2d17f93b6ca95fe4ecb2d17f93ab2cefbfa74532ecb4532ecfe665d9994c325ba992dd4c86d464254647d422ad8f96232175321da977d9393ccca7196f1f7355b73bc7957f4f2274e7810e09c21c8fbbf3e3d0f55966bf1452ffb3b3c7e665597cccab2f999365f32f5b2b3e9f13219f33219aa992cd4c866a6432a5321b512edab625d2bd896faf61aabe8fe58897fa8975d4c85d4c976a64bcb45c2adeb775e5f2fe391bd3840873a722f07ddf9f1e87ab62c5f352ffb0662fd4a4b32a525acea525595297afa3b12e5862892cca897655b12edab6259b5ec4b257b12c95ec4b257b12c95ec4b7d7b08abe8fe588965a8975a8c85d4c876a643b52d1d87025f775e68102037a10fc145fc88715e0ef8f1f54f56cecdda993677f992f67aa92d675292d675297afa3b11516188976544bb2a259b56c4b36bd8966d7b12c95ec4b257b12df5ec4b7d6357eef77bb112cb512cb512ea9e6643b525dfa8afc386f5872a7c548102037a7240872df710e2bc3cf8dedb8e9e8cd727ea25d3a7f9ec4a36bd8946fee6c4a27ee6c5ebe8a8972c31ec4aa57b12a95ec4aa57b12a95ec4afd7b12bf5ec4afd7b12bf5ec4aad7b0d5fbb2fc3112cb512cea8b65c2b66b04ea37fa57a2a5f125dda98f0e0bd61cb688fc2dc0bf2e46f0871872c38e147614f70cbd7d5c2bd34e1e7c6f65d7fbd0bad2c9b83f36c4f4af515b7352fbd0c963896b3a9496656a75f4665f7c3112acaf6255b5ec4ab6bd8956fee6c4aa7ee6c4aa57b12a95ec4affc9b12bf5ec357eede58f62556bd8955af62556bd84b45b27744baebcc955f331aa61bd57a72af48f237a7e12f4204392ef7f1bdb7799eafa331c9fa895657b12ada8956d64a36b2f5f456a2df0c64a36b2559592acac956544ab2a2559512cda8966d44b36a117eeedf86225db512eda8976d44b36a259b518dedc2b897a7e0a7e140872ddefe68102076a10420841082104208410821043b50ed43b50ed43b50ed43a25dfddfffc4002910000201020504020301010100000000000001112151314161d1f11091e1f071a181b1c1204030ffda0008010100013f21ff00b649e93ff94924924f49e95d51eb771b5fdcd6f71bb3f722de39a39a39a15ef7179421cfdcd6f735bdce70d59ca1cc1ce1ce0fa1135e71de94d6354126941d6a1abbb4357f68f9f68f5a117768f4a11c223887a104b8053e017b21e903e2bb09b576136aee7c5773e2bba3e0ee3d3f635cc3f663f6635d3041c99acd546fc41bf14e08e109f13a348e7c51785e8e86922ff4222a26d8d85227643b21e7d70b5644960359afb2a4b5fc3fa258a7e5035d67b43d2a2273daa200107b5105b7dc4be26e47c4dc8789b9ec4dcf626e47c2dc7c46e559f6b72acfb5b8fdd47e887c7b06a5db126daff9054d75f57a9042b51329918052ef96c1b03da87c72b456d21530c1882da24ff9b7fc7d2e086a650c670bf1f67a508788ff002517f664fc9604064aec223a53fd88605f91686127f1a425ee0e4bb1ccb61c4d5a123647a0ad1f96c7a3d87ee7f87a1d88fd1fa1fa3b1eef13dbe27b9d840f5297a9813139ee92a2a92b223c3337f58d00f464f1a75c825e444a1798681a0680e26451d1c0ac11b21d81d81d81d8340d243764886e2ecaf0283046896d80f648942a352aeb8c687aa92a82b57dc4b16c305667f244518c1812b114905531d44cf43ece0771ad7c48ef5f967223948fcc362e7abe059ebf8f01b1d24eb99f42f7bfc135d7b01f3276702071ab96e418fd5b981f576f5a835cd1ec998ed0ed0ed14c8b428b01da1d81da34076c7d32d216658ac5cb546988d3a6436dd3324c85aa44a75b3ceaa47c88f4624a4b21435108eff03f4bfd2f76b71ea6e2693365093a84d5fd7a147e483f291fb47e87e4db0fce447be0ec0173050deae1a7c974f5f0789f11b994d1bc16229260e61624b1ef222d512767ae11a31c6a52434876876890916a5ce842c10ec07683b23b43b6598eca1db30fd510b034d11097f227c8527450fac73753aa921e975514cdc2ee65a2eec7eadfa3dabf83f66fd0f4d08847c5f825dcec72d1cfc3f320fce879483f3b0fca05eed07e65436aefd7c9e8763876c535ad5e03ab90f0d8cd76c32768a4d5f6bd7089790c60cd9a61d91a624a56abf8e84ed234c7687690eca2c50ec8df921ea5160ac8d329aa66bf67a1a1a2852ab0eab74eaa48224bb87f4a5204355c4d57ec83309fb87e8f6afe0cd2e091eb3f8d10bcff006396ec7331ca03f2c0cb98d69cb55f8f02716c4bb7a7c8bd87f0e15b0b2b0ab84573a61e11af6039eeb02675a7f8e90874393aa4ccdd234b314181a68d31d90cced8c1d943b630ecc924a2ded3a168a28e19982735fa43b225c95dd62e33d4815c135fc1063bd4acd588b33f31ce07260ea50455acf809bbfe8e9f9a8614edcb4bd264f9c9a8869b50aabb3a1eff0061b5117e1b0b046393150ac0c8dd55b4429bf847cb7935b97fe0852493631ec8ad0c44fc8d134d13c2c258ac8c5623b686276d0eda3490db922bcf4a28e0580e4e6809bcfc24c8b01542b09f56986849fd13c2978d5642df1bd1278c7d0c23be6ba053f5cfd10cd448296b47a1ce03f331cb43f341cb8735e8ab421199d65d6205110da62ae445c327247151d57e0780857349c29d6b4690b5dd690e1b5229804723449bc214d456c764764764764d0469a34d0ec92e84b88344680d3445211294421699375808cec1c55c0dd7f0535ef043bfd88b7db0f7cb61324a225257e8e55b0fcb363966c4bb9d8e43b1cc76393ec73bd8e5fb0fb5243553be0737d87e4fb0fcbf63c87b1e63d84f41e88b9c1c75c2369623b087690eda2730b07fc15946923491a28d14699a28d234ccaf2206821d91bf243f90a817756a48d8d2340698d1f61b71ec1c51c51c51c51c51c51c51c51c50dee7e838c38c38438238f1442934ff00afffda000c0301000200030000001092492492492492492480008000000000000001b7fd277b6d26da4d06a49249648674c005e0055b6dff00f9e6996c3b431b7a4519b91ff3e38f204140b2592be9b558449868a00055fbef977482c516cd663624dc40906020022d83cc9899f20290db66d58344b64a48a5a2419269600f4e484e35e96410148c31e92f20b2d2148eb42b37243db206696e321b0be4212cd7b5b7dd66dba4845d85e8192fd4b38e9172c42ecb6e3cd218f23ed3120c997ed67b92495b9be79e7b7fdfda48b9e38897c429f8b4090d6147ec181996836925fa9b5649e170b4e9a402012400000086c1049249249249249249249fffc40020110003010101010002030100000000000000011110213120415130405061ffda0008010301013f10ff005084262134842131098842616104354842111084210842626316417c114a5656565656565294a52972132b3d2110c2704e908d945145144646465119191908c8c850910f06f1a1c09492492491a9041235238d48868f495103d7350952082082082082082082083cf849f3452f715151515150c21515151514e8a3e0a99433d4e092e09f9008d29208248c47e44ac82f1d8b3e170a5294a529c668c2ad7a1b7f8288c8cafa1aea498908c217841041041040d0820820864904b27f024de89e28997ec0a8a8e1c3827fa2b3a744c86beea1210f41a611935fc12412c4a88c208fc621075e1c7bf0fc1323233a8a562a7514a759d5e94a2c294a21d6a49890820820824483464924d129249249049042efc609cc543fe1002fa02b3feb1d6a17ee413f340d48c20812fc113936938431fea71eea29f1119589b28a2b38de32323232323232312f42afc3abaceb524c892e6490897ee104b1a924161b362110fdd0413d2f8a54f0ab1531b4731474545452a3870a86cb95098fbf044dc2708209c99488d082308f801b87fa9c3db0acaf7544650db2b5efd7a89e918e0a5e8ddfea5ff03fffc400221100030001040301000300000000000000000111211020315130416140507181ffda0008010201013f10fdb4e7f2c2109a3d5feab353f0370a5d28bc14ba5f0b54689ad841512412490342082a2a2a20920824813a3673ab2702cb138dcb2cb2cb2cb1b965948a659626434d0b6373828ac80bd85145145145a2cb2ca2cb286e2a13d8d29823210689b819124edf8c7d8826c71c17503f10540051659658bb92277673a20a2e4c32222223060c10c92488c851c9111110d1f02536370ade554bc5000556594f02d9168841992108421084d10411aec49b30e3615625ad3f1551015147d09ddb08888490d222308c1111111111111109220888882ad8dd82bdc005896e00182db553266f9d95b210c2f437d0f8108421087047435a217a3fa0f2c10421eb0669635a5e943e93e7beaaa07cca2891f218d0d035a11ea9fa2222223086d1515150a3223060888882069110d701a2629eb63e06d8cba29fe0000103f080000cdf3aa1a4f08b23a23a134fd1fe109a21084211d11d157447447447428f1046b8d6e07195a1f33e62e93e1e10002f99f13e67ccf89f33bd0cd552e44d15151830544444444104460c111845454444428e473d7f29ffc4002710010002010205040301010000000000000100112131415161718191a1c1d1f110b1f0e140ffda0008010100013f10ff00a6f32f94b972929c65ca7497ca5cbe552c972c972ce32e5094779e5f8525ca4b9415cac6256e9f74ff005a8918f267cc28b28f367dfe2db9df0e0ddf16fbe9a8bbba08b6bea8d663be687fbe89557913edd8edc1f609c299d9989a792267be7c4aef666cbc27c4b3f7ecd613a1c232d48a008f467f02fdcd6c248678bfcb9c02120398b433fcb9cc85e3fd6f3842feb8cd2dff004e7002bd12c1af67c9386bf8739fdfe4947f27acfa3cb0e3c7943f8bd623cfa0f98782f67ccd88f0801a7c222d87c3e618946ab455712ad9c7307c4319f0be27f9c7c441c78df11ff05f1177f97a4e278cf88f06edfe4fa67c4d0d1d9f129ddec7c476be03e272aec7c4b38f09f102f8cf89c60f1f11ff0014f88d397f1f117d7c07c45e0f013ea317c5e7694716f3a95db77957c451d40d229af633047394057e354b3a41c4468426fbcaa50f10c1363399f680dd33c93a1250731ca2927984e26f7089de71e8277851ff0050c02b5ba4c84d6908306cc92244f531860bcabf9e333e07d3e78d147f8f9cbb791e6ef0ab5c2d2bec4d199ecd6f34ac1b73d6531bca6ffb52d1738a4a46d027007ed3e2d8cc6e818726803a8367a7ab2f88cf243323c4fec4e4bc40340769c9f88e653c4e51e91ee8df49460417d0b61f15814c9849695d32a6a5c41301f6806d0a76011d52abc09aa8054d352f62147f19978391df721e38756e7a444031b2d45e1d38df89b87fd709568fd4fdd020d485cfc3900853cb778e1181701e2779c875f2e7ed13734229ca1e92a35c6686aa486a8f2107071a8de1969ca5869767c42d7d93f10780a0519d7b6b11714a1b1e0bff003b4e4070b7bcc03029d1b0e9f9025b3712c962a8c0fa4dda35cc946a653b58c569a831b7bc01a7bcfa688dbe26c8cb1a220d312349da3fe540abd2895300a532e4e3a3cc5fb28d86302d8474620ca965db9b1b18788c0683575cfe40651d0a0fa9160137bfe860e0e32d195a19ddb6ce91562ae6f0071318f055e661409053e300b7b11a557da90233d20fed8273d01c435ed9fb4435edfc30cd58c897ba4ee544c7560554853d14f9952d13806061d97c5070c4ea2a22aa7161dc0d745d769b3ef1083264a841543652fe4e0e712d83d65090c8c745f3385c2d5022f6cb2885db8c3b7ac70c3c10d8acada2376c5f6788e1c639d11e01ed15db1790b5c18583de53f6a29a760976094b35c996c034608ea83da0340868adbfcfcd0d40f107a241c25a227d2497c85d0b2e35774ad8a7a44d451ca3468f50c69479c2f6236f4612a1257b981ecdff0019cb5bdfc3099810eaddb9a94f6ca1df3209d5393811a8dbde032019f1a4bcb0e63068d6c2c6135a6f55de2803aa1b81aed7505daba37bcc1c38a5ad95c6d9fcde363de20a0a57ced7cc69d3e253d1e25bd3e22af5d86b4163e66a5e094fd8966bd09c17c4aba628d32964f8804fd113b1ec461205bae3b46e47c4035f045d40be9ce32c0d934d44e90f20381d3fcfca68a7661e88c4c0fbe23b0cae6500b55bc5c27f15bc29fac2dd025d06b84a14606831c5e9aa3cc05a046bed748b8a7d24a39490667b730f63b9146a46967b5222e0be646bbcaeeaa111aedfa42b30740fee44c2100eba0b95542d556e81de506ca5a60b0d69a975da0ad8ee49e46048a42ef1b61f946b813626703a7c289f513fc847fc09621c8ba32c5411a3c4e0eed16d9da57d33fc3471b1d23b4ed13687c13536ed352808375c46190ed32943c4a0a8087a229b06a7e93eba14f54b8e87c7e594a2751ac7648bad9d14cbc9450a004d4d82f0ad1c822cd57f1b456416049d4ea12288059335bd3838db18055d23a7d88daf679418297790c64e0e8d03bbf208a39ed38777b6a176543ae39710b66abae29f29c5bd04dfa9c080a29732526349536a2b581a31a72943741c3e68998f620e0dd7e469166e9e26386574859d1e201a0f111b0882dc156ce03f735e276947c52a3260f4097303c4e1a46ec4de41268b842821b96ed2286888862ed10145c0c759a507221a207384981751ce9fcaf00daf9f1149fd6ebebfdc4e948abc8fd8592f57612a1ac8a3f0b2c9d025b13bf0d3cc130448a65f3ff0f40bef27e02a1bb3e443c72f370eba6bc11b535c255472bdb94f1012c2e859b655b2a48804302db5dd6338974180064040be44ef094bb9ff00844c606522a8cb47e6940ef199526135cc26d82e568f35c55d9da64c28c78523a9e845e00618dea8fdc0180cafa264e3de275f14b5a0ed365de225f6a24fb53d9a235944a44d472d78215b1f11cd86fa460d3144b6bce10b031a280d0e4b018033ca5070180e74fe69e23756e9412052ca23672152afda1ae92590dc0e8ea50744e333645bbadda6686e747b45d53ed0a470814dfd0a1e769acea709372ec4a63c730e452d645deed4abbef6423f5a910597a38b79a0ae762537d4fa41fb2cebc3d0c598fbe88a4f02eb532b56d569ce69dcce185ee843b0b595a3545fc82863a81b34809682d20d069fea97749580a80805979a3c462dafdab5c01eac01a654d32c64f78b34413a5976be2fc632381ded88653504ee567d6bcc2a2fc12acfa1133da8a407a4264bb400a8c3eff9a6a1a82df4a4815163f50bfee7a21497f6e769d77e3de37f9d65484d5731b6cdb479961169cd5ddfc419b4a3bf59378246554cd9c2e348d980aa9a318c9ab9310d8ae001a0c037521a1a872873d717049bb1aa94103685dd5f7fc9b03a2c62eac823025bf6251f62517f54b82a350dd61e1faa25af8a73a9f4d3e9a03b7c4a34f012fbc3c45cacba92994050356a6b29e88f0e88744c47a50d7095a40301dbf20320f59c94e525ff0004fa39f4a8c8a134b1881fc49f449f449f449f449f449f409f409f5c8392268d27d027d627d3a2df0e2daf8b1fa1668d7fd7ffd9, 1001001, 'NewFauxBlind-200x200.jpg'),
(1, 'Faux Blinds', 0xffd8ffe000104a46494600010101006000600000fffe003250726f6365737365642042792065426179207769746820496d6167654d616769636b2c207a312e312e302e207c7c4232ffdb0043000302020302020303030304030304050805050404050a070706080c0a0c0c0b0a0b0b0d0e12100d0e110e0b0b1016101113141515150c0f171816141812141514ffdb00430103040405040509050509140d0b0d1414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414ffc200110800c800c803011100021101031101ffc4001c0000030101010101010000000000000000000102030405060708ffc40017010101010100000000000000000000000000010203ffda000c03010002100310000001fea900000000000000000000000000000828000000000000000000396dc8824889a0215b52318c620244211248964e94ab7956082440219432a9c390025a1244b2cc4b2b07a173da715d4902244201c32863002449225444b3107afae7a9e3358ae6672aa020a72318d6810804a248ad925493e935cfdd4e097e5e6fceb7cbc6950287568c06a208a262564cd3a6b1b7957efef1facd40e45f9e9be3979f26067575400208400665926a631cf5f5bae7efd819af35714aed5446505366565524acc21260ba08b8c8c0fa363d3a0e75f9ecef90c9645110e802442a98421550d77cc8acabe9af3f7ec09316b89688a462004a410b090b2b3189455952c1947bac7b56062bf3f37c32e392032286226b3252092622b428d14334fa7d63e8ec094caeb856ec8551cf0f4690b2419904131800d6e49588f799f6ac0c4f033ae45e79b944908d450499a499ac0a5c4baa352484fabd73fa2a09325e457524d630ec2544ac266419db9e582ba0b92093de67d940c4f9fcef933ac04040ee5da0a4921336a48338aa0d48225faedf3f7ac094caeb901a1039e4bd1cb35290b999912c9c86a38b32a83e8667d340c17e7b3ac3370b4b5112502410490255511251077ea7998aabed35cbdca0839eebc83d04a2579e290208a858a9891462691055be3464bf6971eb20722f859d793a9cdc75d7ab46682a4912434a90482a2c423cb5e23f49df2f7ec085c17cb3857d32d39eaa88924952c021473c694d12e27996fd5ccfaa81ccbf318d724d67444564395588610e9a0a448e92cac49ce9f6fbe7eed8199cc676e708cce65b040000600d60ac09660cebdd99f4400420010806000000048c400234280000000000000000000000000fffc40026100001030403010101010003010000000000010204031213150511142210212306314050ffda0008010100010502ff00e939dfdb8bcbd4bd4bd4bd4bd4c8a5ea64532297a97a97a9914c8a647191c657199e66799de7a2a11abb9d52ba3b27d9f47d1d38fb3a79f67d9d3cfa3e8fa3e8fa3e8fa3e8fa3e8fa3e8fa3e882d72d5928fbbfd0ff43baa7750ff0043ba87fa1f676f3b79dbcfb3b79dbcede76e3b71db8fa3b71f476a76a71c8eee6d5ad44772359a2f2af370a6e8dc9b937486e4dc1b836e6dcdb1b636a6d4da9b53686d0da1b4362e71c63ead56931b732b44bcad011696a914d4a1a84354c444e250d521ab435686b10d621ad435a82f1886b9bd6b505e310a1c7a255ad013bd79ff001ea78637e57efaa95eb355f22b9e8ae7a641e9903a4d63d55cf5563d354f5553d350f5543d2f3d4f3d4e1d2154f51e92957fbab5bfbe944388fba1f8f15a2b533d885885883d8d2c42d2d42d42d42d42d43a42d41c88ab6a16208d41cd431a1013aa1f95aeb6a56988aead2eef4ce3d738f5ce1d2e65bec9a7ae61eb967b251ed927ba41ee907beb9b0aa3a7bd5362e362a32776b5269ef43899292297e3bfeba15a99ad42d42d41ed42d42d42d42d42d42d42d42c42c42a536a894d0c685883d886269c6b51adfca9df55644b6abe4cc3db38f6ce3dd3474e976fbe59ee947ba51ee927ba51ef927be41efae6c6b8ee42a289c8d4362f1b3dc3a72a2ec0e22be76fe2968ad4cd6a16a16a155a82310b10b10b10b10b1056218d0c6854a4d5129a18d0b13a56218d0e39b6b7f2a77d559729aae99290d84c36134d8cc1dc84aeb6328d84a3df24f7c93df2059f20d8573615cd8d61fc85436550d93c49ef51d3dc86c550e1eb67a7f8a2a0e6a5d6a1621621518825342c42c42c42c431a0b4d0c686342a516aae2431218d05a6862438e6db4ff2a77d55972d8e74c9689b09a6c269b09a3b9095d6c259b0947be51b0926c241b0906c6b9b0ac6c6aa0ee42a29b1a86c9e24f7a8b3dc6c54e26a2d5a1f8a7482b7fb621621621529a778d0b10b10b10b10b10c6863431a0ea29912921890c482d34ef121013aa1f9555512a4f94d73a749436528d9ca369285e4e475b4906ce41b3906d241b4ae6d2b9b4ac6cea9b3aa3b92a86cde6d5ea39d52571cbc8be9a6d5c713573c5fc70e4fe324b55f6a1621621529a2ae342c4169a18d0c6863431a18da62416925d8905a2d1cc5752e458a9329daa71dfc8ff922e46d39b232ab9244a672d2d04e52629b3983b9295d6ce59b3966d251b3946d249b3926ce41b3906ceb8bc955ef6754da541393a84a915a4566cba94ce16a2d585f8e2d42447638a7413b6d342c42a534bac42c431a18d0c6863698d0c68624169a5d890c4d31a0fa48a8ea09df1adb637e5757352af252d8abc94c53612cd9cc36b310772b294db4b36b2cdacb3692cd9cb3652cd94b36328d94a179191deca51b2946ca48bc94a17919270f51d561fe38b1056216216218d07d36dd890c6d31b4c4862431a1890c686341d4d3bc6863431a18d05a68424ea87ef47485a85a85886369634b1a58d2c69634b1a58d2c69634c6d31b4c6d3134c4c313046a37ff5ff00ffc4001e11010101000300030101000000000000001100011012202130403150ffda0008010301013f01ff00488f072479393c111f80fab7f4ef922223c1f41eb266666666ed769997967866ed6fcf922222222222223c1cef867d33ed999d99b7c7f62323232322323222222222eb1116fd8cf0ccccf1f3cff2df045d72222222222222222222df2f8666667ea6df1f111919119758c8888888c888e4b7f1b3e1b7c11111111111111111758bac5be5e199999999999999e19b7c17588c8cbae5d722232eb7588c8c8c88ce08b7c3e3e6f9e199fa7fbcefa222eb9111111975cbae5d7222eb975cbae416fa7c333f832c88c8888c8c8c88c8c888c88c8c8c8c8b7d333c7cf2ccccf2cf1f33feafffc40020110003010003010003010100000000000000011112102021300231405060ffda0008010201013f01ff0096bfe4de294a5294a5e94a5294bdff006421084210842108421084213bde2b2b294a5294a5294d14a5297e7084210842108427109d7d3d2b2b2b2b2b2b2b2b2b2b2b2b345294a52f69f28427109d276a56565656565656699a6699a6699a6699a66994a5ed3eb08421084ebe95959595959595959595959a656699a669959a346bf9bce7ceb5f1a6699a6699a65656699a6699a6699a6699a6699a6699a62f87855f0bc421e1084eacacacd334cd32b2b2b2b2b2b34cd33468d336c4cd313bfc7e1e73fa2764f8db34cd334cd334cd334cd334cd334cd334cd334cd334cd3175852f59da978a52f0fa7a5fc8d334cdb37f91a6699a6699a6699a656699a6699a66d9a66989dfaf879f2f3fd5ffc4003b10000102030604020707030500000000000001023134920311123391e11020213241810422426171a1a2131430517293d12340624350a3b1c1ffda0008010100063f02ff007389122448a91522a4548915224489dca44ee53b94ee53b94ee53b94ee3b8b956f3a5da9e1a9e1a9e1a9e1a9e1a9e1a9e1a9e1a9e1a9e1a9e1a9e1a9e1a9b9bf2438408102f5f04130b51c6534ca6996d329a6534cb6996d329a6534cb432da65b4cb432d0cb432d0cb432d0cb432d0cb4328ca1cb870a08e6331b4eb6577c48335dcff4eadceeb2ab73bacaa4fe4eeb2ab73bac6b4fe48d955b91b3a88d9d446cea2367511b3a88d9d4459511b3a8f62a3d8a8f62a3d8a8f62a3d8a8e8c45f838573db859e1c1080d6dde2abff44081017d5890204081020408103b481018b74148102d1bfe77f1e971d2c9aa64b6ff008990dd4c86ea4bb6a12fb044b9618a24bb6a3213532135321353212a323e6647ccc9f9990ba8d5fb25f85e64aea64a8dfe92a7532d4cb70e7dd8515795dfa53ff7912f4fc28439605defe3ea9eaa3342fbacf1ddd7a2c0edb2d17f93b6ca95fe4ecb2d17f93ab2cefbfa74532ecb4532ecfe665d9994c325ba992dd4c86d464254647d422ad8f96232175321da977d9393ccca7196f1f7355b73bc7957f4f2274e7810e09c21c8fbbf3e3d0f55966bf1452ffb3b3c7e665597cccab2f999365f32f5b2b3e9f13219f33219aa992cd4c866a6432a5321b512edab625d2bd896faf61aabe8fe58897fa8975d4c85d4c976a64bcb45c2adeb775e5f2fe391bd3840873a722f07ddf9f1e87ab62c5f352ffb0662fd4a4b32a525acea525595297afa3b12e5862892cca897655b12edab6259b5ec4b257b12c95ec4b257b12c95ec4b7d7b08abe8fe588965a8975a8c85d4c876a643b52d1d87025f775e68102037a10fc145fc88715e0ef8f1f54f56cecdda993677f992f67aa92d675292d675297afa3b11516188976544bb2a259b56c4b36bd8966d7b12c95ec4b257b12df5ec4b7d6357eef77bb112cb512cb512ea9e6643b525dfa8afc386f5872a7c548102037a7240872df710e2bc3cf8dedb8e9e8cd727ea25d3a7f9ec4a36bd8946fee6c4a27ee6c5ebe8a8972c31ec4aa57b12a95ec4aa57b12a95ec4afd7b12bf5ec4afd7b12bf5ec4aad7b0d5fbb2fc3112cb512cea8b65c2b66b04ea37fa57a2a5f125dda98f0e0bd61cb688fc2dc0bf2e46f0871872c38e147614f70cbd7d5c2bd34e1e7c6f65d7fbd0bad2c9b83f36c4f4af515b7352fbd0c963896b3a9496656a75f4665f7c3112acaf6255b5ec4ab6bd8956fee6c4aa7ee6c4aa57b12a95ec4affc9b12bf5ec357eede58f62556bd8955af62556bd84b45b27744baebcc955f331aa61bd57a72af48f237a7e12f4204392ef7f1bdb7799eafa331c9fa895657b12ada8956d64a36b2f5f456a2df0c64a36b2559592acac956544ab2a2559512cda8966d44b36a117eeedf86225db512eda8976d44b36a259b518dedc2b897a7e0a7e140872ddefe68102076a10420841082104208410821043b50ed43b50ed43b50ed43a25dfddfffc4002910000201020504020301010100000000000001112151314161d1f11091e1f071a181b1c1204030ffda0008010100013f21ff00b649e93ff94924924f49e95d51eb771b5fdcd6f71bb3f722de39a39a39a15ef7179421cfdcd6f735bdce70d59ca1cc1ce1ce0fa1135e71de94d6354126941d6a1abbb4357f68f9f68f5a117768f4a11c223887a104b8053e017b21e903e2bb09b576136aee7c5773e2bba3e0ee3d3f635cc3f663f6635d3041c99acd546fc41bf14e08e109f13a348e7c51785e8e86922ff4222a26d8d85227643b21e7d70b5644960359afb2a4b5fc3fa258a7e5035d67b43d2a2273daa200107b5105b7dc4be26e47c4dc8789b9ec4dcf626e47c2dc7c46e559f6b72acfb5b8fdd47e887c7b06a5db126daff9054d75f57a9042b51329918052ef96c1b03da87c72b456d21530c1882da24ff9b7fc7d2e086a650c670bf1f67a508788ff002517f664fc9604064aec223a53fd88605f91686127f1a425ee0e4bb1ccb61c4d5a123647a0ad1f96c7a3d87ee7f87a1d88fd1fa1fa3b1eef13dbe27b9d840f5297a9813139ee92a2a92b223c3337f58d00f464f1a75c825e444a1798681a0680e26451d1c0ac11b21d81d81d81d8340d243764886e2ecaf0283046896d80f648942a352aeb8c687aa92a82b57dc4b16c305667f244518c1812b114905531d44cf43ece0771ad7c48ef5f967223948fcc362e7abe059ebf8f01b1d24eb99f42f7bfc135d7b01f3276702071ab96e418fd5b981f576f5a835cd1ec998ed0ed0ed14c8b428b01da1d81da34076c7d32d216658ac5cb546988d3a6436dd3324c85aa44a75b3ceaa47c88f4624a4b21435108eff03f4bfd2f76b71ea6e2693365093a84d5fd7a147e483f291fb47e87e4db0fce447be0ec0173050deae1a7c974f5f0789f11b994d1bc16229260e61624b1ef222d512767ae11a31c6a52434876876890916a5ce842c10ec07683b23b43b6598eca1db30fd510b034d11097f227c8527450fac73753aa921e975514cdc2ee65a2eec7eadfa3dabf83f66fd0f4d08847c5f825dcec72d1cfc3f320fce879483f3b0fca05eed07e65436aefd7c9e8763876c535ad5e03ab90f0d8cd76c32768a4d5f6bd7089790c60cd9a61d91a624a56abf8e84ed234c7687690eca2c50ec8df921ea5160ac8d329aa66bf67a1a1a2852ab0eab74eaa48224bb87f4a5204355c4d57ec83309fb87e8f6afe0cd2e091eb3f8d10bcff006396ec7331ca03f2c0cb98d69cb55f8f02716c4bb7a7c8bd87f0e15b0b2b0ab84573a61e11af6039eeb02675a7f8e90874393aa4ccdd234b314181a68d31d90cced8c1d943b630ecc924a2ded3a168a28e19982735fa43b225c95dd62e33d4815c135fc1063bd4acd588b33f31ce07260ea50455acf809bbfe8e9f9a8614edcb4bd264f9c9a8869b50aabb3a1eff0061b5117e1b0b046393150ac0c8dd55b4429bf847cb7935b97fe0852493631ec8ad0c44fc8d134d13c2c258ac8c5623b686276d0eda3490db922bcf4a28e0580e4e6809bcfc24c8b01542b09f56986849fd13c2978d5642df1bd1278c7d0c23be6ba053f5cfd10cd448296b47a1ce03f331cb43f341cb8735e8ab421199d65d6205110da62ae445c327247151d57e0780857349c29d6b4690b5dd690e1b5229804723449bc214d456c764764764764d0469a34d0ec92e84b88344680d3445211294421699375808cec1c55c0dd7f0535ef043bfd88b7db0f7cb61324a225257e8e55b0fcb363966c4bb9d8e43b1cc76393ec73bd8e5fb0fb5243553be0737d87e4fb0fcbf63c87b1e63d84f41e88b9c1c75c2369623b087690eda2730b07fc15946923491a28d14699a28d234ccaf2206821d91bf243f90a817756a48d8d2340698d1f61b71ec1c51c51c51c51c51c51c51c51c50dee7e838c38c38438238f1442934ff00afffda000c0301000200030000001092492492492492492480008000000000000001b7fd277b6d26da4d06a49249648674c005e0055b6dff00f9e6996c3b431b7a4519b91ff3e38f204140b2592be9b558449868a00055fbef977482c516cd663624dc40906020022d83cc9899f20290db66d58344b64a48a5a2419269600f4e484e35e96410148c31e92f20b2d2148eb42b37243db206696e321b0be4212cd7b5b7dd66dba4845d85e8192fd4b38e9172c42ecb6e3cd218f23ed3120c997ed67b92495b9be79e7b7fdfda48b9e38897c429f8b4090d6147ec181996836925fa9b5649e170b4e9a402012400000086c1049249249249249249249fffc40020110003010101010002030100000000000000011110213120415130405061ffda0008010301013f10ff005084262134842131098842616104354842111084210842626316417c114a5656565656565294a52972132b3d2110c2704e908d945145144646465119191908c8c850910f06f1a1c09492492491a9041235238d48868f495103d7350952082082082082082082083cf849f3452f715151515150c21515151514e8a3e0a99433d4e092e09f9008d29208248c47e44ac82f1d8b3e170a5294a529c668c2ad7a1b7f8288c8cafa1aea498908c217841041041040d0820820864904b27f024de89e28997ec0a8a8e1c3827fa2b3a744c86beea1210f41a611935fc12412c4a88c208fc621075e1c7bf0fc1323233a8a562a7514a759d5e94a2c294a21d6a49890820820824483464924d129249249049042efc609cc543fe1002fa02b3feb1d6a17ee413f340d48c20812fc113936938431fea71eea29f1119589b28a2b38de32323232323232312f42afc3abaceb524c892e6490897ee104b1a924161b362110fdd0413d2f8a54f0ab1531b4731474545452a3870a86cb95098fbf044dc2708209c99488d082308f801b87fa9c3db0acaf7544650db2b5efd7a89e918e0a5e8ddfea5ff03fffc400221100030001040301000300000000000000000111211020315130416140507181ffda0008010201013f10fdb4e7f2c2109a3d5feab353f0370a5d28bc14ba5f0b54689ad841512412490342082a2a2a20920824813a3673ab2702cb138dcb2cb2cb2cb1b965948a659626434d0b6373828ac80bd85145145145a2cb2ca2cb286e2a13d8d29823210689b819124edf8c7d8826c71c17503f10540051659658bb92277673a20a2e4c32222223060c10c92488c851c9111110d1f02536370ade554bc5000556594f02d9168841992108421084d10411aec49b30e3615625ad3f1551015147d09ddb08888490d222308c1111111111111109220888882ad8dd82bdc005896e00182db553266f9d95b210c2f437d0f8108421087047435a217a3fa0f2c10421eb0669635a5e943e93e7beaaa07cca2891f218d0d035a11ea9fa2222223086d1515150a3223060888882069110d701a2629eb63e06d8cba29fe0000103f080000cdf3aa1a4f08b23a23a134fd1fe109a21084211d11d157447447447428f1046b8d6e07195a1f33e62e93e1e10002f99f13e67ccf89f33bd0cd552e44d15151830544444444104460c111845454444428e473d7f29ffc4002710010002010205040301010000000000000100112131415161718191a1c1d1f110b1f0e140ffda0008010100013f10ff00a6f32f94b972929c65ca7497ca5cbe552c972c972ce32e5094779e5f8525ca4b9415cac6256e9f74ff005a8918f267cc28b28f367dfe2db9df0e0ddf16fbe9a8bbba08b6bea8d663be687fbe89557913edd8edc1f609c299d9989a792267be7c4aef666cbc27c4b3f7ecd613a1c232d48a008f467f02fdcd6c248678bfcb9c02120398b433fcb9cc85e3fd6f3842feb8cd2dff004e7002bd12c1af67c9386bf8739fdfe4947f27acfa3cb0e3c7943f8bd623cfa0f98782f67ccd88f0801a7c222d87c3e618946ab455712ad9c7307c4319f0be27f9c7c441c78df11ff05f1177f97a4e278cf88f06edfe4fa67c4d0d1d9f129ddec7c476be03e272aec7c4b38f09f102f8cf89c60f1f11ff0014f88d397f1f117d7c07c45e0f013ea317c5e7694716f3a95db77957c451d40d229af633047394057e354b3a41c4468426fbcaa50f10c1363399f680dd33c93a1250731ca2927984e26f7089de71e8277851ff0050c02b5ba4c84d6908306cc92244f531860bcabf9e333e07d3e78d147f8f9cbb791e6ef0ab5c2d2bec4d199ecd6f34ac1b73d6531bca6ffb52d1738a4a46d027007ed3e2d8cc6e818726803a8367a7ab2f88cf243323c4fec4e4bc40340769c9f88e653c4e51e91ee8df49460417d0b61f15814c9849695d32a6a5c41301f6806d0a76011d52abc09aa8054d352f62147f19978391df721e38756e7a444031b2d45e1d38df89b87fd709568fd4fdd020d485cfc3900853cb778e1181701e2779c875f2e7ed13734229ca1e92a35c6686aa486a8f2107071a8de1969ca5869767c42d7d93f10780a0519d7b6b11714a1b1e0bff003b4e4070b7bcc03029d1b0e9f9025b3712c962a8c0fa4dda35cc946a653b58c569a831b7bc01a7bcfa688dbe26c8cb1a220d312349da3fe540abd2895300a532e4e3a3cc5fb28d86302d8474620ca965db9b1b18788c0683575cfe40651d0a0fa9160137bfe860e0e32d195a19ddb6ce91562ae6f0071318f055e661409053e300b7b11a557da90233d20fed8273d01c435ed9fb4435edfc30cd58c897ba4ee544c7560554853d14f9952d13806061d97c5070c4ea2a22aa7161dc0d745d769b3ef1083264a841543652fe4e0e712d83d65090c8c745f3385c2d5022f6cb2885db8c3b7ac70c3c10d8acada2376c5f6788e1c639d11e01ed15db1790b5c18583de53f6a29a760976094b35c996c034608ea83da0340868adbfcfcd0d40f107a241c25a227d2497c85d0b2e35774ad8a7a44d451ca3468f50c69479c2f6236f4612a1257b981ecdff0019cb5bdfc3099810eaddb9a94f6ca1df3209d5393811a8dbde032019f1a4bcb0e63068d6c2c6135a6f55de2803aa1b81aed7505daba37bcc1c38a5ad95c6d9fcde363de20a0a57ced7cc69d3e253d1e25bd3e22af5d86b4163e66a5e094fd8966bd09c17c4aba628d32964f8804fd113b1ec461205bae3b46e47c4035f045d40be9ce32c0d934d44e90f20381d3fcfca68a7661e88c4c0fbe23b0cae6500b55bc5c27f15bc29fac2dd025d06b84a14606831c5e9aa3cc05a046bed748b8a7d24a39490667b730f63b9146a46967b5222e0be646bbcaeeaa111aedfa42b30740fee44c2100eba0b95542d556e81de506ca5a60b0d69a975da0ad8ee49e46048a42ef1b61f946b813626703a7c289f513fc847fc09621c8ba32c5411a3c4e0eed16d9da57d33fc3471b1d23b4ed13687c13536ed352808375c46190ed32943c4a0a8087a229b06a7e93eba14f54b8e87c7e594a2751ac7648bad9d14cbc9450a004d4d82f0ad1c822cd57f1b456416049d4ea12288059335bd3838db18055d23a7d88daf679418297790c64e0e8d03bbf208a39ed38777b6a176543ae39710b66abae29f29c5bd04dfa9c080a29732526349536a2b581a31a72943741c3e68998f620e0dd7e469166e9e26386574859d1e201a0f111b0882dc156ce03f735e276947c52a3260f4097303c4e1a46ec4de41268b842821b96ed2286888862ed10145c0c759a507221a207384981751ce9fcaf00daf9f1149fd6ebebfdc4e948abc8fd8592f57612a1ac8a3f0b2c9d025b13bf0d3cc130448a65f3ff0f40bef27e02a1bb3e443c72f370eba6bc11b535c255472bdb94f1012c2e859b655b2a48804302db5dd6338974180064040be44ef094bb9ff00844c606522a8cb47e6940ef199526135cc26d82e568f35c55d9da64c28c78523a9e845e00618dea8fdc0180cafa264e3de275f14b5a0ed365de225f6a24fb53d9a235944a44d472d78215b1f11cd86fa460d3144b6bce10b031a280d0e4b018033ca5070180e74fe69e23756e9412052ca23672152afda1ae92590dc0e8ea50744e333645bbadda6686e747b45d53ed0a470814dfd0a1e769acea709372ec4a63c730e452d645deed4abbef6423f5a910597a38b79a0ae762537d4fa41fb2cebc3d0c598fbe88a4f02eb532b56d569ce69dcce185ee843b0b595a3545fc82863a81b34809682d20d069fea97749580a80805979a3c462dafdab5c01eac01a654d32c64f78b34413a5976be2fc632381ded88653504ee567d6bcc2a2fc12acfa1133da8a407a4264bb400a8c3eff9a6a1a82df4a4815163f50bfee7a21497f6e769d77e3de37f9d65484d5731b6cdb479961169cd5ddfc419b4a3bf59378246554cd9c2e348d980aa9a318c9ab9310d8ae001a0c037521a1a872873d717049bb1aa94103685dd5f7fc9b03a2c62eac823025bf6251f62517f54b82a350dd61e1faa25af8a73a9f4d3e9a03b7c4a34f012fbc3c45cacba92994050356a6b29e88f0e88744c47a50d7095a40301dbf20320f59c94e525ff0004fa39f4a8c8a134b1881fc49f449f449f449f449f449f409f409f5c8392268d27d027d627d3a2df0e2daf8b1fa1668d7fd7ffd9, 1001001, 'NewFauxBlind-200x200.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product_imgs`
--

CREATE TABLE `product_imgs` (
  `id` int(11) NOT NULL,
  `Product Name` varchar(50) NOT NULL,
  `product_image` longblob NOT NULL,
  `secondary_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_imgs`
--

INSERT INTO `product_imgs` (`id`, `Product Name`, `product_image`, `secondary_id`, `name`) VALUES
(0, 'Basswood Blinds', 0x70726f647563745f696d6765732f6e6577776f6f64626c696e642d323030783230302e6a7067, 1001001, 'newwoodblind-200x200.jpg'),
(1, 'Faux Blinds', 0x70726f647563745f696d6765732f4e657746617578426c696e642d323030783230302e6a7067, 1001001, 'NewFauxBlind-200x200.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product_testing`
--

CREATE TABLE `product_testing` (
  `id` int(11) NOT NULL,
  `height_ft` int(11) NOT NULL,
  `width_ft` int(11) NOT NULL,
  `material_type` varchar(100) NOT NULL,
  `rates` int(11) NOT NULL,
  `minimum_price` int(11) NOT NULL,
  `compare_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_testing`
--

INSERT INTO `product_testing` (`id`, `height_ft`, `width_ft`, `material_type`, `rates`, `minimum_price`, `compare_id`) VALUES
(0, 26, 24, 'BASSWOOD 2 Blinds', 80, 0, 1001),
(1, 36, 27, 'BASSWOOD 2 Blinds', 90, 0, 1001),
(2, 36, 30, 'BASSWOOD 2 Blinds', 56, 0, 1001),
(3, 36, 36, 'BASSWOOD 2 Blinds', 68, 0, 1001),
(4, 36, 40, 'BASSWOOD 2 Blinds', 28, 0, 1001),
(5, 36, 43, 'BASSWOOD 2 Blinds', 67, 0, 1001),
(6, 36, 45, 'BASSWOOD 2 Blinds', 28, 0, 1001),
(7, 36, 48, 'BASSWOOD 2 Blinds', 68, 0, 1001),
(8, 36, 56, 'BASSWOOD 2 Blinds', 56, 0, 1001),
(9, 36, 60, 'BASSWOOD 2 Blinds', 44, 0, 1001),
(10, 36, 67, 'BASSWOOD 2 Blinds', 37, 0, 1001),
(11, 36, 70, 'BASSWOOD 2 Blinds', 68, 0, 1001),
(12, 36, 71, 'BASSWOOD 2 Blinds', 37, 0, 1001),
(13, 36, 75, 'BASSWOOD 2 Blinds', 44, 0, 1001),
(14, 36, 78, 'BASSWOOD 2 Blinds', 37, 0, 1001),
(15, 36, 85, 'BASSWOOD 2 Blinds', 32, 0, 1001),
(16, 36, 92, 'BASSWOOD 2 Blinds', 30, 0, 1001),
(17, 42, 24, 'BASSWOOD 2 Blinds', 44, 0, 1001),
(18, 42, 28, 'BASSWOOD 2 Blinds', 37, 0, 1001),
(19, 42, 30, 'BASSWOOD 2 Blinds', 38, 0, 1001),
(20, 42, 33, 'BASSWOOD 2 Blinds', 37, 0, 1001),
(21, 42, 39, 'BASSWOOD 2 Blinds', 44, 0, 1001),
(22, 36, 40, 'BASSWOOD 2 Blinds', 56, 0, 1001),
(23, 42, 43, 'BASSWOOD 2 Blinds', 44, 0, 1001),
(24, 42, 45, 'BASSWOOD 2 Blinds', 65, 0, 1001),
(25, 42, 48, 'BASSWOOD 2 Blinds', 65, 0, 1001),
(26, 42, 52, 'BASSWOOD 2 Blinds', 87, 0, 1001),
(27, 42, 55, 'BASSWOOD 2 Blinds', 76, 0, 1001),
(28, 42, 59, 'BASSWOOD 2 Blinds', 37, 0, 1001),
(29, 42, 64, 'BASSWOOD 2 Blinds', 44, 0, 1001),
(30, 42, 60, 'BASSWOOD 2 Blinds', 37, 0, 1001),
(31, 42, 67, 'BASSWOOD 2 Blinds', 44, 0, 1001),
(32, 42, 71, 'BASSWOOD 2 Blinds', 37, 0, 1001),
(33, 42, 74, 'BASSWOOD 2 Blinds', 89, 0, 1001),
(34, 48, 24, 'BASSWOOD 2 Blinds', 79, 0, 1001),
(35, 48, 27, 'BASSWOOD 2 Blinds', 70, 0, 1001),
(36, 36, 24, 'BASSWOOD 2 Blinds', 50, 0, 1001);

-- --------------------------------------------------------

--
-- Table structure for table `product_testingone`
--

CREATE TABLE `product_testingone` (
  `id` int(11) NOT NULL,
  `height_ft` int(11) NOT NULL,
  `width_ft` int(11) NOT NULL,
  `material_type` varchar(50) NOT NULL,
  `rates` int(11) NOT NULL,
  `minimum_price` int(11) NOT NULL,
  `compare_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_testingone`
--

INSERT INTO `product_testingone` (`id`, `height_ft`, `width_ft`, `material_type`, `rates`, `minimum_price`, `compare_id`) VALUES
(0, 36, 24, 'FAUX 2 Blinds', 800, 0, 1001),
(1, 36, 27, 'FAUX 2 Blinds', 900, 0, 1001),
(2, 36, 30, 'FAUX 2 Blinds', 28, 75, 1001),
(3, 36, 33, 'FAUX 2 Blinds', 44, 75, 1001),
(5, 36, 36, 'FAUX 2 Blinds', 56, 75, 1001),
(6, 36, 39, 'FAUX 2 Blinds', 68, 75, 1001),
(7, 36, 42, 'FAUX 2 Blinds', 28, 75, 1001),
(8, 36, 45, 'FAUX 2 Blinds', 44, 75, 1001),
(9, 36, 51, 'FAUX 2 Blinds', 37, 75, 1001),
(10, 36, 54, 'FAUX 2 Blinds', 44, 75, 1001);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_pass` varchar(50) NOT NULL,
  `user_email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `user_pass`, `user_email`) VALUES
(1, 'kamal', 'kamal&^%', 'kamal@jeronone.com'),
(3, 'aasad', 'asad&^%', 'asadali@jeronone.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `basswood_blinds`
--
ALTER TABLE `basswood_blinds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `colors_products`
--
ALTER TABLE `colors_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `color_table`
--
ALTER TABLE `color_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `color_table1`
--
ALTER TABLE `color_table1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faux_blinds`
--
ALTER TABLE `faux_blinds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_imgs`
--
ALTER TABLE `product_imgs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_testing`
--
ALTER TABLE `product_testing`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_testingone`
--
ALTER TABLE `product_testingone`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `basswood_blinds`
--
ALTER TABLE `basswood_blinds`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=187;
--
-- AUTO_INCREMENT for table `colors_products`
--
ALTER TABLE `colors_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `color_table`
--
ALTER TABLE `color_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `color_table1`
--
ALTER TABLE `color_table1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `faux_blinds`
--
ALTER TABLE `faux_blinds`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=187;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `product_imgs`
--
ALTER TABLE `product_imgs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `product_testing`
--
ALTER TABLE `product_testing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `product_testingone`
--
ALTER TABLE `product_testingone`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
