<?php
  session_start();

  if(!$_SESSION['email'])
  {

      header("Location: login.php");//redirect to login page to secure the welcome page without login access.
  }
  ?>
<html>
<head>
  <?php include'appheader.php'; ?>
  
<title>white Blinds</title>

</head>
<body>
  <div class="navbar">
    <div class="navbar-inner">
      <?php include 'topheader.php' ?>
<style>
    .login-panel {
        margin-top: 150px;
    }
    .table {
        margin-top: 50px;

    }

</style>
  <!-- start: Header -->

    <div class="container-fluid-full">
    <div class="row-fluid">

      <!-- start: Main Menu -->

      <!-- end: Main Menu -->

      <noscript>
        <div class="alert alert-block span10">
          <h4 class="alert-heading">Warning!</h4>
          <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
        </div>
      </noscript>
      <?php include 'left_menu.php'; ?>

      <!-- start: Content -->
      <div id="content" class="span10">


      
      <ul class="breadcrumb">
        <li>
          <i class="icon-home"></i>
          <a href="dashboard.php">Home</a>
          <i class="icon-angle-right"></i>
        </li>
        <li><a href="img_update.php">Update Image</a></li>
      </ul>

 <!--<h1 align="center">BASSWOOD 2" Blinds Price Change Table</h1>-->

 <div class="box span12" id="main_table_div">
					<div class="box-header">
						<h2><i class="halflings-icon align-justify"></i><span class="break"></span>Product Image Change Table</h2>
						<div class="box-icon">
							<!-- <a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a> -->
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<!-- <a href="#" class="btn-close"><i class="halflings-icon remove"></i></a> -->
						</div>
					</div>
					<div class="box-content">
						<table class="table table-striped" id="product_table_id">
							  <thead>
								  <tr>
								      						  
									  <th>Product Name</th>
									  <th>Product Image</th>									  
									  <th></th>
								  </tr>
							  </thead>   
							  <tbody>
								
																	                                   
								
						
        <?php
        include("database/db_conection.php");
        $view_users_query="select * from product_images";//select query for viewing users.
        $run=mysqli_query($dbcon,$view_users_query);//here run the sql query.		
       	//header("Content-type: image/jpeg");
	
        while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
        {
            $product_ids=$row[0];	
            $product_name=$row[1];			
            $product_images=$row[2];
			$com_id=$row[3];
			
			
         	
		
        ?>
		<tr>
		<?php echo '<td>'. $product_name.'</td>'; ?>		
		<?php echo '<td><img src="data:image/jpeg;base64,'.base64_encode($product_images).'"></td>'; ?>
		<?php echo '<td><a href="img_update1.php?update_value='. $product_ids. '"><button class="btn btn-danger" onclick="btnconferm()">Update Image</button></a></td>';?>
       </tr> 		
      		
		<?php }?>			                          
	</tbody>
 </table>  
</div>
</div>
  
        </div>
</div>
</div><!--/.fluid-container-->

    <!-- end: Content -->
  </div><!--/#content.span10-->
  </div><!--/fluid-row-->
<div class="clearfix"></div>
<?php include 'footer.php'; ?>
<script>
function btnconferm() {
    alert("Are You Sure You Want To Change Product Image");
}
</script>

</body>

</html>

