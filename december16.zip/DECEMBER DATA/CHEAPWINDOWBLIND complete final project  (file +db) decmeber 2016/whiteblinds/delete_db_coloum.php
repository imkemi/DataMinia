<?php

      include("database/db_conection.php");//make connection here
      
	
     $update_query="ALTER TABLE `faux_blinds`
                    DROP `color_box (50)`;";  
      $run=mysqli_query($dbcon,$update_query);//here run the sql query.
		  
		   
		 if($run) {
           echo "Delete Coloum in database sucessfully";
                }
		   else{
			   echo "Not Delete coloum In Database";
		   }
		
		   
		   
?>
	