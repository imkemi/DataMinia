<?php

	define('SHOPIFY_SHOP', 'cheap-white-blinds.myshopify.com');
	define('SHOPIFY_APP_API_KEY', '79d40adc6ab40622a73b8962d1600c45');
	define('SHOPIFY_APP_PASSWORD', '142b62603a1537593366d42d877bfd20 ');

?>
