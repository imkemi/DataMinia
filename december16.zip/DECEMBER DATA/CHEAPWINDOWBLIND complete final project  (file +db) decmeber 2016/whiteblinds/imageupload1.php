<?php include'appheader.php'; ?>
<?php
 header('Access-Control-Allow-Origin: *');  
 
require __DIR__.'/vendor/autoload.php';
use phpish\shopify;

require __DIR__.'/conf.php';
?>
<?php
  session_start();

  if(!$_SESSION['email'])
  {

      header("Location: login.php");//redirect to login page to secure the welcome page without login access.
  }

  ?>
<html>
<head> 
<title>white Blinds</title>

</head>
<body>
  <div class="navbar">
    <div class="navbar-inner">
      <?php include 'topheader.php' ?>
<style>
    .login-panel {
        margin-top: 150px;
    }
    .table {
        margin-top: 50px;

    }

</style>
  <!-- start: Header -->

    <div class="container-fluid-full">
    <div class="row-fluid">

      <!-- start: Main Menu -->

      <!-- end: Main Menu -->

      <noscript>
        <div class="alert alert-block span10">
          <h4 class="alert-heading">Warning!</h4>
          <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
        </div>
      </noscript>
      <?php include 'left_menu.php'; ?>

      <!-- start: Content -->
      <div id="content" class="span10">


      <ul class="breadcrumb">
        <li>
          <i class="icon-home"></i>
          <a href="dashboard.php">Home</a>
          <i class="icon-angle-right"></i>
        </li>
        <li><a href="imageupload.php">Upload Product Image</a></li>
      </ul>
<?php
 	$shopify = shopify\client(SHOPIFY_SHOP, SHOPIFY_APP_API_KEY, SHOPIFY_APP_PASSWORD, true);

 error_reporting(0);
define ("MAX_SIZE","1000"); 
function getExtension($str)
{
	 $i = strrpos($str,".");
	 if (!$i) { return ""; }
	 $l = strlen($str) - $i;
	 $ext = substr($str,$i+1,$l);
	 return $ext;
}
 
$errors=0;
$image=$_FILES['image']['name'];
$product_name=$_POST['product_name'];
$product_price=$_POST['product_price'];
$product_type=$_POST['product_type'];
$product_discrip=$_POST['product_discrip'];
if($product_name =="" && $product_price =="" && $product_type =="" && $image =="" && $product_discrip ==""){
		   
		  echo '<script> alert("Please Fill The All Input Fields"); window.location.href = "imageupload.php";</script>'; 
	   }
if ($image) 
{
	$filename = stripslashes($_FILES['image']['name']);
	$extension = getExtension($filename);
	$extension = strtolower($extension);
	if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") 
		&& ($extension != "gif")&& ($extension != "JPG") && ($extension != "JPEG") 
		&& ($extension != "PNG") && ($extension != "GIF")) 
	{
		echo '<h3>Unknown extension!</h3>';
		$errors=1;
	}
	else
	{
		$size=filesize($_FILES['image']['tmp_name']);
 
		if ($size > MAX_SIZE*1024)
		{
			echo '<h4>You have exceeded the size limit!</h4>';
			$errors=1;
		}
 
		$image_name=time().'.'.$extension;
		$newname='product_imges/' .$image_name;
 
		$copied = copy($_FILES['image']['tmp_name'], $newname);
		if (!$copied) 
		{
			echo '<h3>Copy unsuccessfull!</h3>';
			$errors=1;
		}
		else echo '<h3>Uploaded successfull!</h3>';
 
		//mysql_query("insert into file_tbl (path) values('".$newname."')");
		//echo $newname;
	}	
}

	try
	{
		# Making an API request can throw an exception
		$product = $shopify('POST /admin/products.json', array(), array
		(
			'product' => array
			(
				"title" => "$product_name",
				"body_html" => "$product_discrip",
				"product_type" => "$product_type",			
				"variants" => array
				(
					array
					(
						
						"price" => "$product_price",
						
					)
				),
				"images" => Array
                (
                     Array
                        (
                            "position" => "1",  
                            //"src" =>"http://shopifyexperts.biz/apps/blinds/$newname",	product image does not upload by localhost it is only upload by live server						
                            "src" =>"http://localhost/whiteblinds/$newname",
                            "variant_ids" => Array
                                (
                                )

                        )

                ),

             "image" => Array
                (
                    "position" => "1",  
                    //"src" =>"http://shopifyexperts.biz/apps/blinds/$newname",	product image does not upload by localhost it is only upload by live server						
                    "src" =>"http://localhost/whiteblinds/$newname",
                    "variant_ids" => Array
                        (
                        )

                )
      
			)
		));
	//	echo '<pre>';
		//print_r($product);
	}

	catch (shopify\ApiException $e)
	{
		# HTTP status code was >= 400 or response contained the key 'errors'
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
	catch (shopify\CurlException $e)
	{
		# cURL error
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
	?>
	
	

	<form>
		 <?php
     if($product){
     $productvalue=array($product);
   // echo "[$material_type] [$height_ft ] [$width_ft] [$mountingstyle] [ $quantity] [$total_rates] inserted successfully!";
		 	//print_r($a);
	?>
		<!--  <input type="hidden" id="quantitys" name="quantitys" value="<?php //echo $quantity ?> "> -->
		 <table class="table table-bordered table-hover table-striped" style="table-layout: fixed" id="product_tables">
		 <thead>
			 <tr>
				<th>Product Id</th>
				<th>Product Name</th>
				<th>Product Description</th>
				<th>Mounting Style</th>
				<th>Vendor</th>
				<th>Handle</th>				
			 </tr>
		 </thead>
		 <tbody>
		<?php
			 foreach($productvalue as $value)
	 	{
			$vaint = $value['variants'];
			//echo'<pre>';
			//print_r($vaint);
			foreach($vaint as $variantt)
			echo ' <td class="id_cls">'.$variantt['id'].'<td>'; 
			
			?>

	 			 <tr>
	 			 <td class="id_cls"><?php echo $value['id'] ?></td>
				<!--  <input type="hidden" id="ids" name="ids" value="<?php //echo $value['id'] ?> "> -->
	 			 			 <td><?php echo $value['title'] ?></td>
	 						 			 <td><?php echo $value['body_html']  ?></td>	 								 			 
	 												 			 <td><?php echo $value['product_type']  ?></td>
																     <td><?php echo $value['vendor']  ?></td>
	 															 			 <td><?php echo $value['handle']  ?></td>
	 																		      </tr>
			 </table>
				</form>
	 	<?php	}
		
		echo '<a href="imageupload.php" style="text-decoration: none;"><p id="subm">Add Another Product</p></a>';
}
 else{ echo "<br>An error occurred! Product Are not Uploaded"; }

?>
<script>
function btnconferm() {
    alert("Are You confirm ? Delete This Product");
}
</script>
<style>#subm {
    width: 220px !important;
    border-radius: 5px;
    background: #1681cf;
    color: #fff;
    font-size: 17px;
    text-transform: uppercase;
    text-align: center;
    padding: 10px;
}
#subm:hover{text-decoration: none;background: #e05b07;}
</style>
</body>
</html>