<?php
session_start();

if(!$_SESSION['email'])
{

    header("Location: login.php");//redirect to login page to secure the welcome page without login access.
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<?php include'appheader.php'; ?>	
			
		
</head>
<body>
		<!-- start: Header -->
	<div class="navbar">
		<div class="navbar-inner">
			<?php include 'topheader.php' ?>
		
	<!-- start: Header -->
	
		<div class="container-fluid-full">
		<div class="row-fluid">
			<!-- start: Main Menu -->			
			<!-- end: Main Menu -->			
			<?php include 'left_menu.php'; ?>
			<!-- start: Content -->			
			<div id="content" class="span10" style="min-height: none !important;">	
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Dashboard</a></li>
			</ul>	
			
               <div class="row-fluid">	
				<div class="box blue span12" id="quick-buttons">
					<div class="box-header">
						<h2><i class="halflings-icon hand-top"></i><span class="break"></span>Quick Buttons</h2>
					</div>
					<div class="box-content">
						
						<a class="quick-button span2">
							<i class="icon-group"></i>
							<p>Users</p>
							<span class="notification blue">1.367</span>
						</a>
						<a class="quick-button span2">
							<i class="icon-comments-alt"></i>
							<p>Comments</p>
							<span class="notification green">167</span>
						</a>
						<a class="quick-button span2">
							<i class="icon-shopping-cart"></i>
							<p>Orders</p>
						</a>
						<a class="quick-button span2">
							<i class="icon-barcode"></i>
							<p>Products</p>
						</a>
						<a class="quick-button span2">
							<i class="icon-envelope"></i>
							<p>Messages</p>
						</a>
						<a class="quick-button span2">
							<i class="icon-calendar"></i>
							<p>Calendar</p>
							<span class="notification red">68</span>
						</a>
						
					</div>	
				</div><!--/span-->
				
			</div>
			
			 <div class="row-fluid">	
				<div class="box blue span12" id="quick-buttons">
					<div class="box-header">
						<h2><i class="halflings-icon hand-top"></i><span class="break"></span>Quick Buttons</h2>
					</div>
					<div class="box-content">
						
						<a class="quick-button span2" id="quick-buttons">
							<i class="icon-group"></i>
							<p>Users</p>
							<span class="notification blue">1.367</span>
						</a>
						<a class="quick-button span2">
							<i class="icon-comments-alt"></i>
							<p>Comments</p>
							<span class="notification green">167</span>
						</a>
						<a class="quick-button span2">
							<i class="icon-shopping-cart"></i>
							<p>Orders</p>
						</a>
						<a class="quick-button span2">
							<i class="icon-barcode"></i>
							<p>Products</p>
						</a>
						<a class="quick-button span2">
							<i class="icon-envelope"></i>
							<p>Messages</p>
						</a>
						<a class="quick-button span2">
							<i class="icon-calendar"></i>
							<p>Calendar</p>
							<span class="notification red">68</span>
						</a>
						
					</div>	
				</div><!--/span-->
				
			</div>
			
			 <div class="row-fluid">	
				<div class="box blue span12" id="quick-buttons">
					<div class="box-header">
						<h2><i class="halflings-icon hand-top"></i><span class="break"></span>Quick Buttons</h2>
					</div>
					<div class="box-content">
						
						<a class="quick-button span2">
							<i class="icon-group"></i>
							<p>Users</p>
							<span class="notification blue">1.367</span>
						</a>
						<a class="quick-button span2">
							<i class="icon-comments-alt"></i>
							<p>Comments</p>
							<span class="notification green">167</span>
						</a>
						<a class="quick-button span2">
							<i class="icon-shopping-cart"></i>
							<p>Orders</p>
						</a>
						<a class="quick-button span2">
							<i class="icon-barcode"></i>
							<p>Products</p>
						</a>
						<a class="quick-button span2">
							<i class="icon-envelope"></i>
							<p>Messages</p>
						</a>
						<a class="quick-button span2">
							<i class="icon-calendar"></i>
							<p>Calendar</p>
							<span class="notification red">68</span>
						</a>						
					</div>	
				</div><!--/span-->
				
			</div>
			
			
       

	</div><!--/.fluid-container-->	
			<!-- end: Content -->			
		</div><!--/#content.span10-->
		</div><!--/fluid-row-->		
	<div class="clearfix"></div>	
	<?php //include 'footer.php'; ?>	
	
</body>
</html>
