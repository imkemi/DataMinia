<?php
  session_start();

  if(!$_SESSION['email'])
  {

      header("Location: login.php");//redirect to login page to secure the welcome page without login access.
  }

  ?>
  
  <html>
<head>
  <?php include'appheader.php'; ?>
  
<title>white Blinds</title>

</head>
<body>
  <div class="navbar">
    <div class="navbar-inner">
      <?php include 'topheader.php' ?>
<style>
    .login-panel {
        margin-top: 150px;
    }
    .table {
        margin-top: 50px;

    }

</style>
  <!-- start: Header -->

    <div class="container-fluid-full">
    <div class="row-fluid">

      <!-- start: Main Menu -->

      <!-- end: Main Menu -->

      <noscript>
        <div class="alert alert-block span10">
          <h4 class="alert-heading">Warning!</h4>
          <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
        </div>
      </noscript>
      <?php include 'left_menu.php'; ?>

      <!-- start: Content -->
      <div id="content" class="span10">


      <ul class="breadcrumb">
        <li>
          <i class="icon-home"></i>
          <a href="dashboard.php">Home</a>
          <i class="icon-angle-right"></i>
        </li>
        <li><a href="imageupload.php">Upload Product Image</a></li>
      </ul>
	  
	  
	  <div id="my_main_div" style="
    width: 20%;
        box-shadow: 1px 1px 3px 1px rgb(158, 158, 158);
    background: rgba(249, 249, 249, 0.39);
    border-radius: 6px;
    padding: 10px 25px;
    float: left;text-align:center;
    margin-bottom: 10px;">
                   <form role="form" method="post" action="">
                        <fieldset>
						    <h3>Select Data Base</h3>
                            <div class="form-group">
                                <select class = "input_class" id="selctdb" name="selctdb">
                                   <option value = "basswood_blinds" >Basswood Blinds</option>
                                   <option value = "faux_blinds" >Faux Blinds</option>
                                 </select>
                            </div><br>
                            <input class="btn btn-lg btn-success btn-block" type="submit" value="submit" name="submit">

                        </fieldset>
                    </form>					
		</div> 
		
	
<?php
        include("database/db_conection.php");
        if(isset($_POST['submit']))
        {
        $seldb=$_POST['selctdb'];//here getting result from the post array after submitting the form.      
 
  		  		
	       
        
        if($seldb == 'basswood_blinds'){
			?>
			<table class="table table-bordered table-hover table-striped" style="table-layout: fixed" id="product_tables">
		 <thead>
			 <tr>
			    <th>Product Id</th>
				<th>Material Type</th>
				<th>Height(Inch)</th>
				<th>Width(Inch)</th>
				<th>Price</th>
				<th>Min price</th>
				<th>Secondary id</th>
				<th>Sku</th>               				
				
			 </tr>
		 </thead>
		 <tbody>
		 <?php
		  $view_users_query="select * from basswood_blinds";//select query for viewing users.
          $run1=mysqli_query($dbcon,$view_users_query);//here run the sql query.
		  while($row=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
           {
            $product_idd=$row[0];
            $height_ftt=$row[1];
            $width_ftt=$row[2];
			$material_typee=$row[3];
            $row5=$row[4];
			$row6=$row[5];
			$row7=$row[6];
			$row8=$row[7];	
?>	

		 <tr>
  
    
		            <td><?php echo $product_idd; ?></td>
					<td><?php echo $material_typee; ?> </td>
		            <td><?php echo $height_ftt; ?> </td>
		            <td><?php echo $width_ftt; ?> </td>		            
		            <td> <?php echo $row5; ?> </td>
		            <td><?php echo $row6; ?> </td>
		            <td> <?php echo $row7; ?> </td>
					<td> <?php echo $row8; ?> </td>
					
		  </tr>
		 <?php    
		   }		    	   
         ?>
</tbody>
</table>
<?php }
else  if($seldb == 'faux_blinds'){
	
	?>
	<table class="table table-bordered table-hover table-striped" style="table-layout: fixed" id="product_tables">
		 <thead>
			 <tr>
			    <th>Product Id</th>
				<th>Material Type</th>
				<th>Height(Inch)</th>
				<th>Width(Inch)</th>
				<th>Price</th>
				<th>Min price</th>
				<th>Secondary id</th>
				<th>Sku</th>               				
				
			 </tr>
		 </thead>
		 <tbody>
		 <?php
          $view_users_query="select * from faux_blinds";//select query for viewing users.
          $run1=mysqli_query($dbcon,$view_users_query);//here run the sql query.
		  while($row=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
           {
            $product_idd=$row[0];
            $height_ftt=$row[1];
            $width_ftt=$row[2];
			$material_typee=$row[3];
            $row5=$row[4];
			$row6=$row[5];
			$row7=$row[6];
			$row8=$row[7];	
?>	
		 <tr>
  
    
		            <td><?php echo $product_idd; ?></td>
					<td><?php echo $material_typee; ?> </td>
		            <td><?php echo $height_ftt; ?> </td>
		            <td><?php echo $width_ftt; ?> </td>		            
		            <td> <?php echo $row5; ?> </td>
		            <td><?php echo $row6; ?> </td>
		            <td> <?php echo $row7; ?> </td>
					<td> <?php echo $row8; ?> </td>
					
		  </tr>
		 <?php    
		   }		    	   
         ?>
</tbody>
</table>
	
		<?php } }?>
					
</div><!--/.fluid-container-->	
			<!-- end: Content -->			
		</div><!--/#content.span10-->
		</div><!--/fluid-row-->		
	<div class="clearfix"></div>	
	
</body>
</html>
