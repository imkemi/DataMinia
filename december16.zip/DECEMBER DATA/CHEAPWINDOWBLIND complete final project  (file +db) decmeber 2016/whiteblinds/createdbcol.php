<?php
  session_start();

  if(!$_SESSION['email'])
  {

      header("Location: login.php");//redirect to login page to secure the welcome page without login access.
  }

  ?>
  
  <html>
<head>
  <?php include'appheader.php'; ?>
  
<title>white Blinds</title>

</head>
<body>
  <div class="navbar">
    <div class="navbar-inner">
      <?php include 'topheader.php' ?>
<style>
    .login-panel {
        margin-top: 150px;
    }
    .table {
        margin-top: 50px;

    }

</style>
  <!-- start: Header -->

    <div class="container-fluid-full">
    <div class="row-fluid">

      <!-- start: Main Menu -->

      <!-- end: Main Menu -->
      <?php include 'left_menu.php'; ?>

      <!-- start: Content -->
      <div id="content" class="span10">


      <ul class="breadcrumb">
        <li>
          <i class="icon-home"></i>
          <a href="dashboard.php">Home</a>
          <i class="icon-angle-right"></i>
        </li>
        <li><a href="imageupload.php">Upload Product Image</a></li>
      </ul>
                   <div id="my_main_div" style="
    width: 20%;
        box-shadow: 1px 1px 3px 1px rgb(158, 158, 158);
    border-radius: 6px;
    padding: 10px 25px;
    float: left;text-align:center;background: rgba(249, 249, 249, 0.6);">
                   <form role="form" method="post" action="">
                        <fieldset><h3>Add New Coloum In Data Base</h3>
                            <div class="form-group"><h4>Data Base Name</h4>
                                <input class="form-control" placeholder="Database Name" name="dbname" type="text" value="">
                            </div>

                            <div class="form-group"><h4>Add New Column</h4>
                                <input class="form-control" placeholder="Ex: Name Varchar (50)" name="dbcolm" type="text" value="">
                            </div>
                            <div class="form-group"><h4>Enter After Coloum Name<h4>
                                <input class="form-control" placeholder="After column Name" name="afterbefore" type="text" value="">
                            </div>


                            <input class="btn btn-lg btn-success btn-block" type="submit" value="submit" name="submit">

                        </fieldset>
                    </form>					
					</div> 
  
  <?php

      include("database/db_conection.php");//make connection here
       if(isset($_POST['submit']))
        {
    $dbname=$_POST['dbname'];//here getting result from the post array after submitting the form.
    $dbcolm=$_POST['dbcolm'];//same
    $afterbefore=$_POST['afterbefore'];//same
	echo '<h5>New column "'. $dbcolm . '" Has Been Successfully Add in Database "' . $dbname . '" After The "' . $afterbefore . '" Column</h5>';
	
     $update_query="ALTER TABLE $dbname ADD $dbcolm  after $afterbefore";
      $run=mysqli_query($dbcon,$update_query);//here run the sql query.
		  
		   
		 if($run) {
           echo "New Coloum Insert in database sucessfully";
                }
		   else{
			   echo "Not insert new coloum In Database";
		   }
		}
		   
		   
?>
</div><!--/.fluid-container-->	
			<!-- end: Content -->			
		</div><!--/#content.span10-->
		</div><!--/fluid-row-->		
	<div class="clearfix"></div>	
	<?php //include 'footer.php'; ?>	
	
</body>
</html>



