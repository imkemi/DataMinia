<?php
  session_start();

  if(!$_SESSION['email'])
  {

      header("Location: login.php");//redirect to login page to secure the welcome page without login access.
  }

  ?>
<html>
<head>
  <?php include'appheader.php'; ?>
  
<title>white Blinds</title>

</head>
<body>
  <div class="navbar">
    <div class="navbar-inner">
      <?php include 'topheader.php' ?>
<style>
    .login-panel {
        margin-top: 150px;
    }
    .table {
        margin-top: 50px;

    }

</style>
  <!-- start: Header -->

    <div class="container-fluid-full">
    <div class="row-fluid">

      <!-- start: Main Menu -->

      <!-- end: Main Menu -->

      <noscript>
        <div class="alert alert-block span10">
          <h4 class="alert-heading">Warning!</h4>
          <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
        </div>
      </noscript>
      <?php include 'left_menu.php'; ?>

      <!-- start: Content -->
      <div id="content" class="span10">


      <ul class="breadcrumb">
        <li>
          <i class="icon-home"></i>
          <a href="index.html">Home</a>
          <i class="icon-angle-right"></i>
        </li>
        <li><a href="#">Add Product</a></li>
      </ul>


<?php
         include("database/db_conection.php");

       /*  if(isset($_POST['submit'])) {
                       
            $product_price = $_POST['product_price'];
            $compare_id = $_POST['compare_id'];
			$product_id=$_POST['product_id'];
			$min_prices=$_POST['min_prices'];
			
			//echo '<p>'.$product_id. '</p>';
			//echo '<p>'.$product_price.'</p>';
			//echo '<p>'.$compare_id. '</p>';
			//echo implode(" ",$product_price)."<br>";
			//echo implode(" ",$compare_id)."<br>";
			//echo implode(" ",$product_id)."<br>";
			//echo $min_prices;
			
			//print_r($product_price);
			//print_r($compare_id);
			//print_r($product_id);			
			//$display_order=array($product_price);				
			//$ids=1; $product_ids=0; 
          //  $rowCount = count($_POST["compare_id"]);
           // echo $rowCount;			
			// An array containing the category ids as keys and the new positions as values
//$display_order = array(
  //  1 => 10,
  //  2 => 20,
  //  3 => 30, Full texts	

  ///  4 => 40
//);

$ids = implode(',', array_keys($product_price));
$sql = "UPDATE basswood_blinds SET minimum_price = $min_prices , price = CASE id ";
foreach ($product_price as $id => $ordinal) {
    $sql .= sprintf("WHEN %d THEN %d ", $id, $ordinal);
}
$sql .= "END WHERE id IN ($ids)";
//echo $sql;  

$run=mysqli_query($dbcon,$sql);
   
    if($run>0)
    {
        echo '<script> alert("Your Product are successfully Updated"); window.location.href = "product_update.php";</script>';

    }
    else
    {
        echo "<script> alert('Product Are Not Updated'); </script>";
    }
			
   
		 
}*/
	?>
	
	<div id="msg"></div>
 <div class="box span12" id="main_table_div">
					<div class="box-header">
						<h2><i class="halflings-icon align-justify"></i><span class="break"></span>BASSWOOD 2" Blinds Price Change Table</h2>
						<div class="box-icon">
							<!-- <a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a> -->
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<!-- <a href="#" class="btn-close"><i class="halflings-icon remove"></i></a> -->
						</div>
					</div>
					<div class="box-content">
					
						<table class="table table-striped" id="product_table_id">
							  <thead>
								  <tr>
								      <th></th>
									  <th>24</th>
									  <th>27</th>
									  <th>30</th>
									  <th>33</th>
									  <th>36</th>
									  <th>39</th>
									  <th>42</th>
									  <th>45</th>
									  <th>48</th>
									  <th>51</th>
									  <th>54</th>
									  <th>57</th>
									  <th>60</th>
									  <th>63</th>
									  <th>66</th>
									  <th>69</th>									  
									  <th>72</th>
                                      <th></th>									  
									  
								  </tr>
							  </thead>   
							  <tbody>
							    <form id="uploadForm" action="kk.php" method="post">
								<tr><td><b>36</b></td>
																	                                   
								
					
        <?php
         $update_id=$_GET['update_value'];
         $update_query="select * from basswood_blinds WHERE secondary_id='$update_id'";///select query for update user users.
         $run=mysqli_query($dbcon,$update_query);//here run the sql query.
         $cont=1;
	
        while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
        {
           // $product_id=$row[0];
           // $height_ft=$row[1];
           // $width_ft=$row[2];
            $material_type=$row[3];
			//$product_price=$row[4];
			$min_price=$row[5];
			//$compare_price=$row[6];
			$sku=$row[7];
         	
		 
		
        ?>
         
        <?php 
		     //if($cont == 18 || $cont == 35 || $cont == 52 || $cont == 69 || $cont == 86 || $cont == 103 || $cont == 120 || $cont == 137 || $cont == 154 || $cont == 171)
			//{   
         	//	echo '<br>';
				
			//}
			
		    if($cont >=1 && $cont<=17)
		    { 
	            // echo $cont; 
				
		       // echo '<td>$'.$product_price.'</td>';?>
				<td><input type="hidden" name="product_id[]" id="product_id" value="<?php echo $row['id']; ?>" readable />
				<span id="my_doller">$</span><span><input type="text" name="product_price[]" id="product_price" value="<?php echo $row['price']; ?>"/></span>
				<input type="hidden" name="compare_id[]" id="compare_id" value="<?php echo $row['secondary_id']  ?>"  readable /></td>
		   <?php
		   }
			if($cont == 18){				
				echo '<td><b>36</b></td>';
			}
            
			if($cont == 18){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>42</b></td>';
			}
		    if($cont >= 18 && $cont <=34)
		    { 
	             //echo $cont;
		         //echo '<td>$'.$product_price.'</td>';
				 ?>
				 <td> <input type="hidden" name="product_id[]" id="product_id" value="<?php echo $row['id']; ?>" readable />
				<span id="my_doller">$</span><span><input type="text" name="product_price[]" id="product_price" value="<?php echo $row['price']; ?>"/></span>
				<input type="hidden" name="compare_id[]" id="compare_id" value="<?php echo $row['secondary_id']  ?>"  readable /></td>
		    <?php
			}
			if($cont == 35){				
				echo '<td><b>42</b></td>';
			}
			if($cont == 35){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>48</b></td>';
			}
			if($cont > 34 && $cont <=51)
		    { 
	             // echo $cont;
		        //echo '<td>$'.$product_price.'</td>';
				?>
				<td> <input type="hidden" name="product_id[]" id="product_id" value="<?php echo $row['id']; ?>" readable />
				<span id="my_doller">$</span><span><input type="text" name="product_price[]" id="product_price" value="<?php echo $row['price']; ?>"/></span>
				<input type="hidden" name="compare_id[]" id="compare_id" value="<?php echo $row['secondary_id']  ?>"  readable /></td>
				<?php
			}
			if($cont == 52){				
				echo '<td><b>48</b></td>';
			}
			if($cont == 52){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>54</b></td>';
			}
			if($cont > 51 && $cont <=68)
		    { 
	             // echo $cont;
		         //echo '<td>$'.$product_price.'</td>';
				 ?>
				 <td> <input type="hidden" name="product_id[]" id="product_id" value="<?php echo $row['id']; ?>" readable />
				<span id="my_doller">$</span><span><input type="text" name="product_price[]" id="product_price" value="<?php echo $row['price']; ?>"/></span>
				<input type="hidden" name="compare_id[]" id="compare_id" value="<?php echo $row['secondary_id']  ?>"  readable /></td>
				<?php
			}
			if($cont == 69){				
				echo '<td><b>54</b></td>';
			}
			if($cont == 69){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>60</b></td>';
			}
			if($cont > 68 && $cont <=85)
		    { 
	             // echo $cont;
		        //echo '<td>$'.$product_price.'</td>';
				?>
			<td> <input type="hidden" name="product_id[]" id="product_id" value="<?php echo $row['id']; ?>" readable />
				<span id="my_doller">$</span><span><input type="text" name="product_price[]" id="product_price" value="<?php echo $row['price']; ?>"/></span>
				<input type="hidden" name="compare_id[]" id="compare_id" value="<?php echo $row['secondary_id']  ?>"  readable /></td>
			<?php
			}
			if($cont == 86){				
				echo '<td><b>60</b></td>';
			}
			if($cont == 86){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>66</b></td>';
			}
			if($cont > 85 && $cont <=102)
		    { 
	             // echo $cont;
		        //echo '<td>$'.$product_price.'</td>';
				?>
			<td> <input type="hidden" name="product_id[]" id="product_id" value="<?php echo $row['id']; ?>" readable />
				<span id="my_doller">$</span><span><input type="text" name="product_price[]" id="product_price" value="<?php echo $row['price']; ?>"/></span>
				<input type="hidden" name="compare_id[]" id="compare_id" value="<?php echo $row['secondary_id']  ?>"  readable /></td>
			<?php
			}
			if($cont == 103){				
				echo '<td><b>66</b></td>';
			}
			if($cont == 103){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>72</b></td>';
			}
			if($cont > 102 && $cont <=119)
		    { 
	            //  echo $cont;
		        //echo '<td>$'.$product_price.'</td>';
			?>
			<td> <input type="hidden" name="product_id[]" id="product_id" value="<?php echo $row['id']; ?>" readable />
				<span id="my_doller">$</span><span><input type="text" name="product_price[]" id="product_price" value="<?php echo $row['price']; ?>"/></span>
				<input type="hidden" name="compare_id[]" id="compare_id" value="<?php echo $row['secondary_id']  ?>"  readable /></td>
				<?php
			}
			if($cont == 120){				
				echo '<td><b>72</b></td>';
			}
			if($cont == 120){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>78</b></td>';
			}
			if($cont > 119 && $cont <=136)
		    { 
	             // echo $cont;
		        //echo '<td>$'.$product_price.'</td>';
			?>
			<td> <input type="hidden" name="product_id[]" id="product_id" value="<?php echo $row['id']; ?>" readable />
				<span id="my_doller">$</span><span><input type="text" name="product_price[]" id="product_price" value="<?php echo $row['price']; ?>"/></span>
				<input type="hidden" name="compare_id[]" id="compare_id" value="<?php echo $row['secondary_id']  ?>"  readable /></td>
				<?php
			}
			if($cont == 137){				
				echo '<td><b>78</b></td>';
			}
			if($cont == 137){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>84</b></td>';
			}
			if($cont > 136 && $cont <=153)
		    { 
	             // echo $cont;
		        //echo '<td>$'.$product_price.'</td>';
				?>
		     <td> <input type="hidden" name="product_id[]" id="product_id" value="<?php echo $row['id']; ?>" readable />
				<span id="my_doller">$</span><span><input type="text" name="product_price[]" id="product_price" value="<?php echo $row['price']; ?>"/></span>
				<input type="hidden" name="compare_id[]" id="compare_id" value="<?php echo $row['secondary_id']  ?>"  readable /></td>
				
			<?php
			}
			if($cont == 154){				
				echo '<td><b>84</b></td>';
			}
			if($cont == 154){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>90</b></td>';
			}
			if($cont > 153 && $cont <=170)
		    { 
	            //echo $cont;
		        //echo '<td>$'.$product_price.'</td>';
			?>
			<td> <input type="hidden" name="product_id[]" id="product_id" value="<?php echo $row['id']; ?>" readable />
				<span id="my_doller">$</span><span><input type="text" name="product_price[]" id="product_price" value="<?php echo $row['price']; ?>"/></span>
				<input type="hidden" name="compare_id[]" id="compare_id" value="<?php echo $row['secondary_id']  ?>"  readable /></td>
			<?php
			}
			if($cont == 171){				
				echo '<td><b>90</b></td>';
			}
			if($cont == 171){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>96</b></td>';
			}
			if($cont > 170 && $cont <=188)
		    { 
	            //echo $cont;
		        //echo '<td>$'.$product_price.'</td>';
			?>
			<td> <input type="hidden" name="product_id[]" id="product_id" value="<?php echo $row['id']; ?>" readable />
				<span id="my_doller">$</span><span><input type="text" name="product_price[]" id="product_price" value="<?php echo $row['price']; ?>"/></span>
				<input type="hidden" name="compare_id[]" id="compare_id" value="<?php echo $row['secondary_id']  ?>"  readable /></td>
			<?php
			}
			if($cont == 187){				
				echo '<td><b>96</b></td>';
			}
					
		   
	        ?>
	
	
		<!-- <td><input type="text" name="product_price" id="product_price" value="<?php //echo $product_price;  ?>" readonly />    </td> -->
             

        <?php 
		//echo $cont;
		$cont++;
		
		}  ?>	
       <tr><td></td><td><b>24</b></td><td><b>27</b></td><td><b>30</b></td><td><b>33</b></td><td><b>36</b></td><td><b>39</b></td>
	   <td><b>42</b></td><td><b>45</b></td><td><b>48</b></td><td><b>51</b></td><td><b>54</b></td><td><b>57</b></td><td><b>60</b></td>
	   <td><b>63</b></td><td><b>66</b></td><td><b>69</b></td><td><b>72</b></td></tr> 		
      		
								                          
	</tbody>
 </table>  
<div id="table_footer_div">
<div id="table_footer_div_left">
<span id="min_price">Minimum Price = $<input type="text" name="min_prices" id="min_prices" value="<?php echo $min_price;  ?>"/></span>
<span id="min_price">SKU Price = <input type="text" name="min_sku" id="min_sku" value="<?php echo $sku ; ?>"/></span>
<span id="min_price">Product Name = <input type="text" name="proname" id="proname" value="<?php echo $material_type ; ?>"/></span> 


        <?php
        include("database/db_conection.php");
        $view_users_query="select * from product_imgs WHERE id = 0 ";//select query for viewing users.
        $run=mysqli_query($dbcon,$view_users_query);//here run the sql query.		
       	//header("Content-type: image/jpeg");
	
        while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
        {
           // $product_ids=$row[0];	
           // $product_name=$row[1];			
            $product_images=$row[2];
			//$com_id=$row[3];	
			
        ?>
		
			
		<?php echo '<span id="min_prices"><img src="'.$product_images.'" width="50px" height="50px" /></span>' ?>
       <?php // '<span id="min_prices"></span><img src="data:image/jpeg;base64,'.base64_encode($product_images).'"width="50px" height="50px" />'; ?>		
      		
		<?php }?>	
</div><!-- able_footer_div_left -->
<div id="table_footer_div_right">

</div><!-- able_footer_div_rifgt -->
</div><!-- table_footer_div -->
<div id="table_footer_div1">


<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script type="text/javascript">
$(document).ready(function (e) {
	$("#uploadForm").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "kk.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
			success: function(data)
		    {
			$("#targetLayer").html(data);
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>


<div id="targetLayer">No Image</div>
<div id="uploadFormLayer">
<label>Upload Image File:</label><br/>
<input type="text" name="product_ids" id="product_ids" value="0">
<input name="userImage" type="file" class="inputFile" />
<input type="submit" value="Submit" class="btnSubmit" />
</form>
</div>
</div>

</div><!-- table_footer_div1 -->
</div><!-- main_table_div -->
    </div>
</div>
</div><!--/.fluid-container-->

    <!-- end: Content -->
  </div><!--/#content.span10-->
  </div><!--/fluid-row-->
<div class="clearfix"></div>

<?php include 'footer.php'; ?>
<script>
function btnconferm() {
    alert("Are You confirm ? Click Ok To Update");
}
</script>

</body>

</html>






