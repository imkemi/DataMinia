<?php
/**
 * Created by Kamal Kunwar.
 * User: Cheap White Blinds
 * Date: 11/21/2016
 * Time: 1:13 PM
 */

$dbcon=mysqli_connect("localhost","root","");

mysqli_select_db($dbcon,"users");

?>
