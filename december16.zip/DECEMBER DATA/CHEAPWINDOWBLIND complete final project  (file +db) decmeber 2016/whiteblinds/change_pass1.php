<?php
//error_reporting(0);
include("database/db_conection.php");
//if(isset($_POST['change']))
//{	
    error_reporting(0);
    $sql;
    $user_email= $_POST['email'];
    $user_oldpass1= $_POST['passsing'];	
    $user_newpasss= $_POST['passs'];
	$user_confnewpasss= $_POST['passss'];
	//echo '<p>old pass:- ' .$user_oldpass1 . '<p>';
	//echo $user_email;
	//echo '<br>';
    //echo '<p>new pass:- ' .$user_newpasss . '<p>';
	
	if($user_oldpass1 == ""){
		echo '<b id="errormsz">Enter The Old Password</b>';
	}
	else if($user_newpasss == ""){
		echo '<b id="errormsz">Enter The New Password</b>';
	}
	else if($user_confnewpasss == ""){
		echo '<b id="errormsz">Enter The Confirm Password</b>';
	}
	else if($user_newpasss != $user_confnewpasss){
		echo '<b id="errormsz">New Password & Confirm Password Does Not Match</b>';
	}
	else if($user_oldpass1 !="" && $user_newpasss !="" && $user_confnewpasss !=""){
	
	
             $check_user="select * from users WHERE user_email='$user_email'";
             $run=mysqli_query($dbcon,$check_user);
	
	          while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
              {
	               $dbpass=$row['user_pass'];
	               $nme=$row['user_email'];
	
	              //echo '<p>databese pass:- ' .$dbpass . '<p>';
	               //echo '<p>user_email:- ' .$nme . '<p>';
	            if ($dbpass == $user_oldpass1)
	           	{
		            	$sql ="UPDATE users SET user_pass='$user_newpasss' WHERE user_email='$user_email'";
			
		
		        } 

	           $ru=mysqli_query($dbcon,$sql);   
               if($ru)
               {
                   echo '<script> alert("Your Password are successfully Updated"); window.location.href = "dashboard.php";</script>';

                }
                else
                {
                       echo '<b id="errormsz">Your Old Password Is Incorrect.! Try Again </b>';
                 }
		
             //echo $sql;
	    }
	//}
}
?>