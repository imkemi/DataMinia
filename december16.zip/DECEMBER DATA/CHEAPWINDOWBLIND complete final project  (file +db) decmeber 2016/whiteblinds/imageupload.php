<?php
  session_start();

  if(!$_SESSION['email'])
  {

      header("Location: login.php");//redirect to login page to secure the welcome page without login access.
  }

  ?>
<html>
<head>
  <?php include'appheader.php'; ?>
  
<title>white Blinds</title>

</head>
<body>
  <div class="navbar">
    <div class="navbar-inner">
      <?php include 'topheader.php' ?>
<style>
    .login-panel {
        margin-top: 150px;
    }
    .table {
        margin-top: 50px;

    }

</style>
  <!-- start: Header -->

    <div class="container-fluid-full">
    <div class="row-fluid">

      <!-- start: Main Menu -->

      <!-- end: Main Menu -->

      <noscript>
        <div class="alert alert-block span10">
          <h4 class="alert-heading">Warning!</h4>
          <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
        </div>
      </noscript>
      <?php include 'left_menu.php'; ?>

      <!-- start: Content -->
      <div id="content" class="span10">


      <ul class="breadcrumb">
        <li>
          <i class="icon-home"></i>
          <a href="dashboard.php">Home</a>
          <i class="icon-angle-right"></i>
        </li>
        <li><a href="imageupload.php">Upload Product Image</a></li>
      </ul>

	  
	
	<div id="my_main_div">
<h4>Create New Product</h4>
<form action="imageupload1.php" method="post" enctype="multipart/form-data">
<div id="my_main_left">
<h5 id="mainh5id">Product Name:</h5>
<input type="text" name="product_name" id="product_name">
<h5 id="mainh5id">Price:(Number Only)</h5>
<input type="text" name="product_price" id="product_price">
</div><!-- my_main_left -->
<div id="my_main_right">
<h5 id="mainh5id">Product Type:</h5>
<input type="text" name="product_type" id="product_type">
<h5 id="mainh5id">Upload Product Image:</h5>

<input type="file" name="image" id="image" size="40">
</div><!-- my_main_right -->
<div id="my_main_div1">
<h5 id="mainh5id">Product Description:</h5>
<textarea name="product_discrip" id="product_discrip"></textarea>
</div><!-- my_main_div1 -->
<input name="" type="submit" value="upload" id="subm" onclick="btnconferm()"/>
 
</form>
</div><!-- my_main_div -->

<script>
function btnconferm() {
    alert("Are You confirm ? Click Ok To Submit");	
}
</script>
<style>
#my_main_div {
    width: 50%;
   
    border-radius: 6px;
    padding: 10px 25px;float:left;
	    box-shadow: 1px 1px 3px 1px rgb(158, 158, 158);
    background: rgba(249, 249, 249, 0.39);
}
#my_main_div h4{font-size: 25px;}
#my_main_div1{width:100%;float:left;}
#my_main_left{width:48%;float:left;}
#my_main_right{width:48%;float:left;}
#my_main_div input {
    width: 92%;
    height: 35px;
    padding: 10px;
}
#my_main_div textarea{width: 92%;min-height: 182px;}
#subm {
    width: 118px !important;
    border-radius: 5px;
    background: #1681cf;
    color: #fff;
    font-size: 17px;
    text-transform: uppercase;
    border: 1px solid;
    padding: 8px !important;float:left;
}
#subm:hover{text-decoration: none;background: #e05b07;}

#change_image_id {
    border: 2px solid rgba(1, 95, 187, 0.91);
    width: 400px;
    padding: 20px;
    text-align: center;
    border-radius: 5px;
}
#inser {
    margin-left: 0px !important;
    font-size: 16px !important;
    border: 1px solid rgb(224, 137, 25) !important;
    background: rgb(224, 137, 25) none repeat scroll 0% 0% !important;
    color: rgb(255, 255, 255) !important;
    width: 100px !important;
    height: 37px;
    border-radius: 3px;
}
#inser:hover {
    background: rgb(25, 139, 224) none repeat scroll 0% 0% !important;
    border: 1px solid rgb(25, 139, 224) !important;
}  
</style>

</body>
</html>
