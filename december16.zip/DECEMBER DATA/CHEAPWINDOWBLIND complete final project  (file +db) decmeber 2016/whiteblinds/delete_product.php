<?php
    
	session_start();
	
	require __DIR__.'/vendor/autoload.php';
	use phpish\shopify;

	require __DIR__.'/conf.php';

	$shopify = shopify\client(SHOPIFY_SHOP, SHOPIFY_APP_API_KEY, SHOPIFY_APP_PASSWORD, true);
    $ids=$_GET['del'];
	//echo $ids;
     
	
try
	{
		# Making an API request can throw an exception
		$products = $shopify('DELETE /admin/products/'.$ids.'.json', array('published_status'=>'published'));
         if($products>0)
         {
        
		  echo '<script> alert("Your Product are successfully Deleted"); window.location.href = "get_products.php";</script>';
		 // echo "<script>window.open('get_products.php?deleted=Product has been deleted','_self')</script>";
                  
         }
		 else{
			 echo '<script> alert("Your Product are Not Deleted"); window.location.href = "get_products.php";</script>';
		 }
        //print_r($products);
	}
	catch (shopify\ApiException $e)
	{
		# HTTP status code was >= 400 or response contained the key 'errors'
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
	catch (shopify\CurlException $e)
	{
		# cURL error
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
?>
