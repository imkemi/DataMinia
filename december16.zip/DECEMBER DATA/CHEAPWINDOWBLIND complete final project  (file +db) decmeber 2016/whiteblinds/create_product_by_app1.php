<?php
  session_start();

  if(!$_SESSION['email'])
  {

      header("Location: login.php");//redirect to login page to secure the welcome page without login access.
  }

  ?>
<html>
<head>
  <?php include'appheader.php'; ?>
  
<title>white Blinds</title>

</head>
<body>
  <div class="navbar">
    <div class="navbar-inner">
      <?php include 'topheader.php' ?>

  <!-- start: Header -->

    <div class="container-fluid-full">
    <div class="row-fluid">

      <!-- start: Main Menu -->

      <!-- end: Main Menu -->

      <noscript>
        <div class="alert alert-block span10">
          <h4 class="alert-heading">Warning!</h4>
          <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
        </div>
      </noscript>
      <?php include 'left_menu.php'; ?>

      <!-- start: Content -->
      <div id="content" class="span10">


      <ul class="breadcrumb">
        <li>
          <i class="icon-home"></i>
          <a href="index.html">Home</a>
          <i class="icon-angle-right"></i>
        </li>
        <li><a href="#">Add Product</a></li>
      </ul>         
<div id="main-box-division">
      <div class="box-header" data-original-title="">
      <!-- <h2 id="price-previeww" class ="price_previeww"> Unit Price: $0.00</h2></div> 
      <div class="box-header" data-original-title="">
      <h2 id="price-preview" class ="price_preview"> Total Price: $0.00</h2></div> -->
	

       <h2 id="price-previewww" style="text-align:center;">height: </h2>
	      <h2 id="price-previewwww" style="text-align:center;">width: </h2></div>
      <form id="add-item-form" action="/cart/add" method="post" enctype="multipart/form-data">       
       Height: <input type = "text" id = "total_rates" name = "total_rates" value ="">   
	   Width:  <input type = "text" id = "unitt_price" name = "unitt_price" value ="">
		<input type = "text" id = "product_id" name = "id" value ="">
		
		<input type = "text" id = "mat_type1" name = "id" value ="">
        <input type = "text" id = "rates1" name = "id" value =""><br>				
	    <input type = "text" id = "mat_type2" name = "id" value ="">
		<input type = "text" id = "rates2" name = "id" value ="">				
	    
	    
		
        <!--  <div class = "row select clearfix">

            <label> Product </label>

            <select class = "input_class" id="material_type" name="material_type">
              <option value = "BASSWOOD 2 Blinds">BASSWOOD 2" Blinds</option>
              <option value = "FAUX 2 Blinds">FAUX 2" Blinds</option>
            </select>

        </div> -->



        <div class="inch">
          <div class = "row  input_width">

            <label> Height In Feet</label>
            <select class = "input_class" id="height_ft" name="height_ft">
              <option value = "" >Select Height</option>
              <option value = "3">3</option>
              <option value = "4">4</option>
              <option value = "5">5</option>
              <option value = "6">6</option>
              <option value = "7">7</option>
              <option value = "8">8</option>                           
            </select>
            <p class ="show_single_error" id="height_ft_error"></p>

          </div>
		  <div class = "row  input_width">

            <label> Height In Inches</label>
            <select class = "input_class" id="height_inch" name="height_inch">
              <option value = "" >Select Height</option>
              <option value = "0">0</option>
              <option value = "1">1</option>
              <option value = "2">2</option>
              <option value = "3">3</option>
              <option value = "4">4</option>
              <option value = "5">5</option>
              <option value = "6">6</option>
              <option value = "7">7</option>
              <option value = "8">8</option>
              <option value = "9">9</option>
              <option value = "10">10</option>
			  <option value = "11">11</option>
			  <option value = "12">12</option>
            </select>
            <p class ="show_single_error" id="height_inch_error"></p>

          </div>
        </div>


          <div class="inch">
      	  <div class = "row  input_width">
                  <label> Width In Feet</label>
    <select class = "input_class" id="width_ft" name="width_ft">
              <option value = "" >Select Width</option>
			  <option value = "2">2</option>
              <option value = "3">3</option>
              <option value = "4">4</option>
              <option value = "5">5</option>
              <option value = "6">6</option>              
            </select>
                  <p class ="show_single_error" id="width_ft_error"></p>
          </div>
		   <div class = "row  input_width">

            <label> Width In inches</label>
              <select class = "input_class" id="width_inch" name="width_inch">
              <option value = "" >Select Height</option>
              <option value = "0">0</option>
              <option value = "1">1</option>
              <option value = "2">2</option>
              <option value = "3">3</option>
              <option value = "4">4</option>
              <option value = "5">5</option>
              <option value = "6">6</option>
              <option value = "7">7</option>
              <option value = "8">8</option>
              <option value = "9">9</option>
              <option value = "10">10</option>
			  <option value = "11">11</option>
			  <option value = "12">12</option>
            </select>
            <p class ="show_single_error" id="width_inch_error"></p>

          </div>
        </div>

     <div class="inch">
    <div class = "row select ">
                <label> Mounting Style: </label>

                  <select class = "input_class" id="mountingstyle" name="mountingstyle">
                    <option value = "Inside" >Inside</option>
                    <option value = "Outside" >Outside</option>
                  </select>
        </div></div>


     <!-- <div class = "row clearfix">
          	<label> Qty </label>
          	<input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1">
          	<p class ="show_single_error" id="quantity_error"></p>
        </div> -->


        <div class = "row  margin_left pro_bar">
            <input type="button" id="call_api" class="add_to_cart_btn button btn_style" name="call_api" value = "Find Rates" >
        </div>
      </form>
</div><!-- main-box-division -->
  <!-- For displaying a message -->
      <br><div id="message"></div>

</div><!--/.fluid-container-->

    <!-- end: Content -->
  </div><!--/#content.span10-->
  </div><!--/fluid-row-->
<div class="clearfix"></div>
<?php include 'footer.php'; ?>
<!-- The ajax/jquery stuff -->

<script type="text/javascript">
$(document).ready(function(){
//Get the input data using the post method when Push into mysql is clicked .. we pull it using the id fields of ID, Name and Email respectively...
  $('.input_class').change(function(){

        var material_type=$("#material_type").val();
        var height_ft=$("#height_ft").val();
        var height_inch=$("#height_inch").val();
        var width_ft=$("#width_ft").val();
        var width_inch=$("#width_inch").val();
        var mountingstyle=$("#mountingstyle").val();
        var quantity=$("#quantity").val();
        var total_rates=$("#total_rates").val();
        var unitt_price=$("#unitt_price").val();
        
		var rates_chenge_height = parseInt(height_ft) * 12;
        var total_height = rates_chenge_height + parseInt(height_inch);
		var rates_chenge_width = parseInt(width_ft) * 12;			  
        var total_width = rates_chenge_width + parseInt(width_inch);
			  
              //q_rates = parseFloat(q_rates);
			  //$("#price-preview").empty();
              //$("#price-preview").append(' Total Price: $' + q_rates);
              //$("#price-previeww").empty();
              //$("#price-previeww").append('Unit Price: $' +  rates);
             // $("#total_rates").val(q_rates);
             // $("#unitt_price").val(rates);
		      //$('#call_api').removeAttr('disabled');
              
		$("#price-previewww").empty();
        $("#price-previewww").append('height: $' +  total_height); 
        $("#price-previewwww").empty();			  
		$("#price-previewwww").append('width: $' +  total_width);   
        $("#total_rates").val(total_height);
        $("#unitt_price").val(total_width);			  
        $('#call_api').removeAttr('disabled');
	
//validation on width in inches value is greter then table field
    if(parseInt(width_ft) == '6' && parseInt(width_inch) == '1'){
		 $("#width_inch").addClass( "field_error" );
         $("#width_inch_error").empty();
         $("#width_inch_error").append("<b>Maximum Width Selection Is 6 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
	
    else if(parseInt(width_ft) == '6' && parseInt(width_inch) == '2'){
		 $("#width_inch").addClass( "field_error" );
         $("#width_inch_error").empty();
         $("#width_inch_error").append("<b>Maximum Width Selection Is 6 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
			
	
	
 });
$("#call_api").click(function(){
//Get values of the input fields and store it into the variables.
var material_type=$("#material_type").val();
var height_ft=$("#height_ft").val();
var height_inch=$("#height_inch").val();
var width_ft=$("#width_ft").val();
var width_inch=$("#width_inch").val();
var mountingstyle=$("#mountingstyle").val();
var quantity=$("#quantity").val();
var total_height=$("#total_rates").val();
var total_width=$("#unitt_price").val();  
   
   //validation on width in feet field

     if(width_inch == ""){

		 $("#width_inch").addClass( "field_error" );
         $("#width_inch_error").empty();
         $("#width_inch_error").append("<b>Width in feet field is required</b>");
		 $('#call_api').attr('disabled','disabled');

        }else{

           $("#width_ft").removeClass( "field_error" );

           $("#width_ft_error").empty();

           $('#call_api').removeAttr('disabled');


        }
		//validation on width in Inch field

      if(width_ft == ""){

		 $("#width_ft").addClass( "field_error" );
         $("#width_ft_error").empty();
         $("#width_ft_error").append("<b>Width in feet field is required</b>");
		 $('#call_api').attr('disabled','disabled');

        }else{

           $("#width_ft").removeClass( "field_error" );

           $("#width_ft_error").empty();

           $('#call_api').removeAttr('disabled');


        }


      //validation on height in feet field



       if(height_ft == ""){

		 $("#height_ft").addClass( "field_error" );
         $("#height_ft_error").empty();
         $("#height_ft_error").append("<b>Height in feet field is required</b>");

		 $('#call_api').attr('disabled','disabled');

        }else{

           $("#height_ft").removeClass( "field_error" );

           $("#height_ft_error").empty();

           $('#call_api').removeAttr('disabled');


        }
		 //validation on height in Inch field
		 
		 if(height_inch == ""){

		 $("#height_inch").addClass( "field_error" );
         $("#height_inch_error").empty();
         $("#height_inch_error").append("<b>Height in Inch field is required</b>");

		 $('#call_api').attr('disabled','disabled');

        }else{

           $("#height_inch").removeClass( "field_error" );

           $("#height_inch_error").empty();

           $('#call_api').removeAttr('disabled');


        }
  //quantity validation

       // if(quantity <= 0){

          //  $("#quantity").addClass( "field_error" );

         //   $("#quantity_error").empty();
         //   $("#quantity_error").append("<b> Quantity must be greater than zero</b>");
         ///   $('#call_api').attr('disabled','disabled');



       //  }else{

       //     $("#quantity").removeClass( "field_error" );

        //    $("#quantity_error").empty();

        //   $('#call_api').removeAttr('disabled');


        // } 
  
  if(width_ft != "" && height_ft !="" && width_inch != "" && height_inch !=""){

//use the $.post() method to call insert.php file.. this is the ajax request
$.post('create_product_by_app1_price_get.php', {total_height:total_height, total_width:total_width, mountingstyle:mountingstyle},
function(data){
$("#message").html(data);
$("#message").hide();
$("#message").fadeIn(1500); //Fade in the data given by the insert.php file
//alert('Your Product are successfully Submitted');
 
    var $response=$(data);

    //Query the jQuery object for the values
    var materl_type = $response.filter('#product_type').text();
    var materl_type1 = $response.filter('#product_type1').text();
	var rates1 = $response.filter('#new_product_price').text();
	var rates2 = $response.filter('#new_product_price1').text();
	
              
			  $("#mat_type1").val(materl_type);
			  $("#rates1").val(rates1);
              $("#mat_type2").val(materl_type1);
			  $("#rates2").val(rates2);
		      $('#call_api').removeAttr('disabled');
 // console.log('cxbd'+rates);
 // $.ajax({

  //                    	 type: 'POST',
  //                       url: '/cart/add.js',
 //                        cache: false,
  //                       contentType: 'multipart/form-data',
   //						 processData: false,                         
  //                       data: 'quantity=' + quantity + '&id=' + variant_id,
	//					 dataType: 'json',


      //                	 success: function(data)
    //       				 {
     //                     alert('Your Product are successfully Submitted');
                          
							// window.location.href = "http://cheap-white-blinds.myshopify.com/cart";
							

       //                  }
                   



        //              });

});
  }
return false;
});
});

</script>

<script type="text/javascript">

function ajaxindicatorstart(text)
{
	if(jQuery('body').find('#resultLoading').attr('id') != 'resultLoading'){
	jQuery('body').append('<div id="resultLoading" style="display:none"><div><img src="https://cdn.shopify.com/s/files/1/1318/4901/files/ajax-loader.gif?4589250752839393380"><div>'+text+'</div></div><div class="bg"></div></div>');
	}

	jQuery('#resultLoading').css({
		'width':'100%',
		'height':'100%',
		'position':'fixed',
		'z-index':'10000000',
		'top':'0',
		'left':'0',
		'right':'0',
		'bottom':'0',
		'margin':'auto'
	});

	jQuery('#resultLoading .bg').css({
		'background':'#fff',
		'opacity':'0.7',
		'width':'100%',
		'height':'100%',
		'position':'absolute',
		'top':'0'
	});

	jQuery('#resultLoading>div:first').css({
		'width': '100%',
		'height':'60%',
		'text-align': 'center',
		'position': 'fixed',
		'top':'10',
		'left':'0',
		'right':'0',
		'bottom':'0',
		'margin':'auto',
		'font-size':'16px',
		'z-index':'10',
		'color':'#000'

	});

    jQuery('#resultLoading .bg').height('100%');
       jQuery('#resultLoading').fadeIn(1600);
    jQuery('body').css('cursor', 'wait');
}


function ajaxindicatorstop()
{
    jQuery('#resultLoading .bg').height('100%');
       jQuery('#resultLoading').fadeOut(1600);
    jQuery('body').css('cursor', 'default');
}


jQuery(document).ajaxStart(function () {
 		//show ajax indicator
ajaxindicatorstart('loading data.. please wait..');
}).ajaxStop(function () {
//hide ajax indicator
ajaxindicatorstop();
});


jQuery.ajax({
   global: false,
   // ajax stuff
});

</script>
</body>
</html>