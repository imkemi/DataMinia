<?php
//error_reporting(0);
include("database/db_conection.php");
//if(isset($_POST['change']))
//{	
   // error_reporting(0);
    $sql;
    $color= $_POST['color'];
	$material_type= $_POST['material_type'];
	
    
	//echo '<p>old pass:- ' .$user_oldpass1 . '<p>';
	//echo $user_email;
	//echo '<br>';
    //echo '<p>new pass:- ' .$user_newpasss . '<p>';
	 if($material_type == ""){
		echo '<b id="errormsz">Please Select The Product Type</b>';
	}
	else if($color == ""){
		echo '<b id="errormsz">Please Enter The Color</b>';
	}
	
	
	else if($color !="" && $material_type !=""){
		
		    if($material_type == 'basswood_blinds')
			{
				$secondey = '1001001';
			
	            // products_names 	color_names 	secondary_id
	
				$check_email_query="select * from color_table WHERE color_names='$color'";
				$run_query=mysqli_query($dbcon,$check_email_query);

				if(mysqli_num_rows($run_query)>0)
				{
				echo "Color $color is already exist, Please try another one!";
				exit();
				}
				//insert the user into the database.
				$insert_user="insert into color_table (products_names, color_names , secondary_id) VALUE ('$material_type', '$color', '$secondey' )";
				if(mysqli_query($dbcon,$insert_user))
				{
				echo"<script>alert('Color $color is Successfully Added In Basswood Blinds') ;</script><script>window.open('add_color.php','_self')</script>";
				}
			}
			
			else if($material_type == 'faux_blinds')
			{
				$secondey = '1001001';
			
	              // products_names 	color_names 	secondary_id
	
				$check_email_query="select * from color_table1 WHERE color_names='$color'";
				$run_query=mysqli_query($dbcon,$check_email_query);

				if(mysqli_num_rows($run_query)>0)
				{
				echo "Color $color is already exist, Please try another one!";
				exit();
				}
				//insert the user into the database.
				$insert_user="insert into color_table1 (products_names, color_names , secondary_id) VALUE ('$material_type', '$color', '$secondey' )";
				if(mysqli_query($dbcon,$insert_user))
				{
				echo"<script>alert('Color $color is Successfully Added In Faux Blinds') ;</script><script>window.open('add_color.php','_self')</script>";
				}
			}
		
             //echo $sql;
	    }
	//}

?>