<?php
  session_start();

  if(!$_SESSION['email'])
  {

      header("Location: login.php");//redirect to login page to secure the welcome page without login access.
  }

  ?>
<html>
<head>
  <?php include'appheader.php'; ?>
  
<title>white Blinds</title>

</head>
<body>
  <div class="navbar">
    <div class="navbar-inner">
      <?php include 'topheader.php' ?>
<style>
    .login-panel {
        margin-top: 150px;
    }
    .table {
        margin-top: 50px;

    }

</style>
  <!-- start: Header -->

    <div class="container-fluid-full">
    <div class="row-fluid">

      <!-- start: Main Menu -->

      <!-- end: Main Menu -->

      <noscript>
        <div class="alert alert-block span10">
          <h4 class="alert-heading">Warning!</h4>
          <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
        </div>
      </noscript>
      <?php include 'left_menu.php'; ?>

      <!-- start: Content -->
      <div id="content" class="span10">


      <ul class="breadcrumb">
        <li>
          <i class="icon-home"></i>
          <a href="index.html">Home</a>
          <i class="icon-angle-right"></i>
        </li>
        <li><a href="change_pass.php">Change Password</a></li>
      </ul> 

<style>    
#passs,#passss,#passsing{
    height:39px;
    width: 100%;
}
.show_single_error {
    margin-top: -8px;
    text-align: left;
    margin-bottom: 7px;
}
#errormsz{
	color:red;
}
div#targetLayer {
    margin: 10px 0px;
}
#my_main_div {
    width: 30%;
    box-shadow: 1px 1px 3px 1px rgb(158, 158, 158);
    border-radius: 6px;
    padding: 10px 25px;
    float: left;
    text-align: center;
    margin-bottom: 10px;
    background: #f9f9f9;
}

</style>
 <div id="my_main_div">

        <div class="col-md-4 col-md-offset-4">
            <div class="panel panel-success">
                <div class="panel-heading">
				
                    <h3 class="panel-title"> PASSWORD CHANGE </h3>
					<div id="targetLayer"></div>
                </div>
                <div class="panel-body">
                    <form id="uploadForm" method="post" action="change_pass1.php">
                        <fieldset>
                            <div class="form-group">
                               <input class="form_control" placeholder="E-mail" name="email" id="email" type="hidden" value="<?php echo $_SESSION['email'];?>"> 
							  
                            </div>
                            <div class="form-group">
                                <input class="form_control" placeholder="Old Password" name="passsing" id="passsing" type="password" value="">
								<p class ="show_single_error" id="show_ft_error"></p>
                            </div>
							<div class="form-group">
                                <input class="form_control" placeholder="New Password" name="passs" id="passs" type="password" value="">
								<p class ="show_single_error" id="show_ft_error1"></p>
                            </div>
                            <div class="form-group">
							    
                                <input class="form_control" placeholder="Confirm Password" name="passss" id="passss" type="password" value="">
								<p class ="show_single_error" id="show_ft_error2"></p>
								
                            </div>

                                <!-- <input class="btn btn-lg btn-success btn-block" id="  subdata" type="submit" value="Change" name="change"  > -->
			                <!-- <input type="button" id="subdata" class="btn btn-lg btn-success btn-block" name="subdata" value = "Change"> -->	
									<input type="submit" value="Submit" class="btn btn-danger" onclick="btnconferm()" />				

                            <!-- Change this to a button or input when using this as a form -->
                          <!--  <a href="index.html" class="btn btn-lg btn-success btn-block">Login</a> -->
                        </fieldset>
                    </form>
                </div>
            </div>      
</div>
</div><!-- my_main_div -->
</div><!--/.fluid-container-->

    <!-- end: Content -->
  </div><!--/#content.span10-->
  </div><!--/fluid-row-->
<div class="clearfix"></div>

<?php include 'footer.php'; ?>


<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script type="text/javascript">
$(document).ready(function (e) {
	$("#uploadForm").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "change_pass1.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
			success: function(data)
		    {
			$("#targetLayer").html(data);
             //alert("Your Product are successfully Updated"); window.location.href = "product_update_img_sku_price.php";		
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>
<script type="text/javascript">
/*$(document).ready(function(){
	$("#subdata").click(function(){		
		var email = $("#email").val();
	    var oldpassd = $("#passsing").val();
        var newpasss = $("#passs").val();
        var confpassss = $("#passss").val();     
	
		if(oldpassd == ""){		 
         $("#show_ft_error").empty();
         $("#show_ft_error").append("<b>Enter The Old Password</b>");
		// $('#subdata').attr('disabled','disabled');
		$('#subdata').removeAttr('disabled');
		}
		 else if(newpasss == ""){		 
         $("#show_ft_error1").empty();
         $("#show_ft_error1").append("<b>Enter The New Password</b>");
		 //$('#subdata').attr('disabled','disabled');
		 $('#subdata').removeAttr('disabled');
		}
		 else if(confpassss == ""){		 
         $("#show_ft_error2").empty();
         $("#show_ft_error2").append("<b>Enter The Confirm Password</b>");
		 //$('#subdata').attr('disabled','disabled');
		 $('#subdata').removeAttr('disabled');
		}
		else if(newpasss != confpassss){		 
         $("#show_ft_error2").empty();
         $("#show_ft_error2").append("<b>New Password & Confirm Password Does Not Match</b>");
		 //$('#subdata').attr('disabled','disabled');
		 $('#subdata').removeAttr('disabled');
		}
		 else if(email == ""){		 
            alert("You Are Not Logged In! Please Login First"); window.location.href = "login.php";
		}	
		 
		 	 
	    else if(oldpassd !="" && newpasss !="" && confpassss !=""){			
		$.ajax({
        	url: "change_pass1.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
			success: function(data)
		    {
			$("#targetLayer").html(data);
             //alert("Your Product are successfully Updated"); window.location.href = "product_update_img_sku_price.php";		
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	
		}
});
});*/
</script>


</body>

</html>