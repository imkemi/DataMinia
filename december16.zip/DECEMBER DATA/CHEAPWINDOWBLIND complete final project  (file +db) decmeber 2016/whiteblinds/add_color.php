<?php
  session_start();

  if(!$_SESSION['email'])
  {

      header("Location: login.php");//redirect to login page to secure the welcome page without login access.
  }

  ?>
<html>
<head>
  <?php include'appheader.php'; ?>
  
<title>white Blinds</title>

</head>
<body>
  <div class="navbar">
    <div class="navbar-inner">
      <?php include 'topheader.php' ?>
<style>
    .login-panel {
        margin-top: 150px;
    }
    .table {
        margin-top: 50px;

    }

</style>
  <!-- start: Header -->

    <div class="container-fluid-full">
    <div class="row-fluid">

      <!-- start: Main Menu -->

      <!-- end: Main Menu -->

      <noscript>
        <div class="alert alert-block span10">
          <h4 class="alert-heading">Warning!</h4>
          <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
        </div>
      </noscript>
      <?php include 'left_menu.php'; ?>

      <!-- start: Content -->
      <div id="content" class="span10">


      <ul class="breadcrumb">
        <li>
          <i class="icon-home"></i>
          <a href="index.html">Home</a>
          <i class="icon-angle-right"></i>
        </li>
        <li><a href="change_pass.php">Change Password</a></li>
      </ul> 

<style>    
#color{
    height:39px;
    width: 100%;
}
select#material_type {
    width: 100%;
    height: 39px;
}
.show_single_error {
    margin-top: -8px;
    text-align: left;
    margin-bottom: 7px;
}
#errormsz{
	color:red;
}
div#targetLayer {
    margin: 10px 0px;
}
#my_main_div {
    width: 30%;
    box-shadow: 1px 1px 3px 1px rgb(158, 158, 158);
    border-radius: 6px;
    padding: 10px 25px;
    float: left;
    text-align: center;
    margin-bottom: 10px;
    background: #f9f9f9;
	margin-right: 10px;
}
#my_main_div1 {
    width: 60%;
    box-shadow: 1px 1px 3px 1px rgb(158, 158, 158);
    border-radius: 6px;
    padding: 10px 25px;
    float: left;
    text-align: center;
    margin-bottom: 10px;
    margin-right: 10px;
    min-height: 107px;
}
span#color_span {
    padding: 5px 10px;
    border: 1px solid #bdbbbb;
    margin: 5px;
    float: left;
    background: #f9f9f9;
    border-radius: 3px;
}
h5#mynamess {
    text-align: left;
}
</style>
 <div id="my_main_div">

        <div class="col-md-4 col-md-offset-4">
            <div class="panel panel-success">
                <div class="panel-heading">
				
                    <h3 class="panel-title">ADD NEW COLOR </h3>
					<div id="targetLayer"></div>
                </div>
                <div class="panel-body">
                    <form id="uploadForm" method="post" action="add_color1.php">
                        <fieldset>
                             
							    <div class="form-group">
								<h5 id="mynamess"> Select Product </h5>
                                 <select class = "input_class" id="material_type" name="material_type">
								 <option value = "" >Select</option>
                                 <option value = "basswood_blinds">BASSWOOD 2" Blinds</option>
                                 <option value = "faux_blinds">FAUX 2" Blinds</option>
                                 </select>							
                                 </div> 
								 <div class="form-group">
								 <h5 id="mynamess"> Add Color </h5>
                                      <input class="form_control" placeholder="Add New Colors" name="color" id="color" type="text" value=""> 
							  
                                   </div>
                               	
									<input type="submit" value="Submit" class="btn btn-danger" onclick="btnconferm()" />		

                            
                        </fieldset>
                    </form>
                </div>
            </div>      
</div>
</div><!-- my_main_div -->
 <div id="my_main_div1"> <div class="col-md-4 col-md-offset-4">
            <div class="panel panel-success">
                <div class="panel-heading">  <h3 class="panel-title"> BASSWOOD 2" BLINDS ADDED COLOR </h3>
				
				<?php
                 //error_reporting(0);
                 include("database/db_conection.php");
				 //$check_email_query="select * from color_table1 WHERE colors_namess='$color'";
				//$run_query=mysqli_query($dbcon,$check_email_query);
				 $update_query="select * from color_table";///select query for update user users.
                 $run=mysqli_query($dbcon,$update_query);//here run the sql query.
        
	
                 while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
                   {
					    $colors=$row[2];
						echo '<span id="color_span">' .$colors. '</span>';
				   }
                  ?>
				
				
		
		</div>
   </div>      
</div>
				
			</div><!-- my_main_div1 -->
			 <div id="my_main_div1"> <div class="col-md-4 col-md-offset-4">
            <div class="panel panel-success">
                <div class="panel-heading">  <h3 class="panel-title"> FAUX 2" BLINDS ADDED COLOR </h3>
				
				<?php
                 //error_reporting(0);
                 include("database/db_conection.php");
				 //$check_email_query="select * from color_table1 WHERE colors_namess='$color'";
				//$run_query=mysqli_query($dbcon,$check_email_query);
				 $update_query="select * from color_table1";///select query for update user users.
                 $run=mysqli_query($dbcon,$update_query);//here run the sql query.
        
	
                 while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
                   {
					    $colors=$row[2];
						echo '<span id="color_span">' .$colors. '</span>';
				   }
                  ?>
				
				
		
		</div>
   </div>      
</div>
				
			</div><!-- my_main_div1 -->

</div><!--/.fluid-container-->

    <!-- end: Content -->
  </div><!--/#content.span10-->
  </div><!--/fluid-row-->
<div class="clearfix"></div>

<?php include 'footer.php'; ?>


<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script type="text/javascript">
$(document).ready(function (e) {
	$("#uploadForm").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "add_color1.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
			success: function(data)
		    {
			$("#targetLayer").html(data);
             //alert("Your Product are successfully Updated"); window.location.href = "product_update_img_sku_price.php";		
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>


</body>

</html>