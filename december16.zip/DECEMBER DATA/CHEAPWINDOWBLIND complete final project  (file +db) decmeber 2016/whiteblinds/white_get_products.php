<?php
	require __DIR__.'/vendor/autoload.php';
	use phpish\shopify;

	require __DIR__.'/conf.php';

	$shopify = shopify\client(SHOPIFY_SHOP, SHOPIFY_APP_API_KEY, SHOPIFY_APP_PASSWORD, true);

	try
	{ ?>

		<table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
		 <thead>
			 <tr>
				<th>Product Id</th>
				<th>Product Name</th>
				<th>Product Description</th>
				<th>Mounting Style</th>
				 <th>Vendor</th> 
				<th>Handle</th>
				<th>Delete</th>
				
			 </tr>
		 </thead>
		 <tbody>
			 <?php
		# Making an API request can throw an exception
		$products = $shopify('GET /admin/products.json', array('published_status'=>'published'));
		foreach($products as $key=>$value)
		{?>
			 <tr>
			 <td><?php echo $value['id']  ?></td>
			 			 <td><?php echo $value['title']  ?></td>
						 			 <td><?php echo $value['body_html']  ?></td>									 			 
												 			  <td><?php echo $value['product_type']  ?></td> 
															      <td><?php echo $value['vendor'] ?></td>
															 			 <td><?php echo $value['handle']  ?></td>
		 <td><a href="delete_product.php?del=<?php echo $value['id'] ?>"><button class="btn btn-danger" onclick="btnconferm()">Delete</button></a></td> 
		 </tr>
	<?php	}

//echo '<pre>';
//print_r($products);
	}
	catch (shopify\ApiException $e)
	{
		# HTTP status code was >= 400 or response contained the key 'errors'
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
	catch (shopify\CurlException $e)
	{
		# cURL error
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}

?>

<script>
function btnconferm() {
    alert("Are You confirm ? Delete This Product");
}
</script>