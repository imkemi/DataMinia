<?php
	require __DIR__.'/vendor/autoload.php';
	use phpish\shopify;

	require __DIR__.'/conf.php';

	$shopify = shopify\client(SHOPIFY_SHOP, SHOPIFY_APP_API_KEY, SHOPIFY_APP_PASSWORD, true);

    $valuess= $_POST['email'];
	//echo $valuess;
	try
	{ error_reporting(0);
	    if($valuess==1){
		$products = $shopify('GET /admin/orders.json', array('fulfillment_status'=>'fulfilled'));
		//$products1 = $shopify('GET /admin/products.json', array('published_status'=>'unpublished'));
		//$products2 = $shopify('GET /admin/products.json', array('published_status'=>'published'));
		$productvalue=array($products);
			
         //echo '<pre>';
         //print_r($products1);
         //echo '<pre>';
        // print_r($products);
         //print_r($products2);
         //echo '<pre>';
         //print_r($products);
         foreach($products as $value)
	 	 {
			$fulfilled =$value['fulfillment_status'];
			//echo $fulfilled;
			if($fulfilled == 'fulfilled'){
			$vaint = $value['line_items'];
            foreach($vaint as $variantt){
				$fullfill_id = $variantt['product_id'];
			//echo ' <p class="id_cls">'.$variantt['id'].'<p>'; 
			//echo ' <p class="id_cls">'.$fullfill_id.'<p>'; 
			//$pro_update = $shopify('PUT /admin/products/'.$fullfill_id.'.json', array('published_status'=>'published'));
			
			//echo '<pre>';
            //print_r($pro_update);
			# Making an API request can throw an exception
		$pro_update = $shopify('PUT /admin/products/'.$fullfill_id.'.json', array(), array
		(
			'product' => array
			(
				//"title" => "$material_type",
				"published_at" => "",
			)
		));
			
			//echo '<pre>';
           // print_r($pro_update);
		   // echo '<script> alert("Your Product are successfully Updated"); window.location.href = "order_complete_hidden_product.php";</script>';
			
			}
			
			
			
			}
			
			
		}
		//echo '<script> alert("Product are successfully Hide"); window.location.href = "order_complete_hidden_product.php";</script>';
		echo '<script> alert("Order complete product are successfully hide"); window.location.href = "dashboard.php";</script>';
		}
		//else echo '<script> alert("Product are Not Hide..! Try Again"); window.location.href = "order_complete_hidden_product.php";</script>';
		else echo '<script> alert("Product are not hide..! Please try again"); window.location.href = "order_complete_hidden_product.php";</script>';
	}
	catch (shopify\ApiException $e)
	{
		# HTTP status code was >= 400 or response contained the key 'errors'
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
	catch (shopify\CurlException $e)
	{
		# cURL error
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}

?>
