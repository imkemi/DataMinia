<?php 
            //error_reporting(0);
            include("database/db_conection.php"); 
            $product_price = $_POST['product_price'];
            $compare_id = $_POST['compare_id'];
			$product_id= $_POST['product_id'];
			$min_prices= $_POST['min_prices'];
			$product_sku= $_POST['min_sku'];
			$product_nme = $_POST['product_nme'];
			$colr_box = $_POST['colr_box'];			
			//echo $colr_box;			
			//$colr_box1 = $_POST['colr_box'];
			//echo $colr_box1;
			if($colr_box ==""){
				$colr_box1 ='off';
				//echo $colr_box1;
			}
			else if($colr_box == "off")
			{
				$colr_box1 ='on';
				//echo $colr_box1;
			}	
			
			else{
				$colr_box1 = $_POST['colr_box'];
				//echo $colr_box1;
				
			}
			//echo $product_nme;
			//echo '<p>'.$product_id. '</p>';
			//echo '<p>'.$product_price.'</p>';
			//echo '<p>'.$compare_id. '</p>';
			//echo implode(" ",$product_price)."<br>";
			//echo implode(" ",$compare_id)."<br>";
			//echo implode(" ",$product_id)."<br>";
			//echo $min_prices;
			//echo $product_sku;
			//print_r($product_price);
			//print_r($compare_id);
			//print_r($product_id);			
			//$display_order=array($product_price);				
			//$ids=1; $product_ids=0; 
          //  $rowCount = count($_POST["compare_id"]);
           // echo $rowCount;			
			// An array containing the category ids as keys and the new positions as values
//$display_order = array(
  //  1 => 10,
  //  2 => 20,
  //  3 => 30, Full texts	

  ///  4 => 40
//);

$ids = implode(',', array_keys($product_price));
$sql = "UPDATE faux_blinds SET minimum_price = $min_prices, sku =('".$product_sku."'), material_type = ('".$product_nme."'), color_box = ('".$colr_box1."'), price = CASE id ";
foreach ($product_price as $id => $ordinal) {
    $sql .= sprintf("WHEN %d THEN %d ", $id, $ordinal);
}
$sql .= "END WHERE id IN ($ids)";
//echo $sql;  

     $run=mysqli_query($dbcon,$sql);
   
    if($run)
    {
        //echo '<script> alert("Your Product are successfully Updated");</script>';
		$myval=0;

    }
    else
    {
        echo "<script> alert('Product Are Not Update'); </script>";
		
    }
	
   	 

	?>

<?php
    //error_reporting(0);
    include("database/db_conection.php");
    $color_names = $_POST['color_names'];
     
    $pro_ids=1;	 
    //echo implode(" ",$color_names)."<br>";
    echo $color_names;	
	$sql ="UPDATE colors_products SET colours_name =('".$color_names."') WHERE id= ('".$pro_ids."')";
                    // insert the image
					$runs=mysqli_query($dbcon,$sql);
                    if($runs){
                     //echo '<script> alert("Your Product are successfully Updated"); window.location.href = "product_update1.php";</script>';
					//echo $sql;
					$myval=1;
					}
					else 
					  {
				          echo '<script> alert("Product Color Are Not Update");</script>';
					  }    
 	
?>	
 
<?php
    //error_reporting(0);
    include("database/db_conection.php");
    $product_ids=$_POST['product_ids'];
   // echo $product_ids;
    if(is_array($_FILES)) {	
    if(is_uploaded_file($_FILES['userImage']['tmp_name'])) {
    $sourcePath = $_FILES['userImage']['tmp_name'];
    $targetPath = "product_imges/".$_FILES['userImage']['name'];
    $imagename=$_FILES['userImage']['name'];
    if(move_uploaded_file($sourcePath,$targetPath)) {
    ?>
    <!-- <img src="<?php echo $targetPath; ?>" width="100px" height="100px" /> -->
    <?php
    }
	$sql ="UPDATE product_imgs SET product_image =('".$targetPath."') , name =('".$imagename."') WHERE id= ('".$product_ids."')";
                    // insert the image
					$runs=mysqli_query($dbcon,$sql);
                    if($runs){
                    // echo '<script> alert("Your Product are successfully Updated"); window.location.href = "product_update_img_sku_pricefaux.php";</script>';
					//echo $sql;
					$myval=1;
					}
					  else 
					  {
				          echo '<script> alert("Product Image Are Not Update");</script>';
					  }
					  
    }
 }		
?>
<?php  
if($myval== 0 || $myval == 1){
	echo '<script> alert("Your Product Are Successfully Updated"); window.location.href = "product_update_img_sku_pricefaux.php";</script>';
   }
   else{
	    echo '<script> alert("Product Are Not Update! Please Try Again");</script>';
   }
?>

