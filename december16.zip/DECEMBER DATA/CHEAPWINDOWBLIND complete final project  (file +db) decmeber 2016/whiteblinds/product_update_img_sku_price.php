<?php
  session_start();

  if(!$_SESSION['email'])
  {

      header("Location: login.php");//redirect to login page to secure the welcome page without login access.
  }

  ?>
<html>
<head>
  <?php include'appheader.php'; ?>
  
<title>white Blinds</title>

</head>
<body>
  <div class="navbar">
    <div class="navbar-inner">
      <?php include 'topheader.php' ?>
<style>
    .login-panel {
        margin-top: 150px;
    }
    .table {
        margin-top: 50px;

    }

</style>
  <!-- start: Header -->

    <div class="container-fluid-full">
    <div class="row-fluid">

      <!-- start: Main Menu -->

      <!-- end: Main Menu -->

      <noscript>
        <div class="alert alert-block span10">
          <h4 class="alert-heading">Warning!</h4>
          <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
        </div>
      </noscript>
      <?php include 'left_menu.php'; ?>

      <!-- start: Content -->
      <div id="content" class="span10">


      <ul class="breadcrumb">
        <li>
          <i class="icon-home"></i>
          <a href="index.html">Home</a>
          <i class="icon-angle-right"></i>
        </li>
        <li><a href="#">Add Product</a></li>		
      </ul>

 <!--<h1 align="center">BASSWOOD 2" Blinds Price Change Table</h1>-->

 <div class="box span12" id="main_table_div">
					<div class="box-header">
						<h2><i class="halflings-icon align-justify"></i><span class="break"></span>BASSWOOD 2" Blinds Price Change Table</h2>
						<div class="box-icon">
							<!-- <a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a> -->
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<!-- <a href="#" class="btn-close"><i class="halflings-icon remove"></i></a> -->
						</div>
					</div>
					<div class="box-content">
						<table class="table table-striped" id="product_table_id">
							  <thead>								 
								  <tr>
								      <th></th>									
									  <th>24</th>
									  <th>27</th>
									  <th>30</th>
									  <th>33</th>
									  <th>36</th>
									  <th>39</th>
									  <th>42</th>
									  <th>45</th>
									  <th>48</th>
									  <th>51</th>
									  <th>54</th>
									  <th>57</th>
									  <th>60</th>
									  <th>63</th>
									  <th>66</th>
									  <th>69</th>									  
									  <th>72</th>
                                      <th></th>									  
									  
								  </tr>
							  </thead>   
							  <tbody>			    				
								
								<td><b>36</b></td>
																	                                   
								
						
        <?php
        include("database/db_conection.php");
        $view_users_query="select * from basswood_blinds";//select query for viewing users.
        $run=mysqli_query($dbcon,$view_users_query);//here run the sql query.
       	$cont=1;
	
        while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
        {
            $product_id=$row[0];
            $height_ft=$row[1];
            $width_ft=$row[2];
            $material_type=$row[3];
			$product_price=$row[4];
			$min_price=$row[5];
			$compare_price=$row[6];
			$sku=$row[7];	
            $color_code=$row[8];			
         		
        ?>
       
            <?php //var_dump($product_id); ?>
          <?php //echo $height_ft;  ?>
            <?php// echo $width_ft;  ?>
           <?php //echo $material_type;  ?>
		   
        <?php 
		     //if($cont == 18 || $cont == 35 || $cont == 52 || $cont == 69 || $cont == 86 || $cont == 103 || $cont == 120 || $cont == 137 || $cont == 154 || $cont == 171)
			//{   
         	//	echo '<br>';
				
			//}
			
		    if($cont >=1 && $cont<=17)
		    { 
	            // echo $cont; 
				
		        echo '<td>$'.$product_price.'</td>';
		    }
			if($cont == 18){				
				echo '<td><b>36</b></td>';
			}
            
			if($cont == 18){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>42</b></td>';
			}
		    if($cont >= 18 && $cont <=34)
		    { 
	             //echo $cont;
		         echo '<td>$'.$product_price.'</td>';
			}
			if($cont == 35){				
				echo '<td><b>42</b></td>';
			}
			if($cont == 35){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>48</b></td>';
			}
			if($cont > 34 && $cont <=51)
		    { 
	             // echo $cont;
		        echo '<td>$'.$product_price.'</td>';
			}
			if($cont == 52){				
				echo '<td><b>48</b></td>';
			}
			if($cont == 52){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>54</b></td>';
			}
			if($cont > 51 && $cont <=68)
		    { 
	             // echo $cont;
		         echo '<td>$'.$product_price.'</td>';
			}
			if($cont == 69){				
				echo '<td><b>54</b></td>';
			}
			if($cont == 69){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>60</b></td>';
			}
			if($cont > 68 && $cont <=85)
		    { 
	             // echo $cont;
		        echo '<td>$'.$product_price.'</td>';
			}
			if($cont == 86){				
				echo '<td><b>60</b></td>';
			}
			if($cont == 86){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>66</b></td>';
			}
			if($cont > 85 && $cont <=102)
		    { 
	             // echo $cont;
		        echo '<td>$'.$product_price.'</td>';
			}
			if($cont == 103){				
				echo '<td><b>66</b></td>';
			}
			if($cont == 103){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>72</b></td>';
			}
			if($cont > 102 && $cont <=119)
		    { 
	            //  echo $cont;
		        echo '<td>$'.$product_price.'</td>';
			}
			if($cont == 120){				
				echo '<td><b>72</b></td>';
			}
			if($cont == 120){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>78</b></td>';
			}
			if($cont > 119 && $cont <=136)
		    { 
	             // echo $cont;
		        echo '<td>$'.$product_price.'</td>';
			}
			if($cont == 137){				
				echo '<td><b>78</b></td>';
			}
			if($cont == 137){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>84</b></td>';
			}
			if($cont > 136 && $cont <=153)
		    { 
	             // echo $cont;
		        echo '<td>$'.$product_price.'</td>';
			}
			if($cont == 154){				
				echo '<td><b>84</b></td>';
			}
			if($cont == 154){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>90</b></td>';
			}
			if($cont > 153 && $cont <=170)
		    { 
	            //echo $cont;
		        echo '<td>$'.$product_price.'</td>';
			}
			if($cont == 171){				
				echo '<td><b>90</b></td>';
			}
			if($cont == 171){
				echo '</tr>';
				echo '<tr>';
				echo '<td><b>96</b></td>';
			}
			if($cont > 170 && $cont <=188)
		    { 
	            //echo $cont;
		        echo '<td>$'.$product_price.'</td>';
			}
			if($cont == 187){				
				echo '<td><b>96</b></td>';
			}
					
		   
	        ?>
	
	
		<!-- <td><input type="text" name="product_price" id="product_price" value="<?php //echo $product_price;  ?>" readonly />    </td> -->
             

        <?php 
		//echo $cont;
		$cont++;
		
		}  ?>	
       <tr><td></td><td><b>24</b></td><td><b>27</b></td><td><b>30</b></td><td><b>33</b></td><td><b>36</b></td><td><b>39</b></td>
	   <td><b>42</b></td><td><b>45</b></td><td><b>48</b></td><td><b>51</b></td><td><b>54</b></td><td><b>57</b></td><td><b>60</b></td>
	   <td><b>63</b></td><td><b>66</b></td><td><b>69</b></td><td><b>72</b></td><td></td></tr> 		
      		
								                          
	</tbody>
 </table>  

 <!-- <div id="table_footer_div"><span><a href="product_price_update.php?update_value=<?php// echo $compare_price ?>"><button class="btn btn-danger" onclick="btnconferm()">Product Update</button></a><span>-->
     <div id="table_footer_div"> 
	    <span id="min_price">Product Name = <?php echo $material_type ; ?></span>
        <span id="min_price">SKU = <?php echo $sku ; ?></span>	 
        <span id="min_price">Minimum Price = $<?php echo $min_price ; ?></span>
        
    
     <?php
        include("database/db_conection.php");
        $view_users_query="select * from product_imgs WHERE id = 0 ";//select query for viewing users.
        $run=mysqli_query($dbcon,$view_users_query);//here run the sql query.		
       	//header("Content-type: image/jpeg");
	
        while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
        {
           // $product_ids=$row[0];	
           // $product_name=$row[1];			
            $product_images=$row[2];
			//$com_id=$row[3];	
			
        ?>		
			
 		<?php echo '<span id="min_img">Basswood Blinds Image </span><span id="min_imgss"><img src="'.$product_images.'"/></span>' ?>        	
      	<?php //echo '<span id="min_img">Basswood Blinds Image </span><img src="data:image/jpeg;base64,'.base64_encode($product_images).'"width="50px" height="50px" />'; ?>
		<?php }?>	
		
<!-- 		
		<?php // if ($color_code == 'on'){?>
<span id="min_price">Product Color: On</span>
<dl class="dropdown" style="display:none;"> 
  
    <dt>
    <a href="#">
      <span class="hida">Product Colors</span>    
      <p class="multiSel"></p>  
    </a>
    </dt>
  
    <dd>
        <div class="mutliSelect">
            <ul>               
                    <!-- <input type="checkbox" value="green" /> Green
					<?php
                 //error_reporting(0);
              //   include("database/db_conection.php");				
				// $update_query="select * from color_table";
                // $run=mysqli_query($dbcon,$update_query);     
	            //    while($row=mysqli_fetch_array($run))
                 //  {
				//	    $colors=$row[2];
						//echo '<span id="color_span">' .$colors. '</span>';
						//echo '<li><input type="checkbox" name="my_add_color[]" value="'.$colors.'" /><span id="mycolorid">' .$colors . '</span></li>';
						//echo '<li><span id="mycolorid">' .$colors . '</span></li>';
				 //  }
                  ?>
				
            </ul>
        </div>
    </dd> 
</dl>
<?php //}
//else {?> <span id="min_price"> Product Color: Off </span>
<?php //}?> -->
	
	<!-- ADD NEW COLOR OPTION -->
<div id="table_footer_div_full"> 
<?php
         //error_reporting(0);
        include("database/db_conection.php");				
		$update_query="select * from colors_products where id=0";
        $run=mysqli_query($dbcon,$update_query);     
	    while($row=mysqli_fetch_array($run))
        {
		    $colors_nmes_array=$row[2];		
			
		}
     ?>
<span id="min_price">Product Color:<?php echo $colors_nmes_array ; ?></span>
</div><!-- table_footer_div_full -->
	
		</div> <!-- table_footer_div -->  
		</div> <!-- table_footer_div -->  
		
		
	
	
		<div id="table_footer_div1">
		 <span><a href="product_update_img_sku_price1.php?update_value=<?php echo $compare_price ?>"><button class="btn btn-danger" onclick="btnconferm()">Product Update</button></a><span>
		</div>
  </div><!-- Box Content --> 
 
</div>
</div><!--/.fluid-container-->

    <!-- end: Content -->
  </div><!--/#content.span10-->
  </div><!--/fluid-row-->
<div class="clearfix"></div>

<?php include 'footer.php'; ?>
<script>
function btnconferm() {
    alert("Are You Sure You Want To Updates Price");
}
</script>

</body>
</html>
<style>
#tab_height_row {
    background: #f9f9f9!important;
    border-top: 1px solid rgba(202, 194, 194, 0.1);
}
#tab_height_row h2{
    margin:0px;
}
#tabl_rows {
    background: #f9f9f9;
    border-right: 1px solid rgba(202, 194, 194, 0.1);
    border-left: 1px solid rgba(202, 194, 194, 0.1);
}
#tabl_rows h2{
    margin:0px;
}

#tab_height_row1 {
   // background: #3a3a3a;
    //color: #fff;
}
#tabl_rows_bottom {
    //background: #3a3a3a;
    //color: #fff;
}
#tabl_rows1 {
    //background: #3a3a3a;
    //color: #fff;
}
</style>

