<?php
  session_start();

  if(!$_SESSION['email'])
  {

      header("Location: login.php");//redirect to login page to secure the welcome page without login access.
  }

  ?>
<html>
<head>
  <?php include'appheader.php'; ?>

  
<title>white Blinds</title>

</head>
<body>
  <div class="navbar">
    <div class="navbar-inner">
      <?php include 'topheader.php' ?>
<style>
    .login-panel {
        margin-top: 150px;
    }
    .table {
        margin-top: 50px;

    }

</style>
  <!-- start: Header -->

    <div class="container-fluid-full">
    <div class="row-fluid">

      <!-- start: Main Menu -->

      <!-- end: Main Menu -->

      <noscript>
        <div class="alert alert-block span10">
          <h4 class="alert-heading">Warning!</h4>
          <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
        </div>
      </noscript>
      <?php include 'left_menu.php'; ?>

      <!-- start: Content -->
      <div id="content" class="span10">


      <ul class="breadcrumb">
        <li>
          <i class="icon-home"></i>
          <a href="index.html">Home</a>
          <i class="icon-angle-right"></i>
        </li>
        <li><a href="#">Add Product</a></li>
      </ul>
 <div class="box span12" id="main_table_div">
					<div class="box-header">
						<h2><i class="halflings-icon align-justify"></i><span class="break"></span>Hide Order Complete Products</h2>
						<div class="box-icon">
							<!-- <a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a> -->
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<!-- <a href="#" class="btn-close"><i class="halflings-icon remove"></i></a> -->
						</div>
					</div>
					<div class="box-content">
					
						<table class="table table-striped" id="product_table_id">
							  <thead>
								  <tr>
								      <th>Order Id</th>
										<th>Customer Name</th>
										<th>Customer Details</th> 
										<th>Payment Status</th> 
										<th>Total Price</th> 
										<!--<th>Id</th> -->				
										<th>Fulfillment Status</th>										  
									  
								  </tr>
							  </thead>   
							  <tbody>
							  <?php
	require __DIR__.'/vendor/autoload.php';
	use phpish\shopify;    
	require __DIR__.'/conf.php';

	$shopify = shopify\client(SHOPIFY_SHOP, SHOPIFY_APP_API_KEY, SHOPIFY_APP_PASSWORD, true);

	try
	{ ?>
	
	<!-- <table class="table table-bordered table-hover table-striped" style="table-layout: fixed" id="product_tabless"> -->
		
		 <?php
		 error_reporting(0);
		$products = $shopify('GET /admin/orders.json');		
		$productvalue=array($products);
		
//echo '<pre>';
//print_r($products);
      foreach($products as $value)
	 	{
			$fulfilled =$value['fulfillment_status'];
			//echo $fulfilled;
			if($fulfilled == 'fulfilled'){				
			
			$vaint9 = $value['line_items'];
			
			foreach($vaint9 as $variantt9){
						
				$fullfill_ids = $variantt9['product_id'];
				//echo $fullfill_ids;
				$getproducts = $shopify('GET /admin/products/'.$fullfill_ids.'.json');
				
				$getproducts1=array($getproducts);
				foreach($getproducts1 as $valu)
	 	        {
					$publishat =$valu['published_at'];					
					//$publishat1=array($publishat);
					//echo $publishat;
					//echo implode(" ",$publishat)."<br>";
		        }
				//echo '<pre>';
                //print_r($getproducts);
				
			}			
			if($publishat != ""){	?>
			<tr>
			<?php
			$order_id = $value['name'];
			echo '<td>'.$order_id.'</td>';            			
			$vaint = $value['line_items'];
            foreach($vaint as $variantt){		
				
				//$title = $variantt['title'];
				//echo '<td>'.$title.'</td>';
				//$quantity = $variantt['quantity'];
				//echo '<td>'.$quantity.'</td>';
                //$priceunit = $variantt['price'];
                //echo '<td>'.$priceunit.'</td>';				
				//$fullfill_id = $variantt['product_id'];
				//echo '<td>'.$fullfill_id.'</td>';
				
			}
					
			$vaint2 = $value['customer'];
			$prdchts=array($vaint2);
			
			foreach($prdchts as $variantt2){
				$prdchts1 = $variantt2['default_address'];
				$prdchts2=array($prdchts1);
				foreach($prdchts2 as $variantt3){
					$name1 = $variantt3['name'];
					$addr1 = $variantt3['address1'];
					$cty = $variantt3['city'];
					$country = $variantt3['country'];
					$zip = $variantt3['zip'];					
					echo '<td>'.$name1.'</td>';
				    echo '<td>'. $addr1 .' '. $cty .', '. $country .' ' .$zip .'</td>';
				}
			 }
			 
			 $financial_status = $value['financial_status'];
			echo '<td><span id="statments">'.$financial_status.'</span></td>';
			
			 $totl_prce = $value['total_price'];
			 echo '<td>$'.$totl_prce.'</td>';
			
			$vaint1 = $value['fulfillments'];
             foreach($vaint1 as $variantt1){
				//$status = $variantt1['status'];
				//echo '<td>'.$status.'</td>';
			 }	
			  $fulfillment_status = $value['fulfillment_status'];
			  echo '<td><span id="statments1">'.$fulfillment_status.'</span></td>';
			
			
			} //IFF CONDITION
			}?>
			</tr>
			<?php
			
			
	} 
		?>
		</tbody></table>
	
	<?php
	}
	catch (shopify\ApiException $e)
	{
		# HTTP status code was >= 400 or response contained the key 'errors'
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
	catch (shopify\CurlException $e)
	{
		# cURL error
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}

?>
	<div id="my_main_div">

				<div id="targetLayer"></div>             
                
                     <form id="uploadForm" method="post" action="order_complete_hidden_product1.php">                      
                            <div class="form-group">
                               <input class="form_control"  name="email" id="email" type="hidden" value="1"> 							  
                            </div>                           	
									<input type="submit" value="Hide Order Fulfilled Products" class="btn btn-danger" onclick="btnconferm()" />		
                    </form>  
				
</div><!-- my_main_div -->							  
</div><!-- box-content -->
</div><!-- main_table_div -->
  
    </div>
</div>
</div><!--/.fluid-container-->

    <!-- end: Content -->
  </div><!--/#content.span10-->
  </div><!--/fluid-row-->
<div class="clearfix"></div>
<style>    
#passs,#passss,#passsing{
    height:39px;
    width: 100%;
}
.show_single_error {
    margin-top: -8px;
    text-align: left;
    margin-bottom: 7px;
}
#errormsz{
	color:red;
}
div#targetLayer {
    margin: 10px 0px;
}
#my_main_div {
   // width: 30%;
    //box-shadow: 1px 1px 3px 1px rgb(158, 158, 158);
   // border-radius: 6px;
   // padding: 10px 25px;
    float: left;    
	margin-left: 10px;
   // text-align: center;
   // margin-bottom: 10px;
   // background: #f9f9f9;
}
div#my_main_div1 {
    float: left;
    width: 100%;
    background: #2D89EF !important;
    color: #fff;
}
div#my_main_div1 h4 {
    padding: 3px 10px;
    font-size: 18px;
}
table#product_tabless {
    margin: 0px;
}
#product_table_id td, th {
    font-size: 14px !important;
	padding: 15px !important;
}
span#statments {
    padding: 6px 8px;
    background: #2D89EF;
    color: #fff;
    text-transform: capitalize;
    box-shadow: 1px 2px 3px 1px rgb(191, 166, 166);
    border-radius: 3px;
}
span#statments1 {
    padding: 6px 8px;
    background: #00a754;
    color: #fff;
    text-transform: capitalize;
    box-shadow: 1px 2px 3px 1px rgb(191, 166, 166);
    border-radius: 3px;
}
</style>

<script type="text/javascript">
$(document).ready(function (e) {
	$("#uploadForm").on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "order_complete_hidden_product1.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
			success: function(data)
		    {
			$("#targetLayer").html(data);
             //alert("Your Product are successfully Updated"); window.location.href = "product_update_img_sku_price.php";		
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});
</script>
<script>
function btnconferm() {
    alert("Are You Sure You Want To Hide Order Complete Products");
}
</script>
<script type="text/javascript">

function ajaxindicatorstart(text)
{
	if(jQuery('body').find('#resultLoading').attr('id') != 'resultLoading'){
	jQuery('body').append('<div id="resultLoading" style="display:none"><div><img src="https://cdn.shopify.com/s/files/1/1318/4901/files/ajax-loader.gif?4589250752839393380"><div>'+text+'</div></div><div class="bg"></div></div>');
	}

	jQuery('#resultLoading').css({
		'width':'100%',
		'height':'100%',
		'position':'fixed',
		'z-index':'10000000',
		'top':'0',
		'left':'0',
		'right':'0',
		'bottom':'0',
		'margin':'auto'
	});

	jQuery('#resultLoading .bg').css({
		'background':'#fff',
		'opacity':'0.7',
		'width':'100%',
		'height':'100%',
		'position':'absolute',
		'top':'0'
	});

	jQuery('#resultLoading>div:first').css({
		'width': '100%',
		'height':'60%',
		'text-align': 'center',
		'position': 'fixed',
		'top':'10',
		'left':'0',
		'right':'0',
		'bottom':'0',
		'margin':'auto',
		'font-size':'16px',
		'z-index':'10',
		'color':'#000'

	});
 jQuery('#procingdata').css({
		'color': 'grey',
        'font-family':'sans-serif',
        'font-size':'14px'		

	});
    jQuery('#resultLoading .bg').height('100%');
       jQuery('#resultLoading').fadeIn(1600);
    jQuery('body').css('cursor', 'wait');
}


function ajaxindicatorstop()
{
    jQuery('#resultLoading .bg').height('100%');
       jQuery('#resultLoading').fadeOut(1600);
    jQuery('body').css('cursor', 'default');
}


jQuery(document).ajaxStart(function () {
 		//show ajax indicator
ajaxindicatorstart('<div id="procingdata">Processing... Please Wait..!</div>');
}).ajaxStop(function () {
//hide ajax indicator
ajaxindicatorstop();
});


jQuery.ajax({
   global: false,
   // ajax stuff
});

</script>
</body>

</html>
