<?php
  session_start();

  if(!$_SESSION['email'])
  {

      header("Location: login.php");//redirect to login page to secure the welcome page without login access.
  }

  ?>
<html>
<head>
  <?php include'appheader.php'; ?>
  
<title>white Blinds</title>

</head>
<body>
  <div class="navbar">
    <div class="navbar-inner">
      <?php include 'topheader.php' ?>

  <!-- start: Header -->

    <div class="container-fluid-full">
    <div class="row-fluid">

      <!-- start: Main Menu -->

      <!-- end: Main Menu -->

      <noscript>
        <div class="alert alert-block span10">
          <h4 class="alert-heading">Warning!</h4>
          <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
        </div>
      </noscript>
      <?php include 'left_menu.php'; ?>

      <!-- start: Content -->
      <div id="content" class="span10">


      <ul class="breadcrumb">
        <li>
          <i class="icon-home"></i>
          <a href="index.html">Home</a>
          <i class="icon-angle-right"></i>
        </li>
        <li><a href="#">Add Product</a></li>
      </ul>

           <!-- For displaying a message -->
      <div id="message"></div>
<div id="main-box-division">
      <div class="box-header" data-original-title="">
      <h2 id="price-previeww" class ="price_previeww"> Unit Price: $0.00</h2></div>
      <div class="box-header" data-original-title="">
      <h2 id="price-preview" class ="price_preview"> Total Price: $0.00</h2></div>


      <form id="add-item-form" action="/cart/add" method="post" enctype="multipart/form-data">
        <input type = "hidden" id = "unitt_price" name = "unitt_price" value ="">
        <input type = "hidden" id = "total_rates" name = "total_rates" value ="">        
        <input type = "hidden" id = "product_id" name = "id" value ="">
         <div class = "row select clearfix">

            <label> Product </label>

            <select class = "input_class" id="material_type" name="material_type">
              <option value = "BASSWOOD 2 Blinds">BASSWOOD 2" Blinds</option>
              <option value = "FAUX 2 Blinds">FAUX 2" Blinds</option>
            </select>

        </div>



        <div class="inch">
          <div class = "row clearfix input_width">

            <label> Height</label>
            <select class = "input_class" id="height_ft" name="height_ft">
              <option value = "" >Select Height</option>
              <option value = "36">36</option>
              <option value = "42">42</option>
              <option value = "48">48</option>
              <option value = "54">54</option>
              <option value = "60">60</option>
              <option value = "66">66</option>
              <option value = "72">72</option>
              <option value = "78">78</option>
              <option value = "84">84</option>
              <option value = "90">90</option>
              <option value = "96">96</option>
            </select>
            <p class ="show_single_error" id="height_ft_error"></p>

          </div>
        </div>


          <div class="inch">
      	  <div class = "row clearfix input_width">
                  <label> Width</label>
    <select class = "input_class" id="width_ft" name="width_ft">
              <option value = "" >Select Width</option>
              <option value = "24">24</option>
              <option value = "27">27</option>
              <option value = "30">30</option>
              <option value = "33">33</option>
              <option value = "36">36</option>
              <option value = "39">39</option>
              <option value = "42">42</option>
              <option value = "45">45</option>
              <option value = "48">48</option>
              <option value = "51">51</option>
              <option value = "54">54</option>
              <option value = "57">57</option>
              <option value = "60">60</option>
              <option value = "66">66</option>
              <option value = "69">69</option>
              <option value = "72">72</option>
            </select>
                  <p class ="show_single_error" id="width_ft_error"></p>
          </div>
        </div>

     <div class="inch">
    <div class = "row select clearfix">
                <label> Mounting Style: </label>

                  <select class = "input_class" id="mountingstyle" name="mountingstyle">
                    <option value = "Inside" >Inside</option>
                    <option value = "Outside" >Outside</option>
                  </select>
        </div></div>


     <div class = "row clearfix">
          	<label> Qty </label>
          	<input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1">
          	<p class ="show_single_error" id="quantity_error"></p>
        </div>


        <div class = "row clearfix margin_left pro_bar">
            <input type="button" id="call_api" class="add_to_cart_btn button btn_style" name="call_api" value = "Add to Cart" >
        </div>
      </form>
</div><!-- main-box-division -->

</div><!--/.fluid-container-->

    <!-- end: Content -->
  </div><!--/#content.span10-->
  </div><!--/fluid-row-->

<div class="modal hide fade" id="myModal">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">×</button>
    <h3>Settings</h3>
  </div>
  <div class="modal-body">
    <p>Here settings can be configured...</p>
  </div>
  <div class="modal-footer">
    <a href="#" class="btn" data-dismiss="modal">Close</a>
    <a href="#" class="btn btn-primary">Save changes</a>
  </div>
</div>

<div class="clearfix"></div>

<?php include 'footer.php'; ?>

<!-- The ajax/jquery stuff -->
<script type="text/javascript">
$(document).ready(function(){
//Get the input data using the post method when Push into mysql is clicked .. we pull it using the id fields of ID, Name and Email respectively...

  $('.input_class').change(function(){

        width_ft = $("#width_ft").val();
        width_inch = $("#width_inch").val();
        height_ft = $("#height_ft").val();
        height_inch = $("#height_inch").val();
        quantity = $("#quantity").val();
        material_type = $("#material_type").val();

          var rates;
// first matrix condition according to rates.
  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 24 && material_type =="BASSWOOD 2 Blinds"){
              rates=24;
	          var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
	           	$('#call_api').removeAttr('disabled');

          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 27 && material_type =="BASSWOOD 2 Blinds"){
             rates=32;

       		var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');

          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 30 && material_type =="BASSWOOD 2 Blinds"){
         rates=35;

       	     var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');

          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 33 && material_type =="BASSWOOD 2 Blinds"){
         rates=37;

          	var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');

          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 36 && material_type =="BASSWOOD 2 Blinds"){
         rates=40;

       		var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');

          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 39 && material_type =="BASSWOOD 2 Blinds"){
         rates=44;

       		var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');
          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 42 && material_type =="BASSWOOD 2 Blinds"){
         rates=48;

       		var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
	          $('#call_api').removeAttr('disabled');
          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 45 && material_type =="BASSWOOD 2 Blinds"){
         rates=52;

       		var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');
          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 48 && material_type =="BASSWOOD 2 Blinds"){
         rates=55;
               var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');
          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 51 && material_type =="BASSWOOD 2 Blinds"){
         rates=60;

       		var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');
          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 54 && material_type =="BASSWOOD 2 Blinds"){
         rates=63;

       		var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');
          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 57 && material_type =="BASSWOOD 2 Blinds"){
         rates=72;

       		var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');
          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 60 && material_type =="BASSWOOD 2 Blinds"){
         rates=76;

       		var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');
          }


// second matrix condition according to rates.

else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 24 && material_type =="FAUX 2 Blinds"){
         rates=20;

       		var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');
          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 27 && material_type =="FAUX 2 Blinds"){
         rates=23;

       		var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');
          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 30 && material_type =="FAUX 2 Blinds"){
         rates=28;
var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');

          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 33 && material_type =="FAUX 2 Blinds"){
         rates=29;

       		var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');
          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 36 && material_type =="FAUX 2 Blinds"){
         rates=20;

       		  var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');
          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 42 && material_type =="FAUX 2 Blinds"){
         rates=34;

       		  var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');
          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 45 && material_type =="FAUX 2 Blinds"){
         rates=37;

       		  var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');
          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 48 && material_type =="FAUX 2 Blinds"){
         rates=40;

       		  var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');
          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 51 && material_type =="FAUX 2 Blinds"){
         rates=43;

       		  var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');
          }
else  if(parseInt(height_ft) == 36 && parseInt(width_ft) == 54 && material_type =="FAUX 2 Blinds"){
         rates=45;

       		  var q_rates = rates * quantity;
              q_rates = parseFloat(q_rates);
              $("#price-preview").empty();
              $("#price-preview").append(' Total Price: $' + q_rates);
              $("#price-previeww").empty();
              $("#price-previeww").append('Unit Price: $' +  rates);
              $("#total_rates").val(q_rates);
              $("#unitt_price").val(rates);
		      $('#call_api').removeAttr('disabled');
          }
    
 });
  
  
$("#call_api").click(function(){
//Get values of the input fields and store it into the variables.
var material_type=$("#material_type").val();
var height_ft=$("#height_ft").val();
var width_ft=$("#width_ft").val();
var mountingstyle=$("#mountingstyle").val();
var quantity=$("#quantity").val();
var total_rates=$("#total_rates").val();
var unitt_price=$("#unitt_price").val();
  
  
  
   //validation on width in feet field

      if(width_ft == ""){

		 $("#width_ft").addClass( "field_error" );
         $("#width_ft_error").empty();
         $("#width_ft_error").append("<b>Width in feet field is required</b>");
		 $('#call_api').attr('disabled','disabled');

        }else{

           $("#width_ft").removeClass( "field_error" );

           $("#width_ft_error").empty();

           $('#call_api').removeAttr('disabled');


        }


      //validation on height in feet field



       if(height_ft == ""){

		 $("#height_ft").addClass( "field_error" );
         $("#height_ft_error").empty();
         $("#height_ft_error").append("<b>Height in feet field is required</b>");

		 $('#call_api').attr('disabled','disabled');

        }else{

           $("#height_ft").removeClass( "field_error" );

           $("#height_ft_error").empty();

           $('#call_api').removeAttr('disabled');


        }
  //quantity validation

        if(quantity <= 0){

            $("#quantity").addClass( "field_error" );

            $("#quantity_error").empty();
            $("#quantity_error").append("<b> Quantity must be greater than zero</b>");
            $('#call_api').attr('disabled','disabled');



         }else{

            $("#quantity").removeClass( "field_error" );

            $("#quantity_error").empty();

           $('#call_api').removeAttr('disabled');


         } 
  
  if(width_ft != "" && height_ft !="" && quantity > 0){



//use the $.post() method to call insert.php file.. this is the ajax request
$.post('http://localhost/whiteblinds/create_product.php', {material_type:material_type, height_ft:height_ft, width_ft:width_ft, mountingstyle:mountingstyle, quantity:quantity, total_rates:total_rates, unitt_price:unitt_price},
function(data){
	$("#message").html(data);
$("#message").hide();
$("#message").fadeIn(1500); //Fade in the data given by the insert.php file
//alert('Your Product are successfully Submitted');
 // var variant_id = $(data).find('.id_cls').html();
  
  //console.log('cxbd'+variant_id);
 // $.ajax({

  //                    	 type: 'POST',
  //                       url: '/cart/add.js',
 //                        cache: false,
  //                       contentType: 'multipart/form-data',
   //						 processData: false,                         
  //                       data: 'quantity=' + quantity + '&id=' + variant_id,
	//					 dataType: 'json',


      //                	 success: function(data)
    //       				 {
     //                     alert('Your Product are successfully Submitted');
                          
							// window.location.href = "http://cheap-white-blinds.myshopify.com/cart";
							

       //                  }
                   



        //              });

});
  }
return false;
});
});
</script>

<script type="text/javascript">

function ajaxindicatorstart(text)
{
	if(jQuery('body').find('#resultLoading').attr('id') != 'resultLoading'){
	jQuery('body').append('<div id="resultLoading" style="display:none"><div><img src="https://cdn.shopify.com/s/files/1/1318/4901/files/ajax-loader.gif?4589250752839393380"><div>'+text+'</div></div><div class="bg"></div></div>');
	}

	jQuery('#resultLoading').css({
		'width':'100%',
		'height':'100%',
		'position':'fixed',
		'z-index':'10000000',
		'top':'0',
		'left':'0',
		'right':'0',
		'bottom':'0',
		'margin':'auto'
	});

	jQuery('#resultLoading .bg').css({
		'background':'#fff',
		'opacity':'0.7',
		'width':'100%',
		'height':'100%',
		'position':'absolute',
		'top':'0'
	});

	jQuery('#resultLoading>div:first').css({
		'width': '100%',
		'height':'60%',
		'text-align': 'center',
		'position': 'fixed',
		'top':'10',
		'left':'0',
		'right':'0',
		'bottom':'0',
		'margin':'auto',
		'font-size':'16px',
		'z-index':'10',
		'color':'#000'

	});

    jQuery('#resultLoading .bg').height('100%');
       jQuery('#resultLoading').fadeIn(1600);
    jQuery('body').css('cursor', 'wait');
}


function ajaxindicatorstop()
{
    jQuery('#resultLoading .bg').height('100%');
       jQuery('#resultLoading').fadeOut(1600);
    jQuery('body').css('cursor', 'default');
}


jQuery(document).ajaxStart(function () {
 		//show ajax indicator
ajaxindicatorstart('loading data.. please wait..');
}).ajaxStop(function () {
//hide ajax indicator
ajaxindicatorstop();
});


jQuery.ajax({
   global: false,
   // ajax stuff
});

</script>
</body>
</html>