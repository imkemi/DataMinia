
<?php
  session_start();

  if(!$_SESSION['email'])
  {

      header("Location: login.php");//redirect to login page to secure the welcome page without login access.
  }

  ?>
<html>
<head>
  <?php include'appheader.php'; ?>
  
<title>white Blinds</title>

</head>
<body>
  <div class="navbar">
    <div class="navbar-inner">
      <?php include 'topheader.php' ?>

  <!-- start: Header -->

    <div class="container-fluid-full">
    <div class="row-fluid">

      <!-- start: Main Menu -->

      <!-- end: Main Menu -->

      <noscript>
        <div class="alert alert-block span10">
          <h4 class="alert-heading">Warning!</h4>
          <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
        </div>
      </noscript>
      <?php include 'left_menu.php'; ?>

      <!-- start: Content -->
      <div id="content" class="span10">


      <ul class="breadcrumb">
        <li>
          <i class="icon-home"></i>
          <a href="index.html">Home</a>
          <i class="icon-angle-right"></i>
        </li>
        <li><a href="#">Add Product</a></li>
      </ul>         


<div id="main-box-division">
      <div class="box-header" data-original-title="">
      <!-- <h2 id="price-previeww" class ="price_previeww"> Unit Price: $0.00</h2></div> 
      <div class="box-header" data-original-title="">
      <h2 id="price-preview" class ="price_preview"> Total Price: $0.00</h2></div> -->
	<!-- <h2 id="price-previewww" style="text-align:center;">height: </h2>
	    <h2 id="price-previewwww" style="text-align:center;">width: </h2> -->
        <h4>Cheap White Blinds</h4>
        </div>
  <div id="main-box-division_inner">
      <form id="add-item-form" action="/cart/add" method="post" enctype="multipart/form-data">       
        <input type = "hidden" id = "total_rates" name = "total_rates" value ="">   
	    <input type = "hidden" id = "unitt_price" name = "unitt_price" value ="">
		<input type = "hidden" id = "product_id" name = "id" value ="">		
		<input type = "hidden" id = "mat_type1" name = "id" value ="">
        <input type = "hidden" id = "rates1" name = "id" value =""><br>				
	    <input type = "hidden" id = "mat_type2" name = "id" value ="">
		<input type = "hidden" id = "rates2" name = "id" value ="">				
	    
	    
		
        <!--  <div class = "row select clearfix">

            <label> Product </label>

            <select class = "input_class" id="material_type" name="material_type">
              <option value = "BASSWOOD 2 Blinds">BASSWOOD 2" Blinds</option>
              <option value = "FAUX 2 Blinds">FAUX 2" Blinds</option>
            </select>

        </div> -->



        <div class="inch">
          <div class = "row  input_width">

            <label> Height In Feet</label>
            <select class = "input_class" id="height_ft" name="height_ft">
              <option value = "" >Select Height In Feet</option>
              <option value = "3">3</option>
              <option value = "4">4</option>
              <option value = "5">5</option>
              <option value = "6">6</option>
              <option value = "7">7</option>
              <option value = "8">8</option>                           
            </select>
            <p class ="show_single_error" id="height_ft_error"></p>

          </div>
		  <div class = "row  input_width">
            <label> Height In Inches</label>
            <select class = "input_class" id="height_inch" name="height_inch">
              <option value = "" >Select Height In Inches</option>
              <option value = "0">0</option>
              <option value = "1">1</option>
              <option value = "2">2</option>
              <option value = "3">3</option>
              <option value = "4">4</option>
              <option value = "5">5</option>
              <option value = "6">6</option>
              <option value = "7">7</option>
              <option value = "8">8</option>
              <option value = "9">9</option>
              <option value = "10">10</option>
			  <option value = "11">11</option>
			  <option value = "12">12</option>
            </select>
            <p class ="show_single_error" id="height_inch_error"></p>

          </div>
        </div>


          <div class="inch">
      	  <div class = "row  input_width">
           <label> Width In Feet</label>
           <select class = "input_class" id="width_ft" name="width_ft">
              <option value = "" >Select Width In Feet</option>
			  <option value = "2">2</option>
              <option value = "3">3</option>
              <option value = "4">4</option>
              <option value = "5">5</option>
              <option value = "6">6</option>              
            </select>
                  <p class ="show_single_error" id="width_ft_error"></p>
          </div>
            
		   <div class = "row  input_width">
            <label> Width In inches</label>
              <select class = "input_class" id="width_inch" name="width_inch">
              <option value = "" >Select Width In Inches</option>
              <option value = "0">0</option>
              <option value = "1">1</option>
              <option value = "2">2</option>
              <option value = "3">3</option>
              <option value = "4">4</option>
              <option value = "5">5</option>
              <option value = "6">6</option>
              <option value = "7">7</option>
              <option value = "8">8</option>
              <option value = "9">9</option>
              <option value = "10">10</option>
			  <option value = "11">11</option>
			  <option value = "12">12</option>
            </select>
            <p class ="show_single_error" id="width_inch_error"></p>

          </div>
        </div>

     <div class="inch">
    <div class = "row select ">
                <label> Mounting Style: </label>

                  <select class = "input_class" id="mountingstyle" name="mountingstyle">
                    <option value = "Inside" >Inside</option>
                    <option value = "Outside" >Outside</option>
                  </select>
        </div></div>


     <!-- <div class = "row clearfix">
          	<label> Qty </label>
          	<input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1">
          	<p class ="show_single_error" id="quantity_error"></p>
        </div> -->
        <div class = "row  margin_left pro_bar">
            <input type="button" id="call_api" class="add_to_cart_btn button btn_style" name="call_api" value = "Find Rates">
        </div>
      </form>  
</div><!-- main-box-division-inner -->
</div><!-- main-box-division --> 
  <!-- For displaying a message -->
<br> 

<div id="display_product_div"  style="display:none;" class="answer_list" >      
<table class="table table-bordered table-hover table-striped" style="table-layout: fixed" id="product_tables">
		 <thead>
			 <tr>
			    <th>Featured Image</th>
				<th>Material Type</th>
				<th>Height(Inch)</th>
				<th>Width(Inch)</th>
				<th>Unit Per Price</th>
                <th>Total Price</th>
				<th>Quantity</th>
				<th>Mounting Style</th>
				<th>Add To Cart</th>				
				
			 </tr>
		 </thead>
		 <tbody>
           <tr>	
		     <input type="hidden" class = "input_class1" id="material_type1" name="material_type1" value="">
		     <input type="hidden" class = "input_class1" id="product_price1" name="product_price1" value="">
             <input type="hidden" class = "input_class1" id="total_price1" name="total_price1" value="">
			 <td><h5 id="product_images1"></h5></td>			
             <td><h5 id="material_type_2"></h5></td>	
			 <input type = "hidden" id ="height_ft1" name = "height_ft1" value ="">
			 <td><h5 id="height_ft_2"> </h5></td>	
			 <input type = "hidden" id ="width_ft1" name = "width_ft1" value ="">
			 <td><h5 id="width_ft_2"> </h5></td>	
             <td><h5 id="product_price_2"> </h5></td>
             <td><h5 id="total_price_2"> </h5></td>             
			 <td><input id= "quantity1" type ="number" class ="input_class field_input" name ="quantity1" step="1" value = "1"></td> 
			 <td><h5 id="mountingstyles_2"> </h5></td>	
			 <input type="hidden" id ="mountingstyles1" name ="mountingstyles1" value ="">
			 <td><input type="button" id="call_apiii" class="add_to_cart_btn button btn_style" name="call_apiii" value = "Add To Cart"></td>			        	
			 </tr>
              <tr>	
		     <input type="hidden" class = "input_class1" id="material_type2" name="material_type2" value="">
		     <input type="hidden" class = "input_class1" id="product_price2" name="product_price2" value="">
             <input type="hidden" class = "input_class1" id="total_price2" name="total_price2" value="">
			 <td><h5 id="product_images2"></h5></td>	
             <td><h5 id="material_type3"></h5></td>	    
			 <input type = "hidden" id ="height_ft2" name = "height_ft2" value ="">
			 <td><h5 id="height_ft3"> </h5></td>	
			 <input type = "hidden" id ="width_ft2" name = "width_ft2" value ="">
			 <td><h5 id="width_ft3"> </h5></td>	
             <td><h5 id="product_price3"> </h5></td> 
             <td><h5 id="total_price_3"> </h5></td> 
			 <td><input id= "quantity2" type ="number" class ="input_class field_input" name ="quantity2" step="1" value = "1"></td> 
			 <td><h5 id="mountingstyles3"> </h5></td>	
			 <input type="hidden" id ="mountingstyles2" name ="mountingstyles2" value ="">
			 <td><input type="button" id="insertt" class="add_to_cart_btn button btn_style" name="insertt" value = "Add To Cart"></td>		        	
			 </tr>
        </tbody>
  </table>
</div><!-- display_product_div -->
<br><div id="message"></div> 

 <!--  <input type="button" name="answer" value="Show Div" onclick="showDiv()" /> -->

</div><!--/.fluid-container-->

    <!-- end: Content -->
  </div><!--/#content.span10-->
  </div><!--/fluid-row-->
<div class="clearfix"></div>
<?php include 'footer.php'; ?>
<!-- The ajax/jquery stuff -->
</body>
</html>  

<script type="text/javascript">
$(document).ready(function(){
//Get the input data using the post method when Push into mysql is clicked .. we pull it using the id fields of ID, Name and Email respectively...
  $('.input_class').change(function(){

        var material_type=$("#material_type").val();
        var height_ft=$("#height_ft").val();
        var height_inch=$("#height_inch").val();
        var width_ft=$("#width_ft").val();
        var width_inch=$("#width_inch").val();
        var mountingstyle=$("#mountingstyle").val();
        var quantity=$("#quantity").val();
        var total_rates=$("#total_rates").val();
        var unitt_price=$("#unitt_price").val();
        
		var rates_chenge_height = parseInt(height_ft) * 12;
        var total_height = rates_chenge_height + parseInt(height_inch);
		var rates_chenge_width = parseInt(width_ft) * 12;			  
        var total_width = rates_chenge_width + parseInt(width_inch);
			  
              //q_rates = parseFloat(q_rates);
			  //$("#price-preview").empty();
              //$("#price-preview").append(' Total Price: $' + q_rates);
              //$("#price-previeww").empty();
              //$("#price-previeww").append('Unit Price: $' +  rates);
             // $("#total_rates").val(q_rates);
             // $("#unitt_price").val(rates);
		      //$('#call_api').removeAttr('disabled');
              
		$("#price-previewww").empty();
        $("#price-previewww").append('height: $' +  total_height); 
        $("#price-previewwww").empty();			  
		$("#price-previewwww").append('width: $' +  total_width);   
        $("#total_rates").val(total_height);
        $("#unitt_price").val(total_width);	
    
     //total price validation for product first
     var totall_price=$("#product_price1").val();
     var quantity1=$("#quantity1").val();
     var totall_price1=  totall_price*quantity1;
     $("#total_price_2").empty();
     $("#total_price_2").append(totall_price1); 
     $("#total_price1").val(totall_price1);
    
     //total price validation for product second
     var totall_price1=$("#product_price2").val();
     var quantity2=$("#quantity2").val();
     var totall_price2=  totall_price1*quantity2;
     $("#total_price_3").empty();
     $("#total_price_3").append(totall_price2); 
     $("#total_price2").val(totall_price2);
     $('#call_api').removeAttr('disabled');  
    
//validation on Height in inches value is greter then table field
   
    if(parseInt(height_ft) == 8 && parseInt(height_inch) == 1){
		 $("#height_inch").addClass( "field_error" );
         $("#height_inch_error").empty();
         $("#height_inch_error").append("<b>Maximum Height Selection Is 8 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
    else if(parseInt(height_ft) == 8 && parseInt(height_inch) == 2){
		 $("#height_inch").addClass( "field_error" );
         $("#height_inch_error").empty();
         $("#height_inch_error").append("<b>Maximum Height Selection Is 8 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
     else if(parseInt(height_ft) == 8 && parseInt(height_inch) == 3){
		 $("#height_inch").addClass( "field_error" );
         $("#height_inch_error").empty();
         $("#height_inch_error").append("<b>Maximum Height Selection Is 8 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
     else if(parseInt(height_ft) == 8 && parseInt(height_inch) == 4){
		$("#height_inch").addClass( "field_error" );
         $("#height_inch_error").empty();
         $("#height_inch_error").append("<b>Maximum Height Selection Is 8 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
     else if(parseInt(height_ft) == 8 && parseInt(height_inch) == 5){
		 $("#height_inch").addClass( "field_error" );
         $("#height_inch_error").empty();
         $("#height_inch_error").append("<b>Maximum Height Selection Is 8 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
    else if(parseInt(height_ft) == 8 && parseInt(height_inch) == 6){
	    $("#height_inch").addClass( "field_error" );
         $("#height_inch_error").empty();
         $("#height_inch_error").append("<b>Maximum Height Selection Is 8 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
     else if(parseInt(height_ft) == 8 && parseInt(height_inch) == 7){
		 $("#height_inch").addClass( "field_error" );
         $("#height_inch_error").empty();
         $("#height_inch_error").append("<b>Maximum Height Selection Is 8 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
    else if(parseInt(height_ft) == 8 && parseInt(height_inch) == 8){
		 $("#height_inch").addClass( "field_error" );
         $("#height_inch_error").empty();
         $("#height_inch_error").append("<b>Maximum Height Selection Is 8 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
     else if(parseInt(height_ft) == 8 && parseInt(height_inch) == 9){
		 $("#height_inch").addClass( "field_error" );
         $("#height_inch_error").empty();
         $("#height_inch_error").append("<b>Maximum Height Selection Is 8 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
     else if(parseInt(height_ft) == 8 && parseInt(height_inch) == 10){
		 $("#height_inch").addClass( "field_error" );
         $("#height_inch_error").empty();
         $("#height_inch_error").append("<b>Maximum Height Selection Is 8 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
     else if(parseInt(height_ft) == 8 && parseInt(height_inch) == 11){
		 $("#height_inch").addClass( "field_error" );
         $("#height_inch_error").empty();
         $("#height_inch_error").append("<b>Maximum Height Selection Is 8 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
     else if(parseInt(height_ft) == 8 && parseInt(height_inch) == 12){
		 $("#height_inch").addClass( "field_error" );
         $("#height_inch_error").empty();
         $("#height_inch_error").append("<b>Maximum Height Selection Is 8 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
    else{

           $("#height_inch").removeClass( "field_error" );

           $("#height_inch_error").empty();

           $('#call_api').removeAttr('disabled');


        }
	
//validation on width in inches value is greter then table field
   
    if(parseInt(width_ft) == 6 && parseInt(width_inch) == 1){
		 $("#width_inch").addClass( "field_error" );
         $("#width_inch_error").empty();
         $("#width_inch_error").append("<b>Maximum Width Selection Is 6 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
    else if(parseInt(width_ft) == 6 && parseInt(width_inch) == 2){
		 $("#width_inch").addClass( "field_error" );
         $("#width_inch_error").empty();
         $("#width_inch_error").append("<b>Maximum Width Selection Is 6 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
     else if(parseInt(width_ft) == 6 && parseInt(width_inch) == 3){
		 $("#width_inch").addClass( "field_error" );
         $("#width_inch_error").empty();
         $("#width_inch_error").append("<b>Maximum Width Selection Is 6 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
     else if(parseInt(width_ft) == 6 && parseInt(width_inch) == 4){
		 $("#width_inch").addClass( "field_error" );
         $("#width_inch_error").empty();
         $("#width_inch_error").append("<b>Maximum Width Selection Is 6 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
     else if(parseInt(width_ft) == 6 && parseInt(width_inch) == 5){
		 $("#width_inch").addClass( "field_error" );
         $("#width_inch_error").empty();
         $("#width_inch_error").append("<b>Maximum Width Selection Is 6 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
     else if(parseInt(width_ft) == 6 && parseInt(width_inch) == 6){
		 $("#width_inch").addClass( "field_error" );
         $("#width_inch_error").empty();
         $("#width_inch_error").append("<b>Maximum Width Selection Is 6 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
     else if(parseInt(width_ft) == 6 && parseInt(width_inch) == 7){
		 $("#width_inch").addClass( "field_error" );
         $("#width_inch_error").empty();
         $("#width_inch_error").append("<b>Maximum Width Selection Is 6 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
     else if(parseInt(width_ft) == 6 && parseInt(width_inch) == 8){
		 $("#width_inch").addClass( "field_error" );
         $("#width_inch_error").empty();
         $("#width_inch_error").append("<b>Maximum Width Selection Is 6 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
     else if(parseInt(width_ft) == 6 && parseInt(width_inch) == 9){
		 $("#width_inch").addClass( "field_error" );
         $("#width_inch_error").empty();
         $("#width_inch_error").append("<b>Maximum Width Selection Is 6 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
     else if(parseInt(width_ft) == 6 && parseInt(width_inch) == 10){
		 $("#width_inch").addClass( "field_error" );
         $("#width_inch_error").empty();
         $("#width_inch_error").append("<b>Maximum Width Selection Is 6 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
     else if(parseInt(width_ft) == 6 && parseInt(width_inch) == 11){
		 $("#width_inch").addClass( "field_error" );
         $("#width_inch_error").empty();
         $("#width_inch_error").append("<b>Maximum Width Selection Is 6 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}
     else if(parseInt(width_ft) == 6 && parseInt(width_inch) == 12){
		 $("#width_inch").addClass( "field_error" );
         $("#width_inch_error").empty();
         $("#width_inch_error").append("<b>Maximum Width Selection Is 6 Feet</b>");
		 $('#call_api').attr('disabled','disabled');		
	}    
    else{

           $("#width_inch").removeClass( "field_error" );

           $("#width_inch_error").empty();

           $('#call_api').removeAttr('disabled');


        }
    
    //quantity validation

     if(quantity1 <= 0){

           alert("Minimum Product Quantity Is One");


         }	
     if(quantity2 <= 0){

           alert("Minimum Product Quantity Is One");


         }			
		
 });
$("#call_api").click(function(){
//Get values of the input fields and store it into the variables.
var material_type=$("#material_type").val();
var height_ft=$("#height_ft").val();
var height_inch=$("#height_inch").val();
var width_ft=$("#width_ft").val();
var width_inch=$("#width_inch").val();
var mountingstyle=$("#mountingstyle").val();
var quantity=$("#quantity").val();
var total_height=$("#total_rates").val();
var total_width=$("#unitt_price").val();  
   
  
  //validation on height in feet field
       if(height_ft == ""){

		 $("#height_ft").addClass( "field_error" );
         $("#height_ft_error").empty();
         $("#height_ft_error").append("<b>Height in feet field is required</b>");

		 $('#call_api').attr('disabled','disabled');

        }else{

           $("#height_ft").removeClass( "field_error" );

           $("#height_ft_error").empty();

           $('#call_api').removeAttr('disabled');


        }
		 //validation on height in Inch field
		 
		 if(height_inch == ""){

		 $("#height_inch").addClass( "field_error" );
         $("#height_inch_error").empty();
         $("#height_inch_error").append("<b>Height in Inch field is required</b>");

		 $('#call_api').attr('disabled','disabled');

        }else{

           $("#height_inch").removeClass( "field_error" );

           $("#height_inch_error").empty();

           $('#call_api').removeAttr('disabled');


        }
    
  //validation on width in feet field

      if(width_ft == ""){

		 $("#width_ft").addClass( "field_error" );
         $("#width_ft_error").empty();
         $("#width_ft_error").append("<b>Width in feet field is required</b>");
		 $('#call_api').attr('disabled','disabled');

        }else{

           $("#width_ft").removeClass( "field_error" );

           $("#width_ft_error").empty();

           $('#call_api').removeAttr('disabled');


        }

   //validation on width in Inches field   
   if(width_inch == ""){

		 $("#width_inch").addClass( "field_error" );
         $("#width_inch_error").empty();
         $("#width_inch_error").append("<b>Width in Inch field is required</b>");
		 $('#call_api').attr('disabled','disabled');

        }else{

           $("#width_inch").removeClass( "field_error" );

           $("#width_inch_error").empty();

           $('#call_api').removeAttr('disabled');


        }

   
		

      
  //quantity validation

       // if(quantity <= 0){

          //  $("#quantity").addClass( "field_error" );

         //   $("#quantity_error").empty();
         //   $("#quantity_error").append("<b> Quantity must be greater than zero</b>");
         ///   $('#call_api').attr('disabled','disabled');



       //  }else{

       //     $("#quantity").removeClass( "field_error" );

        //    $("#quantity_error").empty();

        //   $('#call_api').removeAttr('disabled');


        // } 
  
  
  if(width_ft != "" && height_ft !="" && width_inch != "" && height_inch !=""){
    
    function explode(){
                document.getElementById('display_product_div').style.display = "block";
                      }
        setTimeout(explode, 3000);  
    
   //use the $.post() method to call insert.php file.. this is the ajax request
$.post('create_product_by_app1_price_get.php', {total_height:total_height, total_width:total_width, mountingstyle:mountingstyle},
function(data){
$("#message").html(data);
$("#message").hide();
$("#message").fadeIn(1500); //Fade in the data given by the insert.php file
//alert('Your Product are successfully Submitted');
    var $response=$(data);
	

    //Query the jQuery object for the values
    var materl_type = $response.filter('#product_type').text();
    var materl_type1 = $response.filter('#product_type1').text();
	var rates1 = $response.filter('#new_product_price').text();
	var rates2 = $response.filter('#new_product_price1').text();	     
	$("#mat_type1").val(materl_type);
	$("#rates1").val(rates1);
    $("#mat_type2").val(materl_type1);
	$("#rates2").val(rates2);
	// Get Product details from first product table in backend	     
  var material_type1 = $response.filter('#material_type2').text();
  var product_price1 = $response.filter('#product_price2').text();
  var height_ft1 = $response.filter('#height_ft2').text();
  var width_ft1 = $response.filter('#width_ft2').text();
  var mountingstyles1 = $response.filter('#mountingstyles2').text();
  $("#material_type1").val(material_type1);
  $("#product_price1").val( product_price1);
  $("#height_ft1").val(height_ft1);
  $("#width_ft1").val(width_ft1);
  $("#mountingstyles1").val(mountingstyles1); 
  $("#total_price1").val(product_price1);   
  $("#material_type_2").empty();
  $("#material_type_2").append(material_type1);
  $("#product_price_2").empty();  
  $("#product_price_2").append(product_price1);
  $("#height_ft_2").empty();  
  $("#height_ft_2").append(height_ft1);
  $("#width_ft_2").empty();  
  $("#width_ft_2").append(width_ft1);
  $("#mountingstyles_2").empty(); 
  $("#mountingstyles_2").append(mountingstyles1);
  $("#total_price_2").empty();
  $("#total_price_2").append(product_price1); 
        
  $('#call_api').removeAttr('disabled');
  // Get Product details from second product table in backend	
  var material_type2 = $response.filter('#material_type3').text();
  var product_price2 = $response.filter('#product_price3').text();
  var height_ft2 = $response.filter('#height_ft3').text();
  var width_ft2 = $response.filter('#width_ft3').text();
  var mountingstyles2 = $response.filter('#mountingstyles3').text();
  $("#material_type2").val(material_type2);
  $("#product_price2").val( product_price2);
  $("#height_ft2").val(height_ft2);
  $("#width_ft2").val(width_ft2);
  $("#mountingstyles2").val(mountingstyles2);  
  $("#total_price2").val(product_price2);
  
  $("#material_type3").empty();
  $("#material_type3").append(material_type2);
  $("#product_price3").empty();  
  $("#product_price3").append(product_price2);
  $("#height_ft3").empty();  
  $("#height_ft3").append(height_ft2);
  $("#width_ft3").empty();  
  $("#width_ft3").append(width_ft2);
  $("#mountingstyles3").empty(); 
  $("#mountingstyles3").append(mountingstyles2); 
  $("#total_price_3").empty();
  $("#total_price_3").append(product_price2); 
  $('#call_api').removeAttr('disabled');
  
  // Get Product Image from The backend	
  var product_images1 = $response.filter('#product_img').text();  
  var product_images2 = $response.filter('#product_img1').text();
  //alert(product_images1);
  var product_image1 ='<img src="' + product_images1 + '">';    
  var product_image2 ='<img src="' + product_images2 + '">'; 
   $("#product_images1").empty();  
   $("#product_images1").append(product_image1);
   $("#product_images2").empty();  
   $("#product_images2").append(product_image2);
   $('#call_api').removeAttr('disabled');
 // console.log('cxbd'+rates);
 // $.ajax({

  //                    	 type: 'POST',
  //                       url: '/cart/add.js',
 //                        cache: false,
  //                       contentType: 'multipart/form-data',
   //						 processData: false,                         
  //                       data: 'quantity=' + quantity + '&id=' + variant_id,
	//					 dataType: 'json',


      //                	 success: function(data)
    //       				 {
     //                     alert('Your Product are successfully Submitted');
                          
							// window.location.href = "http://cheap-white-blinds.myshopify.com/cart";
							

       //                  }
                   



        //              });

});
  }
return false;
});
});

</script>

<script type="text/javascript">
$(document).ready(function(){
  $("#call_apiii").click(function(){
     
       var material_type = $("#material_type1").val();
       var product_price = $("#product_price1").val();
       var total_pro_price = $("#total_price1").val();       
	   var height_ft1= $("#height_ft1").val();
	   var width_ft1= $("#width_ft1").val();
       var quantity = $("#quantity1").val();
	   var mountingstyles = $("#mountingstyles1").val();
          
    if(material_type !="" && product_price !="" && total_pro_price !="" && height_ft1 !="" && width_ft1 !="" && mountingstyles !="" && quantity>0){
    $.post('create_product_by_app3_price_get.php', {material_type:material_type, product_price:product_price, total_pro_price:total_pro_price, quantity:quantity, height_ft1:height_ft1, width_ft1:width_ft1, mountingstyles:mountingstyles},
    function(data){
        alert('Your Product One are successfully Submitted');   
        // alert(data);
    //var variant_id = $(data).find('.id_cls').html();  
    //console.log('id is'+variant_id);
    //$.ajax({

    //       type: 'POST',
    //       url: '/cart/add.js',
    //       cache: false,
     //      contentType: 'multipart/form-data',
    //       processData: false,                         
     //      data: 'quantity=' + quantity + '&id=' + variant_id,
     //      dataType: 'json',
      //     success: function(data)
      //      {
       //           alert('Your Product are successfully Submitted');                     
		//		  window.location.href = "http://cheap-white-blinds.myshopify.com/cart";
							

          //    }
                   
             //});

          });
    }
    else alert('Wrong Input..! Please Input The Correct Values');  
      });
  });
</script>
<script type="text/javascript">
$(document).ready(function(){
	$("#insertt").click(function(){

       var material_type = $("#material_type2").val();
       var product_price = $("#product_price2").val();
       var total_pro_price = $("#total_price2").val();       
	   var height_ft1= $("#height_ft2").val();
	   var width_ft1= $("#width_ft2").val();
       var quantity = $("#quantity2").val();
	   var mountingstyles = $("#mountingstyles2").val();
	 if(material_type !="" && product_price !="" && total_pro_price !="" && height_ft1 !="" && width_ft1 !="" && mountingstyles !="" && quantity>0){		
    $.post('create_product_by_app3_price_get1.php', {material_type:material_type, product_price:product_price, total_pro_price:total_pro_price, quantity:quantity, height_ft1:height_ft1, width_ft1:width_ft1, mountingstyles:mountingstyles},
    function(data){
        alert('Your Product Two are successfully Submitted');   
        // alert(data);
   // var variant_id = $(data).find('.id_cls').html();  
    //console.log('id is'+variant_id);
  //  $.ajax({

        //   type: 'POST',
        //   url: '/cart/add.js',
        //   cache: false,
         //  contentType: 'multipart/form-data',
        //   processData: false,                         
        //   data: 'quantity=' + quantity + '&id=' + variant_id,
         //  dataType: 'json',
        //   success: function(data)
         //   {
          //        alert('Your Product are successfully Submitted');                     
		//		  window.location.href = "http://cheap-white-blinds.myshopify.com/cart";
							

           //   }
                   
            // });

          });  
        }
           else alert('Wrong Input..! Please Input The Correct Values'); 
      });
  });
</script>

<script type="text/javascript">

function ajaxindicatorstart(text)
{
	if(jQuery('body').find('#resultLoading').attr('id') != 'resultLoading'){
	jQuery('body').append('<div id="resultLoading" style="display:none"><div><img src="https://cdn.shopify.com/s/files/1/1318/4901/files/ajax-loader.gif?4589250752839393380"><div>'+text+'</div></div><div class="bg"></div></div>');
	}

	jQuery('#resultLoading').css({
		'width':'100%',
		'height':'100%',
		'position':'fixed',
		'z-index':'10000000',
		'top':'0',
		'left':'0',
		'right':'0',
		'bottom':'0',
		'margin':'auto'
	});

	jQuery('#resultLoading .bg').css({
		'background':'#fff',
		'opacity':'0.7',
		'width':'100%',
		'height':'100%',
		'position':'absolute',
		'top':'0'
	});

	jQuery('#resultLoading>div:first').css({
		'width': '100%',
		'height':'60%',
		'text-align': 'center',
		'position': 'fixed',
		'top':'10',
		'left':'0',
		'right':'0',
		'bottom':'0',
		'margin':'auto',
		'font-size':'16px',
		'z-index':'10',
		'color':'#000'

	});

    jQuery('#resultLoading .bg').height('100%');
       jQuery('#resultLoading').fadeIn(1600);
    jQuery('body').css('cursor', 'wait');
}


function ajaxindicatorstop()
{
    jQuery('#resultLoading .bg').height('100%');
       jQuery('#resultLoading').fadeOut(1600);
    jQuery('body').css('cursor', 'default');
}


jQuery(document).ajaxStart(function () {
 		//show ajax indicator
ajaxindicatorstart('loading data.. please wait..');
}).ajaxStop(function () {
//hide ajax indicator
ajaxindicatorstop();
});


jQuery.ajax({
   global: false,
   // ajax stuff
});

</script>
<style>
#call_apiii {
    margin-left: 0px !important;
    font-size: 13px !important;
    border: 1px solid rgb(224, 137, 25) !important;
    background: rgb(224, 137, 25) none repeat scroll 0% 0% !important;
    color: rgb(255, 255, 255) !important;
	width: 100px !important;
}
#call_apiii:hover {
    background: rgb(25, 139, 224) none repeat scroll 0% 0% !important;
    border: 1px solid rgb(25, 139, 224) !important;
}
#call_apii{
    margin-left: 0px !important;
    font-size: 13px !important;
    border: 1px solid rgb(224, 137, 25) !important;
    background: rgb(224, 137, 25) none repeat scroll 0% 0% !important;
    color: rgb(255, 255, 255) !important;
	width: 100px !important;
  }
  
#call_apii:hover {
    background: rgb(25, 139, 224) none repeat scroll 0% 0% !important;
    border: 1px solid rgb(25, 139, 224) !important;
}
#insert{
    margin-left: 0px !important;
    font-size: 13px !important;
    border: 1px solid rgb(224, 137, 25) !important;
    background: rgb(224, 137, 25) none repeat scroll 0% 0% !important;
    color: rgb(255, 255, 255) !important;
	width: 100px !important;
  }
#insert:hover{ 
    background: rgb(25, 139, 224) none repeat scroll 0% 0% !important;
    border: 1px solid rgb(25, 139, 224) !important;
	}   
#quantity1, #quantity2, #quantity {
    width: 100px;
    height: 40px;
}
#insertt {
    margin-left: 0px !important;
    font-size: 13px !important;
    border: 1px solid rgb(224, 137, 25) !important;
    background: rgb(224, 137, 25) none repeat scroll 0% 0% !important;
    color: rgb(255, 255, 255) !important;
	width: 100px !important;
}
#insertt:hover {
    background: rgb(25, 139, 224) none repeat scroll 0% 0% !important;
    border: 1px solid rgb(25, 139, 224) !important;
}   
 #quantity1, #quantity2, #quantity {
    width: 100px;
    height: 40px;
}
  
#main-box-division {
    border: 1px solid #bdbdbd;
    font-family: arial;
    font-size: 15px;
}
.box-header {
        height: 25px !important;
}
.box-header h4{font-size:18px;}
  
#main-box-division_inner {
    padding: 10px;
}
.box-header h4 {
    font-size: 18px;
    text-align: center;
    padding: 5px;
}
#add-item-form {
    margin-top: -30px;
}

.inch {
    width: 100%;
}
.row.input_width {
    width: 48%;
    float: left;
    margin-left: 3px;
    margin-bottom: 10px;
}
.row.select {
    margin-left: 10px;
    width: 96%;
}
#call_api {
    font-size: 13px !important;
    border: 1px solid rgb(25, 139, 224) !important;
    background: rgb(25, 139, 224) none repeat scroll 0% 0% !important;
    color: rgb(255, 255, 255) !important;
    margin-left: 10px !important;
}
#call_api:hover{background: rgb(224, 137, 25) none repeat scroll 0% 0% !important;border: 1px solid rgb(224, 137, 25) !important;}
#main-box-division b {
    color: red !important;
    font-size: 12px !important;
}
#product_tables{
    font-family: arial;
    font-size: 12px;
}
#product_tables th {
    border: 1px solid #f6ebef;
    background: #0091cb;
    color: #fff;
    text-align:center;
}
#product_tables tr {
    background: #fff;
}
#product_tables td {
    border: 1px solid #b1b1b1;
    text-align: center;
    padding: 7px 10px;
}
</style>

