
<footer>

		<p>
			<span style="text-align:left;float:left">&copy; 2016 <a href="#" alt="Bootstrap_Metro_Dashboard">Jeronone Technology</a></span>
			
		</p>

	</footer>
