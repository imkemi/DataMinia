<div id="sidebar-left" class="span2">
<div class="nav-collapse sidebar-nav">
<ul class="nav nav-tabs nav-stacked main-menu">
	<li><a href="dashboard.php"><i class="icon-bar-chart"></i><span class="hidden-tablet"> Dashboard</span></a></li>
	<li><a href="create_product_by_app.php"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Add Product</span></a></li>
	<li><a href="create_product_by_app1.php"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Add Product New Format</span></a></li>
	<li><a href="new_form_store.php"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> New Store Form</span></a></li>
	<li><a href="get_products.php"><i class="icon-tasks"></i><span class="hidden-tablet"> View Product</span></a></li>	
 	<li>
							<a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Update Matrix</span><span class="label label-important" style="display:none"> 2 </span></a>
							<ul>
								<li><a class="submenu" href="product_update.php"><i class="icon-file-alt"></i><span class="hidden-tablet">Table One</span></a></li>
								<li><a class="submenu" href="product_update1.php"><i class="icon-file-alt"></i><span class="hidden-tablet">Table Two</span></a></li>
								<li><a class="submenu" href="submenu3.html" style="display:none"><i class="icon-file-alt"></i><span class="hidden-tablet"> Sub Menu 3</span></a></li>
							</ul>	
						</li>	
	<li><a href="img_update.php"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Product Image Update</span></a></li>
	
</ul>
</div></div>

