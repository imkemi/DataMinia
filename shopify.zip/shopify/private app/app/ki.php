<?php
 header('Access-Control-Allow-Origin: *');  

require __DIR__.'/vendor/autoload.php';
use phpish\shopify;

require __DIR__.'/conf.php';
?>






<?php
 	$shopify = shopify\client(SHOPIFY_SHOP, SHOPIFY_APP_API_KEY, SHOPIFY_APP_PASSWORD, true);

 
define ("MAX_SIZE","1000"); 
function getExtension($str)
{
	 $i = strrpos($str,".");
	 if (!$i) { return ""; }
	 $l = strlen($str) - $i;
	 $ext = substr($str,$i+1,$l);
	 return $ext;
}
 
$errors=0;
$image=$_FILES['image']['name'];
if ($image) 
{
	$filename = stripslashes($_FILES['image']['name']);
	$extension = getExtension($filename);
	$extension = strtolower($extension);
	if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") 
		&& ($extension != "gif")&& ($extension != "JPG") && ($extension != "JPEG") 
		&& ($extension != "PNG") && ($extension != "GIF")) 
	{
		echo '<h3>Unknown extension!</h3>';
		$errors=1;
	}
	else
	{
		$size=filesize($_FILES['image']['tmp_name']);
 
		if ($size > MAX_SIZE*1024)
		{
			echo '<h4>You have exceeded the size limit!</h4>';
			$errors=1;
		}
 
		$image_name=time().'.'.$extension;
		$newname='https://cdn.shopify.com/s/files/1/1318/4901/files/' .$image_name. '?16431291055174327543';
 
		$copied = copy($_FILES['image']['tmp_name'], $newname);
		if (!$copied) 
		{
			echo '<h3>Copy unsuccessfull!</h3>';
			$errors=1;
		}
		else echo '<h3>uploaded successfull!</h3>';
 
		//mysql_query("insert into file_tbl (path) values('".$newname."')");
		echo $newname;
	}	
}

	try
	{
		# Making an API request can throw an exception
		$product = $shopify('POST /admin/products.json', array(), array
		(
			'product' => array
			(
				"title" => "This is prooduct title",
				"body_html" => "This Is a product discription",
				"product_type" => "Product Type",			
				"variants" => array
				(
					array
					(
						
						"price" => "20.00",
						
					)
				),
				"images" => Array
                (
                     Array
                        (
                            "position" => "1",                            
                            "src" =>"$newname",
                            "variant_ids" => Array
                                (
                                )

                        )

                ),

             "image" => Array
                (
                    "position" => "1",   
                    "src" =>"$newname",
                    "variant_ids" => Array
                        (
                        )

                )
      
			)
		));
	//	echo '<pre>';
		//print_r($product);
	}

	catch (shopify\ApiException $e)
	{
		# HTTP status code was >= 400 or response contained the key 'errors'
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
	catch (shopify\CurlException $e)
	{
		# cURL error
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
	?>
	
	

	<form>
		 <?php
     if($product){
     $productvalue=array($product);
   // echo "[$material_type] [$height_ft ] [$width_ft] [$mountingstyle] [ $quantity] [$total_rates] inserted successfully!";
		 	//print_r($a);
	?>
		 <input type="text" id="quantitys" name="quantitys" value="<?php echo $quantity ?> ">
		 <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
		 <thead>
			 <tr>
				<th>Product Id</th>
				<th>Product Name</th>
				<th>Product Description</th>
				<th>Mounting Style</th>
				<th>Vendor</th>
				<th>Handle</th>
				<th>Delete</th>
			 </tr>
		 </thead>
		 <tbody>
		<?php
			 foreach($productvalue as $value)
	 	{
			$vaint = $value['variants'];
			//echo'<pre>';
			//print_r($vaint);
			foreach($vaint as $variantt)
			echo ' <td class="id_cls">'.$variantt['id'].'<td>'; 
			
			?>

	 			 <tr>
	 			 <td class="id_cls"><?php echo $value['id'] ?></td>
				 <input type="text" id="ids" name="ids" value="<?php echo $value['id'] ?> ">
	 			 			 <td><?php echo $value['title'] ?></td>
	 						 			 <td><?php echo $value['body_html']  ?></td>	 								 			 
	 												 			 <td><?php echo $value['product_type']  ?></td>
																     <td><?php echo $value['vendor']  ?></td>
	 															 			 <td><?php echo $value['handle']  ?></td>
	 																		      <td><button class="btn btn-danger">Chackout</button></a></td>
	        </tr>
				</form>
	 	<?php	}
}
 else{ echo "An error occurred!"; }

?>

