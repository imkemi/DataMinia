 <?php
//session_start();//session starts here
include 'appheader.php';
?>

<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>Login</title>
	 <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<style>
    .login-panel {
        margin-top: 150px;
	
}
#passs,#passss {
    height:39px;
    width: 100%;
}

</style>

<body>


<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="login-panel panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">Password Change</h3>
                </div>
                <div class="panel-body">
                    <form role="form" method="post" action="change_pass.php">
                        <fieldset>
                            <div class="form-group"  >
                                <input class="form-control" placeholder="E-mail" name="email" type="email" autofocus>
                            </div>
                            <div class="form-group">
                                <input class="form-control" placeholder="Old Password" name="pass" type="password" value="">
                            </div>
							<div class="form-group">
                                <input class="form_control" placeholder="New Password" name="passs" id="passs" type="password" value="">
                            </div>
                            <div class="form-group">
							    <p class ="show_single_error" id="show_ft_error"></p>
                                <input class="form_control" placeholder="Confirm Password" name="passss" id="passss" type="password" value="">
								
                            </div>

                                <input class="btn btn-lg btn-success btn-block" id="call_api" type="submit" value="change" name="change"  >

                            <!-- Change this to a button or input when using this as a form -->
                          <!--  <a href="index.html" class="btn btn-lg btn-success btn-block">Login</a> -->
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


</body>

</html>
<script type="text/javascript">
$(document).ready(function(){
	$("#call_api").click(function(){

        passs = $("#passs").val();
        passss = $("#passss").val();
       
	if(passs == ""){
		 alert('Please Enter The New Password');
	}
	else if(passss == ""){
		 alert('Please Enter The Confirm Password');
	}
	else if( passs !=  passss ) {
         alert('New Password And Confirm Password Does Not Match!');
	}
	
});
        
});
 

</script>

<?php
//error_reporting(0);
include("database/db_conection.php");

if(isset($_POST['change']))
{	error_reporting(0);
    $sql;
    $user_email=$_POST['email'];
    $user_pass1=$_POST['pass'];	
    $user_passs=$_POST['passs'];
	//echo '<p>old pass:- ' .$user_pass1 . '<p>';
	//echo $user_email;echo '<br>';
   // echo '<p>new pass:- ' .$user_passs . '<p>';
    $check_user="select * from users WHERE user_email='$user_email'";

    $run=mysqli_query($dbcon,$check_user);
	
	  while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
    {
	$dbpass=$row['user_pass'];
	$nme=$row['user_email'];
	
	//echo '<p>databese pass:- ' .$dbpass . '<p>';
	//echo '<p>user_email:- ' .$nme . '<p>';
	if ($dbpass == $user_pass1)
		{
			$sql ="UPDATE users SET user_pass='$user_passs' WHERE user_email='$user_email'";
			
		
		}
  

	$ru=mysqli_query($dbcon,$sql);
   
    if($ru>0)
    {
        echo '<script> alert("Your Password are successfully Updated"); window.location.href = "login.php";</script>';

    }
    else
    {
        echo "<script> alert('Password Are Not Match'); </script>";
    }
		
//echo $sql;
	}
}
?>
