<?php
 header('Access-Control-Allow-Origin: *');  

require __DIR__.'/vendor/autoload.php';
use phpish\shopify;

require __DIR__.'/conf.php';
?>
<?php
 $material_type = $_POST['material_type'];
 $product_price = $_POST['product_price'];
 $total_price = $_POST['total_pro_price'];
 $height_ft = $_POST['height_ft1'];
 $width_ft = $_POST['width_ft1'];
 $quantity = $_POST['quantity'];
 $mountingstyles = $_POST['mountingstyles'];
 
	$shopify = shopify\client(SHOPIFY_SHOP, SHOPIFY_APP_API_KEY, SHOPIFY_APP_PASSWORD, true);

	try
	{
		# Making an API request can throw an exception
		$product = $shopify('POST /admin/products.json', array(), array
		(
			'product' => array
			(
				"title" => "$material_type",
				"body_html" => "<span>Height(Inch): $height_ft</span><br><span>Width(Inch): $width_ft</span><br><span>Product Price: $product_price</span><br><span>Total Price: $total_price</span><br><span>Quantity: $quantity</span>",
				"product_type" => "$mountingstyles",			
				"variants" => array
				(
					array
					(
						
						"price" => "$product_price",
						
					)
				),
				"images" => Array
                (
                     Array
                        (
                            "position" => "1",                            
                            "src" =>"https://cdn.shopify.com/s/files/1/1318/4901/files/NewFauxBlind-200x200.jpg?16238074404248707205",
                            "variant_ids" => Array
                                (
                                )

                        )

                ),
             "image" => Array
                (
                    "position" => "1",   
                    "src" =>"https://cdn.shopify.com/s/files/1/1318/4901/files/NewFauxBlind-200x200.jpg?16238074404248707205",
                    "variant_ids" => Array
                        (
                        )

                )
				
			)
		));
	//	echo '<pre>';
		//print_r($product);
	}

	catch (shopify\ApiException $e)
	{
		# HTTP status code was >= 400 or response contained the key 'errors'
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
	catch (shopify\CurlException $e)
	{
		# cURL error
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
	?>
	
	

	<form>
		 <?php
     if($product){
     $productvalue=array($product);
   // echo "[$material_type] [$height_ft ] [$width_ft] [$mountingstyle] [ $quantity] [$total_rates] inserted successfully!";
		 	//print_r($a);
	?>
		 <input type="text" id="quantitys" name="quantitys" value="<?php echo $quantity ?> ">
		 <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
		 <thead>
			 <tr>
				<th>Product Id</th>
				<th>Product Name</th>
				<th>Product Description</th>
				<th>Mounting Style</th>
				<th>Vendor</th>
				<th>Handle</th>
				<th>Delete</th>
			 </tr>
		 </thead>
		 <tbody>
		<?php
			 foreach($productvalue as $value)
	 	{
			$vaint = $value['variants'];
			//echo'<pre>';
			//print_r($vaint);
			foreach($vaint as $variantt)
			echo ' <td class="id_cls">'.$variantt['id'].'<td>'; 
			
			?>

	 			 <tr>
	 			 <td class="id_cls"><?php echo $value['id'] ?></td>
				 <input type="text" id="ids" name="ids" value="<?php echo $value['id'] ?> ">
	 			 			 <td><?php echo $value['title'] ?></td>
	 						 			 <td><?php echo $value['body_html']  ?></td>	 								 			 
	 												 			 <td><?php echo $value['product_type']  ?></td>
																     <td><?php echo $value['vendor']  ?></td>
	 															 			 <td><?php echo $value['handle']  ?></td>
	 																		      
	        </tr>
				</form>
	 	<?php	}
}
 else{ echo "An error occurred!"; }

?>

