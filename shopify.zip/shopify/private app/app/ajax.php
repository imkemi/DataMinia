<?php
session_start();

if(!$_SESSION['email'])
{

    header("Location: login.php");//redirect to login page to secure the welcome page without login access.
}
require __DIR__.'/vendor/autoload.php';
use phpish\shopify;

require __DIR__.'/conf.php';
?>
<?php
 $material_type = $_POST['material_type'];
 $height_ft = $_POST['height_ft'];
 $width_ft = $_POST['width_ft'];
 $shipping = $_POST['shipping'];
 $quantity = $_POST['quantity'];
 $total_rates = $_POST['total_rates'];


	$shopify = shopify\client(SHOPIFY_SHOP, SHOPIFY_APP_API_KEY, SHOPIFY_APP_PASSWORD, true);

	try
	{
		# Making an API request can throw an exception
		$product = $shopify('POST /admin/products.json', array(), array
		(
			'product' => array
			(
				"title" => "$material_type",
				"body_html" => "<strong>Height:$height_ft</strong><br><strong>Width:$width_ft</strong>",
				"vendor" => "$shipping",
				"product_type" => "$quantity",
				"variants" => array
				(
					array
					(
						"option1" => "First",
						"price" => "$total_rates",
						"sku" => 123,
					),
					array (
						"option1" => "Second",
						"price" => "20.00",
						"sku" => "123"
					)
				)
			)
		));
	//	echo '<pre>';
	//	print_r($product);
	}

	catch (shopify\ApiException $e)
	{
		# HTTP status code was >= 400 or response contained the key 'errors'
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
	catch (shopify\CurlException $e)
	{
		# cURL error
		echo $e;
		print_R($e->getRequest());
		print_R($e->getResponse());
	}
     if($product){
    //echo "Data for  [$material_type] [$height_ft ] [$width_ft] [$shipping] [ $quantity] [$total_rates] inserted successfully!";
  }
  else{ echo "An error occurred!"; }

?>
