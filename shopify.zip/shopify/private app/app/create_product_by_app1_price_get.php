<?php
 header('Access-Control-Allow-Origin: *'); 
 $height_ft = $_POST['total_height'];
 $width_ft = $_POST['total_width'];
 $mountingstyles = $_POST['mountingstyle'];
//echo '<b>Select height is :-&nbsp;'. $height_ft. '&nbsp;And  Select Width Is :-&nbsp;' .$width_ft . 'And  Mounting Style Is :-&nbsp;'.$mountingstyles.'</b></br>';
 
    include("database/db_conection.php");
    $view_users_query="select * from basswood_blinds";//select query for viewing users.
    $run=mysqli_query($dbcon,$view_users_query);//here run the sql query.
    $run1=mysqli_query($dbcon,$view_users_query);//here run the sql query.
	$cont=1;
	?>
	<table class="table table-bordered table-hover table-striped" style="table-layout: fixed" id="product_tables">
		 <thead>
			 <tr>
				<th>Material Type</th>
				<th>Height(Inch)</th>
				<th>Width(Inch)</th>
				<th>Price</th>
				<th>Quantity</th>
				<th>Mounting Style</th>
				<th></th>				
				
			 </tr>
		 </thead>
		 <tbody>
		 <?php
    while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
    {
            $product_idd=$row[0];
            $height_ftt=$row[1];
            $width_ftt=$row[2];
            $material_typee=$row[3];
			$product_pricee=$row[4];
			$compare_pricee=$row[6];
           // $arr=array($product_pricee);						
   			//foreach($arr as $value)	{
			//	if($height_ft == $height_ftt+1 && $width_ft ==  $width_ftt+1){
				   //echo $value;
                  // echo next($value);
			//	}
			//}    			

		if($height_ft == $height_ftt && $width_ft ==  $width_ftt){
			//echo $cont; 		
			$final_price=$product_pricee;
			$material_type=$material_typee;
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
				
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>					
			<?php
			//continue;
			break;
		}
			
		else if($height_ft == $height_ftt && $width_ft == ($width_ftt+1)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+1)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }			 
			//$product_price=$product_pricee;
			$material_type=$material_typee;			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>				
			<?php
			//continue;
			break;
		}
		else if($height_ft == $height_ftt && $width_ft == ($width_ftt+2)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+1)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         } 
			//$product_price=$product_pricee;
			$material_type=$material_typee;			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>				
			<?php
			//continue;
			break;
		}
		  
		
        					
		else if($height_ft == ($height_ftt+1) && $width_ft ==  $width_ftt){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				        // echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         } 
			//$product_price=$product_pricee;
			$material_type=$material_typee;			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>				
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt+1) && $width_ft ==  ($width_ftt+1)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>			
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt+1) && $width_ft ==  ($width_ftt+2)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>						
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt+1) && $width_ft ==  ($width_ftt+3)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>				
			<?php
			//continue;
			break;
		}
			    
		else if($height_ft == ($height_ftt+2) && $width_ft ==  $width_ftt){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>				
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt+2) && $width_ft ==  ($width_ftt+1)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>				
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt+2) && $width_ft ==  ($width_ftt+2)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>				
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt+2) && $width_ft ==  ($width_ftt+3)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>				
			<?php
			//continue;
			break;
		}
		
		
		else if($height_ft == ($height_ftt+3) && $width_ft ==  $width_ftt){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>				
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt+3) && $width_ft ==  ($width_ftt+1)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>		
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt+3) && $width_ft ==  ($width_ftt+2)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>			
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt+3) && $width_ft ==  ($width_ftt+3)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>				
			<?php
			//continue;
			break;
		}
		
		else if($height_ft == ($height_ftt+4) && $width_ft ==  $width_ftt){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>				
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt+4) && $width_ft ==  ($width_ftt+1)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>			
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt+4) && $width_ft ==  ($width_ftt+2)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
		    <tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>		
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt+4) && $width_ft ==  ($width_ftt+3)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				        // echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
		    <tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>			
			<?php
			//continue;
			 break;
		}
		
			else if($height_ft == ($height_ftt+5) && $width_ft ==  $width_ftt){
				//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>			
			<?php
			//continue;
			 break;
		}
		else if($height_ft == ($height_ftt+5) && $width_ft ==  ($width_ftt+1)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>			
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt+5) && $width_ft ==  ($width_ftt+2)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>			
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt+5) && $width_ft ==  ($width_ftt+3)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>		
			<?php
			//continue;
			break;
		}
					
		else if($height_ft == ($height_ftt+6) && $width_ft ==  ($width_ftt+1)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
		   <tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>				
			<?php
			//continue;
			 break;
		}
		else if($height_ft == ($height_ftt+6) && $width_ft ==  ($width_ftt+2)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type=$material_typee;
			
			echo '<p id="new_product_price" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type" style="display:none;">' .$material_type . '</p>';
			
			echo '<p id="material_type2" style="display:none;">' .$material_type . '</p>';
			echo '<p id="product_price2" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft2" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft2" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles2" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type" name="material_type" value="<?php echo $material_type ?> ">
		     <input type="hidden" class = "input_class" id="product_price" name="product_price" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft1" name = "height_ft1" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft1" name = "width_ft1" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity" type = "number" class = "input_class field_input" name = "quantity" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles" name = "mountingstyles" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="call_apii" class="add_to_cart_btn button btn_style" name="call_apii" value = "Add To Cart" ></td>			        	
			 </tr>			
			<?php
			//continue;
			break;
		}
		$cont++;
		
	}	
	
?>
</table>

<table class="table table-bordered table-hover table-striped" style="table-layout: fixed" id="product_tables">
		  <thead>			 
		 </thead>
		 <tbody>
		 <?php
		 $view_users_query="select * from faux_blinds";//select query for viewing users.
         $run=mysqli_query($dbcon,$view_users_query);//here run the sql query.
		 $run1=mysqli_query($dbcon,$view_users_query);//here run the sql query.
	     $cont=1;
  while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
    {
            $product_idd1=$row[0];
            $height_ftt1=$row[1];
            $width_ftt1=$row[2];
            $material_typee1=$row[3];
			$product_pricee1=$row[4];
			$compare_pricee1=$row[6];
            		

		if($height_ft == $height_ftt1 && $width_ft ==  $width_ftt1){
			//echo $cont; 		
			$final_price=$product_pricee1;			
			$material_type1=$material_typee1;
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
				
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>					 
			<?php
			//continue;
			break;
		}
			
		else if($height_ft == $height_ftt1 && $width_ft == ($width_ftt1+1)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+1)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }			 
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;	
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>					
			<?php
			//continue;
			break;
		}
		else if($height_ft == $height_ftt1 && $width_ft == ($width_ftt1+2)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+1)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         } 
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;	
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>					
			<?php
			//continue;
			break;
		}
		  
		
        					
		else if($height_ft == ($height_ftt1+1) && $width_ft ==  $width_ftt1){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				        // echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         } 
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;		
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>					
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt1+1) && $width_ft ==  ($width_ftt1+1)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>		
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt1+1) && $width_ft ==  ($width_ftt1+2)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				        // echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>						
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt1+1) && $width_ft ==  ($width_ftt1+3)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				        // echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>				
			<?php
			//continue;
			break;
		}
			    
		else if($height_ft == ($height_ftt1+2) && $width_ft ==  $width_ftt1){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				        // echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>				
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt1+2) && $width_ft ==  ($width_ftt1+1)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>					
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt1+2) && $width_ft ==  ($width_ftt1+2)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>					
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt1+2) && $width_ft ==  ($width_ftt1+3)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>					
			<?php
			//continue;
			break;
		}
		
		
		else if($height_ft == ($height_ftt1+3) && $width_ft ==  $width_ftt1){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>				
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt1+3) && $width_ft ==  ($width_ftt1+1)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>			
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt1+3) && $width_ft ==  ($width_ftt1+2)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				        // echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>				
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt1+3) && $width_ft ==  ($width_ftt1+3)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>				
			<?php
			//continue;
			break;
		}
		
		else if($height_ft == ($height_ftt1+4) && $width_ft ==  $width_ftt1){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				        // echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>			
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt1+4) && $width_ft ==  ($width_ftt1+1)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>				
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt1+4) && $width_ft ==  ($width_ftt1+2)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>			
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt1+4) && $width_ft ==  ($width_ftt1+3)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				        // echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
		    <tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>			
			<?php
			//continue;
			 break;
		}
		
			else if($height_ft == ($height_ftt1+5) && $width_ft ==  $width_ftt1){
				//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				        // echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>			
			<?php
			//continue;
			 break;
		}
		else if($height_ft == ($height_ftt1+5) && $width_ft ==  ($width_ftt1+1)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>					
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt1+5) && $width_ft ==  ($width_ftt1+2)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>				
			<?php
			//continue;
			break;
		}
		else if($height_ft == ($height_ftt1+5) && $width_ft ==  ($width_ftt1+3)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			
		    echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>			
			<?php
			//continue;
			break;
		}
					
		else if($height_ft == ($height_ftt1+6) && $width_ft ==  ($width_ftt1+1)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';
			
			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
		   <tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>				
			<?php
			//continue;
			 break;
		}
		else if($height_ft == ($height_ftt1+6) && $width_ft ==  ($width_ftt1+2)){
			//echo $cont; 
			$i=1;						
			while($row1=mysqli_fetch_array($run1))//while look to fetch the result and store in a array $row.
             {
                  $height_ftt1=$row1[1];
                  $width_ftt1=$row1[2];                  
			      $product_pric1=$row1[4];	
                  if($i==($cont+18)){			  
				         $final_price=$product_pric1;
				         //echo '<p>next price value is:-' .$final_price. '<p>';
				  }
				  $i++;			 
			      
	         }
			//$product_price=$product_pricee;
			$material_type1=$material_typee1;
			
			echo '<p id="new_product_price1" style="display:none;">' .$final_price . '</p>';
			echo '<p id="product_type1" style="display:none;">' .$material_type1 . '</p>';

			echo '<p id="material_type3" style="display:none;">' .$material_type1 . '</p>';
			echo '<p id="product_price3" style="display:none;">' .$final_price . '</p>';
			echo '<p id="height_ft3" style="display:none;">' .$height_ft . '</p>';
			echo '<p id="width_ft3" style="display:none;">' .$width_ft . '</p>';
			echo '<p id="mountingstyles3" style="display:none;">' .$mountingstyles . '</p>';
			
						
			?>
			<tr>		
		     <input type="hidden" class = "input_class" id="material_type1" name="material_type1" value="<?php echo $material_type1 ?> ">
		     <input type="hidden" class = "input_class" id="product_price1" name="product_price1" value="<?php echo $final_price ?> ">
			 <td><?php echo $material_type1 ?></td>		     
			 <td><?php echo $height_ft ?></td>
			 <input type = "hidden" id = "height_ft2" name = "height_ft2" value ="<?php echo $height_ft ?>">
			 <td><?php echo $width_ft ?></td>
			 <input type = "hidden" id = "width_ft2" name = "width_ft2" value ="<?php echo $width_ft ?>">
			 <td><?php echo $final_price ?></td>		     
			 <td><input id = "quantity1" type = "number" class = "input_class field_input" name = "quantity1" step="1" value = "1"></td> 
			 <td><?php echo $mountingstyles ?></td>
			 <input type = "hidden" id = "mountingstyles1" name = "mountingstyles1" value ="<?php echo $mountingstyles ?>">
			 <td><input type="button" id="insert" class="add_to_cart_btn button btn_style" name="insert" value = "Add To Cart" ></td>			          	
			 </tr>			
			<?php
			//continue;
			break;
		}
		$cont++;
		
	}	
	
?>
</table>
<table class="table table-bordered table-hover table-striped" style="table-layout: fixed" id="product_tables">
		 <thead>
			 <tr>
				<th>Id</th>
				<th>Product Name</th>
				<th>Product Image</th>
				<th>Image Name</th>						
				
			 </tr>
		 </thead>
		 <tbody>
		
 <?php
         include("database/db_conection.php");
         $update_query="select * from product_images";///select query for update user users.
         $run=mysqli_query($dbcon,$update_query);//here run the sql query.
         	    
        while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
        {
            $product_ids=$row[0];
            $product_names=$row[1];
            $product_imagess=$row[2];
            $product_image_name=$row[4];
			
			if( $product_ids == 0){
		?>	
		
		        <?php echo '<p id="product_nms" style="display:none;">' .$product_names . '</p>';
			         // echo '<p style="display:block;"><img id="product_img" src="data:image/jpeg;base64,'.base64_encode($product_imagess).'"></p>';
					  $jpegimage = 'data:image/jpeg;base64,'.base64_encode($product_imagess).'"';
					 // echo $jpegimage;
					  echo '<p id="product_img" style="display:none;">' .$jpegimage . '</p>';
			    ?>
		        <tr>
		        <td> <?php echo  $product_ids; ?></td>
				<td> <?php echo  $product_names; ?></td>
				<td><?php echo '<img src="data:image/jpeg;base64,'.base64_encode($product_imagess).'">'; ?></td>
				<td> <?php echo  $product_image_name; ?></td>
				</tr>
         	  
		<?php
		    }
			if( $product_ids == 1){
				      echo '<p id="product_nms1" style="display:none;">' .$product_names . '</p>';
			           // echo '<p style="display:block;"><img id="product_img" src="data:image/jpeg;base64,'.base64_encode($product_imagess).'"></p>';
					  $jpegimage = 'data:image/jpeg;base64,'.base64_encode($product_imagess).'"';
					 // echo $jpegimage;
					  echo '<p id="product_img1" style="display:none;">' .$jpegimage . '</p>';
		    ?>
                <tr>
		        <td> <?php echo  $product_ids; ?></td>
				<td> <?php echo  $product_names; ?></td>
				<td><?php echo '<img src="data:image/jpeg;base64,'.base64_encode($product_imagess).'">'; ?></td>
				<td> <?php echo  $product_image_name; ?></td>	
                </tr>				
			<?php
		    }
		}
		?>	
				 
		 </tbody>
</table>	 
<style>
#quantity,#quantity1{width: 75px;height:30px;}
#call_apii,#insert {
    width: 125px !important;
    margin-left: 2em;
}
</style>
<script type="text/javascript">
$(document).ready(function(){
	$("#call_apii").click(function(){

       var material_type = $("#material_type").val();
       var product_price = $("#product_price").val();
       var quantity = $("#quantity").val();
	   var height_ft1= $("#height_ft1").val();
	   var width_ft1= $("#width_ft1").val();
	   var mountingstyles = $("#mountingstyles").val();
			
		$.post('create_product_by_app2_price_get.php', {material_type:material_type, product_price:product_price, quantity:quantity, height_ft1:height_ft1, width_ft1:width_ft1, mountingstyles:mountingstyles},
       function(data){
        alert('Your First Product are successfully Submitted');
        // var variant_id = $(data).find('.id_cls').html();
        //alert(data);

});
        
});

	
	});
    

</script>
<script type="text/javascript">
$(document).ready(function(){
	$("#insert").click(function(){

        material_type = $("#material_type1").val();
        product_price = $("#product_price1").val();
        quantity = $("#quantity1").val();
		var height_ft1= $("#height_ft2").val();
	    var width_ft1= $("#width_ft2").val();
	    var mountingstyles = $("#mountingstyles1").val();
		
		$.post('create_product_by_app2_price_get.php', {material_type:material_type, product_price:product_price, quantity:quantity, height_ft1:height_ft1, width_ft1:width_ft1, mountingstyles:mountingstyles},
       function(data){
        alert('Your Second Product are successfully Submitted');
        // var variant_id = $(data).find('.id_cls').html();
        //alert(data);

});
        
});	
	});    

</script>


	
