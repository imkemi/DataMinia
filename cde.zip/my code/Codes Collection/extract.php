<?php
$zip = new ZipArchive;
if ($zip->open('apps.zip') === TRUE) {
    $zip->extractTo('extract/');
    $zip->close();
    echo 'ok';
} else {
    echo 'failed';
}
?>
