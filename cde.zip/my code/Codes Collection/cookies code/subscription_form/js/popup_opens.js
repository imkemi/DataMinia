//Pop Dialog Subscription Box
$(document).ready(function() {	
		var id = '#dialog';
	
		//Get the screen height and width
		var maskHeight = $(document).height();
		var maskWidth = $(window).width();
	
		//Set heigth and width to mask to fill up the whole screen
		$('#mask').css({'width':maskWidth,'height':maskHeight});
		
		//transition effect		
		$('#mask').fadeIn(1000);	
		$('#mask').fadeTo("slow",0.8);	
	
		//Get the window height and width
		var winH = $(window).height();
		var winW = $(window).width();
              
		//Set the popup window to center
		//$(id).css('top',  winH/2-$(id).height()/2);
		//$(id).css('left', winW/2-$(id).width()/2);
	
		//transition effect
		$(id).fadeIn(2000); 	
	
	//if close button is clicked
	$('.window .close').click(function (e) {
		//Cancel the link behavior
		e.preventDefault();
		
		$('#mask').hide();
		$('.window').hide();
	});		
	
	//if mask is clicked
	$('#mask').click(function () {
		$(this).hide();
		$('.window').hide();
	});		
	
});


      $(document).ready(function(){
      var check_cookie = $.cookie('select_quiz_delay_popup');  
      //var date = new Date();
      //var minutes = 1;
      //date.setTime(date.getTime() + (minutes * 60 * 1000));
      if(check_cookie == null){   
      $.cookie("select_quiz_delay_popup", "foo", { expires: 7 });
      //fire your fancybox here
          setTimeout(function(){
            $(".popup_subscribe_box").show();
          }, 200);
        }
        else{         
          
          $(".popup_subscribe_box").css("display","none");     
          $("#mask").css("display","none");  
          
        }
      });
	  
	  
	
  $(document).ready(function(){
    $("#mc-embedded-subscribe").click(function(e){
 
    //$("#mce-FNAME").css('border', '2px solid rgba(235, 235, 235, 1)');
 //$("#mce-FNAME").attr("placeholder","Business Name");
// $("#mce-FNAME").removeClass("error");
 
 //$("#mce-LNAME").css('border', '2px solid rgba(235, 235, 235, 1)');
 //$("#mce-LNAME").attr("placeholder","Contact Name");
// $("#mce-LNAME").removeClass("error");
 
    $("#mce-EMAIL").css('border', '2px solid rgba(235, 235, 235, 1)');
// $("#mce-EMAIL").attr("placeholder","E-mail");
 $("#mce-EMAIL").removeClass("error");
     //aert('stopped');
      
   // var bnam = $("#mce-FNAME").val();
 //var cnam = $("#mce-LNAME").val();
    var booking_email = $("#mce-EMAIL").val();
      
      //if( bnam.length < 1 || cnam.length < 1 || booking_email.length < 1 )
      //{
		  if(booking_email.length < 1 )
      {
  e.preventDefault();
      //if (bnam.length <1 )   
      //{
      // $("#mce-FNAME").css('border', '1px solid #ff3333');
    //$("#mce-FNAME").attr("placeholder","Please Enter Your Business Name");
 //$("#mce-FNAME").addClass("error");
     // }
  // if (cnam.length <1 )   
    //  {
    //   $("#mce-LNAME").css('border', '1px solid #ff3333');
   // $("#mce-LNAME").attr("placeholder","Please Enter Your Contact Name");
 //$("#mce-LNAME").addClass("error");
     // }
      if (booking_email.length < 1)
      {
       $("#mce-EMAIL").css('border', '1px solid #ff3333');
   // $("#mce-EMAIL").attr("placeholder","Please Enter Your Email Address");
 $("#mce-EMAIL").addClass("error");
      }
      }
      else {      
      
      }
      
      if( /(.+)@(.+){2,}\.(.+){2,}/.test(booking_email) ){
  // valid email
  } else {
   e.preventDefault();
   $("#mce-EMAIL").css('border', '1px solid #ff3333');
  // $("#mce-EMAIL").attr("placeholder","Please Enter Your Email Address");
   $("#mce-EMAIL").addClass("error");
  }     
    });
   });
