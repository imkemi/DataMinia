<html>
<title>Mail Chimp Subscription Form</title>
<head>
<!-- <script src="//cdn.shopify.com/s/files/1/1451/9842/t/2/assets/jquery.cookie.js?566095691742545800" type="text/javascript"></script>-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="js/cookies.js"></script>
<script type="text/javascript">
//Pop Dialog Subscription Box
$(document).ready(function() {	
		var id = '#dialog';
	
		//Get the screen height and width
		var maskHeight = $(document).height();
		var maskWidth = $(window).width();
	
		//Set heigth and width to mask to fill up the whole screen
		$('#mask').css({'width':maskWidth,'height':maskHeight});
		
		//transition effect		
		$('#mask').fadeIn(1000);	
		$('#mask').fadeTo("slow",0.8);	
	
		//Get the window height and width
		var winH = $(window).height();
		var winW = $(window).width();
              
		//Set the popup window to center
		//$(id).css('top',  winH/2-$(id).height()/2);
		//$(id).css('left', winW/2-$(id).width()/2);
	
		//transition effect
		$(id).fadeIn(2000); 	
	
	//if close button is clicked
	$('.window .close').click(function (e) {
		//Cancel the link behavior
		e.preventDefault();
		
		$('#mask').hide();
		$('.window').hide();
	});		
	
	//if mask is clicked
	$('#mask').click(function () {
		$(this).hide();
		$('.window').hide();
	});		
	
});
</script>
<style>
/********** popup **************/
 
@font-face {
    font-family: 'filmotype_havanaregular';
    src: url('http://www.freez.com.au//subscription_form/filmotype_-_filmotypehavana-webfont.woff2') format('woff2'),
         url('http://www.freez.com.au//subscription_form/filmotype_-_filmotypehavana-webfont.woff') format('woff');
    font-weight: normal;
    font-style: normal;

}
.popup_subscribe_box #main_heading {
    font-family: filmotype_havanaregular;
    font-size: 54px;
    margin: 0px;
    color: #000;
}

.popup_subscribe_box  #popup_main #main_subscriber_bar > h1 {
  margin-bottom: 13px;
}
.popup_subscribe_box  #popup_main #mc-embedded-subscribe-form {
  margin-top: 5px;
}
.popup_subscribe_box  #popup_main .mc-field-group {
  margin-bottom: 15px;
}
.popup_subscribe_box  #popup_main .clear {
  padding-top: 0 !important;
}
.popup_subscribe_box  #popup_main #main_subscriber_bar {
  padding-bottom: 8px;
  padding-top: 19px;
}
.popup_subscribe_box  #popup_main #mc-embedded-subscribe-form {
  padding-left: 0 !important;
}
.popup_subscribe_box  #popup_main #main_subscriber_bar {
  padding-left: 18px;
}
.popup_subscribe_box  #popup_main *::-moz-placeholder {
  color: #9d9d9d;
  font-weight: normal;
  opacity: 0.7;
}
.popup_subscribe_box  a {color:#fff !important; text-decoration:none; margin: 9px 9px 0px 0px !important;}
.popup_subscribe_box  a:hover {color:#ccc; text-decoration:none;}
.popup_subscribe_box  #mc-embedded-subscribe-form {
    background: #79cb9b;
}
.popup_subscribe_box  #mask {
  position:absolute;
  left:0;
  top:0;
  z-index:9000;
  background-color:#000;
  display:none;
}  
/*.popup_subscribe_box .window {
  position: absolute;
  z-index: 9999;
}
.popup_subscribe_box #dialog {
  left: 50%;
  top: 50%;
transform:translate(-50%,-50%);;
  width: 600px;
}*/
#boxes .window {
  position:absolute;
  position: absolute;
  z-index: 9999;  
  display:none;
}
#boxes #dialog {
    left: 50%;
    top: 50%;
    transform:translate(-50%,-50%);
    width: 600px;   
}
.popup_subscribe_box   #popup_main{width:100%;float:left;}
.popup_subscribe_box   #div_left{width:49%;float:left;}
.popup_subscribe_box   #div_right {
    width: 50%;
    float: left;
}
.popup_subscribe_box  .close{
  opacity: 1 !important;
  font-size: 15px !important;  
}
.popup_subscribe_box  #mce-EMAIL, #mce-FNAME, #mce-LNAME, #mc-embedded-subscribe {
    border: 1px solid #7b7878;
    height: 35px;
    width: 100% !important;
    padding-left: 10px !important;
    border-radius: 0px !important;
	font-size: 14px !important;
}
.popup_subscribe_box  #mce-EMAIL{
    border: 1px solid #7b7878;
    height: 35px;
    padding-left: 10px !important;
    border-radius: 0px !important;
}
.popup_subscribe_box  .close {
    margin: 0px 0px 0px -15px;
    position: absolute;
    right: 3px;
}
.popup_subscribe_box  #div_left img{width:100%;float:left;height:400px;}
.popup_subscribe_box  #subheading{color: #fff;font-family: Verdana;}
.popup_subscribe_box  #main_subscriber_bar{padding:10px;}
.popup_subscribe_box  #mc-embedded-subscribe {
    border: 1px solid #9c9c9c !important;
    width: 100% !important;
    background: #fff !important;
    font-family: Verdana !important;
    color: grey !important;
    border-radius: 0px !important;
    height: 34px !important;
}
.popup_subscribe_box  .clear {
    background: #79cb9b;
    padding-top: 5%;
}
.popup_subscribe_box  #popup_main {    
    background: #79cb9b;
}
.popup_subscribe_box  .mc-field-group {
    background: #79cb9b;
}
.popup_subscribe_box #mask
{
    height: 100%;
    opacity: 0.8;
    position: fixed;
}
 
.popup_subscribe_box #subheading {
  margin-bottom: 26px !important;
  color:#000 !important;
  font-size: 15px;
}
 .popup_subscribe_box #popup_main .mc-field-group {
  margin-bottom: 25px !important;
}
 .popup_subscribe_box #popup_main #main_subscriber_bar {
  padding-bottom: 8px !important;
  padding-top: 16px !important;
}
 




@media screen and (min-width:768px) and (max-width:959px) {

  .popup-address {
    min-width: 726px;
  }
  .popup-address li.address-box {
    margin: 0 10px 10px 0;
  }

}

@media screen and (max-width:767px) {

  .ui-dialog {
    -webkit-box-shadow: none;
    -moz-box-shadow: none;
    box-shadow: none;
    overflow: hidden;
  }
  .ui-dialog .ui-dialog-titlebar-close {
    right: 0;
    top: 10px;
    border-bottom-left-radius: 11px;
    border-top-right-radius: 0;
    border-top-left-radius: 0;
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 11px;
  }
  .ui-dialog .ui-dialog-content table {
    width: 100%;
  }

  .popup-address {
    min-width: 232px;
  }
  .popup-address li.address-box {
    margin: 0 10px 10px 0;
  }
  
}
@media screen and (max-width:650px) {
	.popup_subscribe_box #popup_main #main_subscriber_bar {
  padding-bottom: 28px !important;
  padding-top: 16px !important;
}
	.popup_subscribe_box  #div_left {
  display: none;
}
.popup_subscribe_box #div_right {
  width: 100%;
}
.popup_subscribe_box #popup_main #main_subscriber_bar {
  padding-left: 18px;
  padding-right: 18px;
}
.popup_subscribe_box #dialog {
  width: 90%;
}
#boxes #dialog {
  width: 90%;
}
}
</style>
</head>
<body>
<div class="popup_subscribe_box" id="boxes">
<div id="dialog" class="window">
<a href="#" class="close">X</a>
 <div id='popup_main'>
    <div id="div_left"><img src="http://www.freez.com.au//subscription_form/imgs.jpg"></div>    
   
	 <div id="div_right">      
     <div id="main_subscriber_bar">
     <h1 id="main_heading">see freez first</h1>
     <p id="subheading">Be the first to see sales, discounts and new arrivals online.</p>
<!-- Begin MailChimp Signup Form -->
<div id="mc_embed_signup">
<form action="//freez.us1.list-manage.com/subscribe/post?u=51b57937c30a68863f8985150&amp;id=76d5e2b77a" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
    <div id="mc_embed_signup_scroll">	
<div class="mc-field-group">	
	<input type="text" value="" name="MMERGE1" class="" id="mce-FNAME" placeholder="First Name">
</div>
<div class="mc-field-group">	
	<input type="text" value="" name="MMERGE2" class="" id="mce-LNAME" placeholder="Last Name">
</div>
<div class="mc-field-group">	
	<input type="email" value="" name="EMAIL" class="required email" id="mce-EMAIL" placeholder="Email">
</div>
    <input type="hidden" value="Yes" name="POPUP" class="" id="mce-POPUP">
	
	<div id="mce-responses" class="clear">
		<div class="response" id="mce-error-response" style="display:none"></div>
		<div class="response" id="mce-success-response" style="display:none"></div>
	</div>    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
    <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_51b57937c30a68863f8985150_76d5e2b77a" tabindex="-1" value=""></div>
    <div class="clear"><button type="submit" name="subscribe" id="mc-embedded-subscribe" class="button"><span>SEND ME SPECIALS NOW</span></button></div>
    </div>
</form>
</div>

<!--End mc_embed_signup-->
</div>
   	</div>
  </div>
</div>
<!-- Mask to cover the whole screen -->
<div style="width: 100%; height: 100%; display: none; opacity: 0.8;" id="mask"></div>
</div>

<div><h1 style="text-align:center;">MailChimp Email Subscription Form </h1></div>
</body>
<script type="text/javascript">     
      $(document).ready(function(){
      var check_cookie = $.cookie('select_quiz_delay_popup');  
      var date = new Date();
      var minutes = 1;
      date.setTime(date.getTime() + (minutes * 60 * 1000));
      if(check_cookie == null){   
      $.cookie("select_quiz_delay_popup", "foo", { expires: date });
      //fire your fancybox here
          setTimeout(function(){
            $(".popup_subscribe_box").show();
          }, 200);
        }
        else{         
          
          $(".popup_subscribe_box").css("display","none");     
          $("#mask").css("display","none");  
          
        }
      });	  
  </script>
<script type="text/javascript">
  $(document).ready(function(){
    $("#mc-embedded-subscribe").click(function(e){
 
    //$("#mce-FNAME").css('border', '2px solid rgba(235, 235, 235, 1)');
 //$("#mce-FNAME").attr("placeholder","Business Name");
// $("#mce-FNAME").removeClass("error");
 
 //$("#mce-LNAME").css('border', '2px solid rgba(235, 235, 235, 1)');
 //$("#mce-LNAME").attr("placeholder","Contact Name");
// $("#mce-LNAME").removeClass("error");
 
    $("#mce-EMAIL").css('border', '2px solid rgba(235, 235, 235, 1)');
// $("#mce-EMAIL").attr("placeholder","E-mail");
 $("#mce-EMAIL").removeClass("error");
     //aert('stopped');
      
   // var bnam = $("#mce-FNAME").val();
 //var cnam = $("#mce-LNAME").val();
    var booking_email = $("#mce-EMAIL").val();
      
      //if( bnam.length < 1 || cnam.length < 1 || booking_email.length < 1 )
      //{
		  if(booking_email.length < 1 )
      {
  e.preventDefault();
      //if (bnam.length <1 )   
      //{
      // $("#mce-FNAME").css('border', '1px solid #ff3333');
    //$("#mce-FNAME").attr("placeholder","Please Enter Your Business Name");
 //$("#mce-FNAME").addClass("error");
     // }
  // if (cnam.length <1 )   
    //  {
    //   $("#mce-LNAME").css('border', '1px solid #ff3333');
   // $("#mce-LNAME").attr("placeholder","Please Enter Your Contact Name");
 //$("#mce-LNAME").addClass("error");
     // }
      if (booking_email.length < 1)
      {
       $("#mce-EMAIL").css('border', '1px solid #ff3333');
   // $("#mce-EMAIL").attr("placeholder","Please Enter Your Email Address");
 $("#mce-EMAIL").addClass("error");
      }
      }
      else {      
      
      }
      
      if( /(.+)@(.+){2,}\.(.+){2,}/.test(booking_email) ){
  // valid email
  } else {
   e.preventDefault();
   $("#mce-EMAIL").css('border', '1px solid #ff3333');
  // $("#mce-EMAIL").attr("placeholder","Please Enter Your Email Address");
   $("#mce-EMAIL").addClass("error");
  }     
    });
   });
</script>
</html>
