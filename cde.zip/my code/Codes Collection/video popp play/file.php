<?php
/**
 * The template used for displaying page content in single-portfolio.php
 *
 * @package Rhythm
 */
?>
<link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.2/css/bootstrap.min.css" integrity="sha384-y3tfxAZXuh4HwSYylfB+J125MxIs6mR5FOHamPBG064zB+AFeWH94NdvaCBm8qnd" crossorigin="anonymous">

	<script src="http://code.jquery.com/jquery-1.12.1.min.js"></script>	
	<script type="text/javascript">
		jQuery(function(){
			jQuery("a.bla-1").YouTubePopUp();
			jQuery("a.bla-2").YouTubePopUp( { autoplay: 0 } ); // Disable autoplay
		});
	</script>
	<script>	
(function ( $ ) {
 
    $.fn.YouTubePopUp = function(options) {

        var YouTubePopUpOptions = $.extend({
                autoplay: 1
        }, options );

        $(this).on('click', function (e) {

            var youtubeLink = $(this).attr("href");

            if( youtubeLink.match(/(youtube.com)/) ){
                var split_c = "v=";
                var split_n = 1;
            }

            if( youtubeLink.match(/(youtu.be)/) || youtubeLink.match(/(vimeo.com\/)+[0-9]/) ){
                var split_c = "/";
                var split_n = 3;
            }

            if( youtubeLink.match(/(vimeo.com\/)+[a-zA-Z]/) ){
                var split_c = "/";
                var split_n = 5;
            }

            var getYouTubeVideoID = youtubeLink.split(split_c)[split_n];

            var cleanVideoID = getYouTubeVideoID.replace(/(&)+(.*)/, "");

            if( youtubeLink.match(/(youtu.be)/) || youtubeLink.match(/(youtube.com)/) ){
                var videoEmbedLink = "https://www.youtube.com/embed/"+cleanVideoID+"?autoplay="+YouTubePopUpOptions.autoplay+"";
            }

            if( youtubeLink.match(/(vimeo.com\/)+[0-9]/) || youtubeLink.match(/(vimeo.com\/)+[a-zA-Z]/) ){
                var videoEmbedLink = "https://player.vimeo.com/video/"+cleanVideoID+"?autoplay="+YouTubePopUpOptions.autoplay+"";
            }

            $("body").append('<div class="YouTubePopUp-Wrap YouTubePopUp-animation"><div class="YouTubePopUp-Content"><span class="YouTubePopUp-Close"></span><iframe src="'+videoEmbedLink+'" allowfullscreen></iframe></div></div>');

            if( $('.YouTubePopUp-Wrap').hasClass('YouTubePopUp-animation') ){
                setTimeout(function() {
                    $('.YouTubePopUp-Wrap').removeClass("YouTubePopUp-animation");
                }, 600);
            }

            $(".YouTubePopUp-Wrap, .YouTubePopUp-Close").click(function(){
                $(".YouTubePopUp-Wrap").addClass("YouTubePopUp-Hide").delay(515).queue(function() { $(this).remove(); });
            });

            e.preventDefault();

        });

        $(document).keyup(function(e) {

            if ( e.keyCode == 27 ){
                $('.YouTubePopUp-Wrap, .YouTubePopUp-Close').click();
            }

        });

    };
 
}( jQuery ));

	</script>
<style>
@charset "UTF-8";
.YouTubePopUp-Wrap{
    position:fixed;
    width:100%;
    height:100%;
    background-color:#000;
    background-color:rgba(11, 10, 10, 0.35);
    top:0;
    left:0;
    z-index:9999999999999;
}

.YouTubePopUp-animation{
    opacity: 0;
    -webkit-animation-duration: 0.5s;
    animation-duration: 0.5s;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
    -webkit-animation-name: YouTubePopUp;
    animation-name: YouTubePopUp;
}

@-webkit-keyframes YouTubePopUp {
    0% {
        opacity: 0;
    }

    100% {
        opacity: 1;
    }
}

@keyframes YouTubePopUp {
    0% {
        opacity: 0;
    }

    100% {
        opacity: 1;
    }
}

body.logged-in .YouTubePopUp-Wrap{ /* For WordPress */
    top:32px;
    z-index:99998;
}

.YouTubePopUp-Content{
    max-width:680px;
    display:block;
    margin:0 auto;
    height:100%;
    position:relative;
}

.YouTubePopUp-Content iframe{
    max-width:100% !important;
    width:100% !important;
    display:block !important;
    height:480px !important;
    border:none !important;
    position:absolute;
    top: 0;
    bottom: 0;
    margin: auto 0;
}

.YouTubePopUp-Hide{
    -webkit-animation-duration: 0.5s;
    animation-duration: 0.5s;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
    -webkit-animation-name: YouTubePopUpHide;
    animation-name: YouTubePopUpHide;
}

@-webkit-keyframes YouTubePopUpHide {
    0% {
        opacity: 1;
    }

    100% {
        opacity: 0;
    }
}

@keyframes YouTubePopUpHide {
    0% {
        opacity: 1;
    }

    100% {
        opacity: 0;
    }
}

.YouTubePopUp-Close{
    position:absolute;
    top:0;
    cursor:pointer;
    bottom:528px;
    right:0px;
    margin:auto 0;
    width:24px;
    height:24px;
    background:url(../images/close.png) no-repeat;
    background-size:24px 24px;
    -webkit-background-size:24px 24px;
    -moz-background-size:24px 24px;
    -o-background-size:24px 24px;
}

.YouTubePopUp-Close:hover{
    opacity:0.5;
}

@media all and (max-width: 768px) and (min-width: 10px){
    .YouTubePopUp-Content{
        max-width:90%;
    }
}

@media all and (max-width: 600px) and (min-width: 10px){
    .YouTubePopUp-Content iframe{
        height:320px !important;
    }

    .YouTubePopUp-Close{
        bottom:362px;
    }
}

@media all and (max-width: 480px) and (min-width: 10px){
    .YouTubePopUp-Content iframe{
        height:220px !important;
    }

    .YouTubePopUp-Close{
        bottom:262px;
    }
}
</style>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="text port-new"> 
	<div class="row">	
	<div id="main_wrapper_left" class="col-md-6 col-sm-6">
	
		<?php if (ts_get_opt('portfolio-enable-featured-image') == 1): ?>
			<?php get_template_part('templates/portfolio/parts/featured-image'); ?>
		<?php endif; ?>

		<?php if (ts_get_opt('portfolio-enable-gallery') == 1): ?>
			<?php switch (ts_get_opt('portfolio-gallery-type')):
				case 'slider':
					get_template_part('templates/portfolio/parts/slider');
					break;
				case 'fullwidth-slider':
					get_template_part('templates/portfolio/parts/fullwidth-slider');
					break;
				case 'masonry':
					get_template_part('templates/portfolio/parts/masonry');
					break;
				case 'classic':
				default:
					get_template_part('templates/portfolio/parts/gallery');

			endswitch; ?>
		<?php endif; ?>
		
		<?php if (ts_get_opt('portfolio-enable-video') == 1): ?>
			<?php get_template_part('templates/portfolio/parts/video'); ?>
		<?php endif; ?>
	</div>
	<div id="main_wrapper_right" class="col-md-6 col-sm-6">
	<?php $meta = get_post_meta( get_the_ID() ); 
		//echo '<pre>';
		//print_r ($meta);
		$team_position =$meta['team-position'];
		$team_header = $meta['team-header'];		
		$team_facebook =$meta['team-facebook'];
		$team_twitter=$meta['team-twitter'];
		$team_pinterest=$meta['team-pinterest'];
		$team_vedio=$meta['team-vedio'];
		$team_image1=$meta['team-image1'];
		$team_image2=$meta['team-image2'];
	?>
	<h1 id="team_header" class="hs-line-11 font-alt"><?php echo $team_header[0]; ?></h1>
	<h2 id="team_position" class="hs-line-11 font-alt"><?php echo $team_position[0] ?></h2>
	<?php if (ts_get_opt('portfolio-content-bottom') != 1): ?>
			<?php get_template_part('templates/portfolio/parts/editor-content'); ?>
	<?php endif; ?>
	
	<div id="Social_media">
		<?php if(!empty($team_facebook[0])): ?>
		<span><a href="<?php echo $team_facebook[0] ?> " target="_black">Facebook</a></span> 
		<?php endif; ?>
		<?php if(!empty($team_twitter[0])): ?>
		<span><a href="<?php echo $team_twitter[0] ?> " target="_black">Twitter</a></span>
		<?php endif; ?>
		<?php if(!empty($team_pinterest[0])): ?>
		<span><a href="<?php echo $team_pinterest[0] ?> " target="_black">Pinterest</a></span>
		<?php endif; ?>		
			
	</div>
	</div>	
	</div>
	
	<div class="row">	
	<div id="main_wrapper_left" class="col-md-4 col-sm-4">
	<div id="team_vedios" style="height: 195px;width: 100%;background:url('http://vervetheagency.com.au/wp-content/uploads/2015/03/Untitled-design-3.jpg');">
	<div id="team_vedios_inner">
	<?php if(!empty($team_vedio[0])): ?>
		<a class="bla-1" href="<?php echo $team_vedio[0] ?>"><span class="big-icon"><i class="fa fa-play"></i></a></span> 
	<?php endif; ?>		
	</div>
	</div>
	</div>
	<div id="main_wrapper_left" class="col-md-4 col-sm-4">
	<?php if(!empty($team_image1[0])): ?>
		<div id="team_images"><img src="<?php echo $team_image1[0] ?>"></div>
		<?php endif; ?>	
	</div>
	<div id="main_wrapper_left" class="col-md-4 col-sm-4">
	<?php if(!empty($team_image2[0])): ?>
		<div id="team_images"><img src="<?php echo $team_image2[0] ?>"></div>
		<?php endif; ?>	
	</div>
	</div>
</article><!-- #post-## -->
